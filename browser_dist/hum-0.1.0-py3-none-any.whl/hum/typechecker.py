"""Type checker — structural validation of a built IR.

Basic concrete pin compatibility is checked while connections are built, and
adaptive channel compatibility is finalized by ``shape_resolver.py`` before
resource sizing.  This module handles graph-level structural checks that can
be performed using only the resolved IR:

- Every graph output pin must have at least one incoming edge.
- Edges must not connect two graph-boundary pins directly.
- No self-loops (src_node == dst_node).
- Every resolved node input slot must have exactly one producer
  (see ``_check_input_pins``).
- Resolved output slots must preserve positional/variadic arity invariants
  while still permitting producer fanout (see ``_check_output_pins``).

These checks run after the builder but before topo-sort, so the IR has
complete node/edge/pin lists but no schedule yet.
"""

from __future__ import annotations

from collections import defaultdict

from hum.errors import CompileError, ErrorCollector
from hum.ir import IR


def _check_input_pins(ir: IR, ec: ErrorCollector) -> None:
    """Verify every resolved node input slot has exactly one producer.

    An undriven input is not merely a missing diagnostic: the serializer builds
    each schedule entry's pin list from *only* the pins that have edges, sorted
    by index and written positionally.  A gap therefore silently shifts every
    later connection down a slot, and the node reads a signal the author never
    wired to it.  Rejecting gaps here keeps that positional encoding correct by
    construction.

    Multiple producers are never implicit mixing.  A regular edge and a
    feedback edge are alternative ways to supply a slot; feedback changes the
    timing of the producer, not the cardinality of the input.  If signals need
    to be combined, the graph must contain an explicit node such as ``Sum``.

    Rules matching the two pin kinds:

    * **All slots** — more than one incoming edge to the same ``(node, pin)``
      is rejected (``E090``), regardless of whether those edges are regular or
      feedback edges.
    * **Fixed pins** — every declared position must have an incoming edge
      (``E087``).
    * **Variadic pins** (``count = "variable"``) — the pin owns the whole index
      space, so the connected subscripts must be contiguous from 0 (``E088``)
      and their number must fall within ``[min_count, max_count]`` (``E087``).

    A node declaring *both* fixed and variadic input pins would have the two
    index spaces overlap; no such node exists and the case is not modelled, so
    only the fixed pins are checked there.
    """
    incoming: dict[int, dict[int, list[int]]] = defaultdict(lambda: defaultdict(list))
    for edge_id, edge in enumerate(ir.edges):
        if edge.dst_node >= 0:
            incoming[edge.dst_node][edge.dst_pin].append(edge_id)

    for node_idx, node in enumerate(ir.nodes):
        slots = incoming[node_idx]
        pins = set(slots)
        variadic = [p for p in node.input_pins if p.variadic]
        fixed    = [p for p in node.input_pins if not p.variadic]

        # One producer per resolved input slot.  For a sole variadic pin the
        # IR pin index is the explicit subscript; for fixed pins it is the
        # declaration index.  In either case the destination tuple uniquely
        # identifies the slot.
        for pin_idx, edge_ids in sorted(slots.items()):
            if len(edge_ids) <= 1:
                continue

            if variadic and not fixed:
                pin_name = f"{variadic[0].name}[{pin_idx}]"
            else:
                spec = next((p for p in fixed if p.index == pin_idx), None)
                pin_name = spec.name if spec is not None else str(pin_idx)

            ec.error(
                "E090",
                f"node '{node.name}': input pin '{pin_name}' is driven by "
                f"{len(edge_ids)} edges (only one producer allowed)",
            )

        # Sole variadic input pin: contiguity + arity.
        if variadic and not fixed:
            spec = variadic[0]
            lo   = spec.min_count if spec.min_count is not None else 1
            n    = len(pins)

            if n == 0:
                ec.error(
                    "E087",
                    f"node '{node.name}': input pin '{spec.name}' has no "
                    f"connections (at least {lo} required)",
                )
                continue

            missing = sorted(set(range(n)) - pins)
            if missing:
                ec.error(
                    "E088",
                    f"node '{node.name}': input pin '{spec.name}' indices must be "
                    f"contiguous from 0 — {n} connection(s) present but "
                    f"index {missing[0]} is unused "
                    f"(highest connected index is {max(pins)})",
                )
            if n < lo:
                ec.error(
                    "E087",
                    f"node '{node.name}': input pin '{spec.name}' has {n} "
                    f"connection(s); at least {lo} required",
                )
            if spec.max_count is not None and n > spec.max_count:
                ec.error(
                    "E087",
                    f"node '{node.name}': input pin '{spec.name}' has {n} "
                    f"connection(s); at most {spec.max_count} allowed",
                )
            if spec.count_from_channels is not None and n != spec.resolved_count:
                ec.error(
                    "E091",
                    f"node '{node.name}': input pin '{spec.name}' requires "
                    f"{spec.resolved_count} resolved slot(s), found {n}",
                )
            continue

        for p in fixed:
            if p.index not in pins:
                ec.error(
                    "E087",
                    f"node '{node.name}': input pin '{p.name}' is not connected",
                )


def _check_output_pins(ir: IR, ec: ErrorCollector) -> None:
    """Validate output slot numbering and variadic output arity.

    Output fanout is legal, so validation is based on unique ``(node, pin)``
    slots rather than edge count.  A sole variadic output owns the explicit
    index space and must be contiguous from zero.  When shape resolution has
    derived an exact arity (for example SplitChannels), every resolved slot
    must be connected so the runtime receives the declared output array.

    For ordinary fixed outputs, unused trailing outputs are allowed, but a
    later output may not be connected while an earlier slot is absent because
    the runtime process ABI is positional.
    """
    outgoing: dict[int, set[int]] = defaultdict(set)
    for edge in ir.edges:
        if edge.src_node >= 0:
            outgoing[edge.src_node].add(edge.src_pin)

    for node_idx, node in enumerate(ir.nodes):
        slots = outgoing[node_idx]
        variadic = [p for p in node.output_pins if p.variadic]
        fixed = [p for p in node.output_pins if not p.variadic]

        if variadic and not fixed:
            spec = variadic[0]
            n = len(slots)
            if n == 0:
                lo = spec.min_count if spec.min_count is not None else 1
                ec.error(
                    "E087",
                    f"node '{node.name}': output pin '{spec.name}' has no "
                    f"connections (at least {lo} required)",
                )
                continue

            missing = sorted(set(range(max(slots) + 1)) - slots)
            if missing:
                ec.error(
                    "E088",
                    f"node '{node.name}': output pin '{spec.name}' indices must be "
                    f"contiguous from 0 — index {missing[0]} is unused "
                    f"(highest connected index is {max(slots)})",
                )
            lo = spec.min_count if spec.min_count is not None else 1
            if n < lo:
                ec.error(
                    "E087",
                    f"node '{node.name}': output pin '{spec.name}' has {n} "
                    f"connected slot(s); at least {lo} required",
                )
            if spec.max_count is not None and n > spec.max_count:
                ec.error(
                    "E087",
                    f"node '{node.name}': output pin '{spec.name}' has {n} "
                    f"connected slot(s); at most {spec.max_count} allowed",
                )
            if spec.count_from_channels is not None and n != spec.resolved_count:
                ec.error(
                    "E091",
                    f"node '{node.name}': output pin '{spec.name}' requires "
                    f"{spec.resolved_count} resolved slot(s), found {n}",
                )
            continue

        if fixed and slots:
            highest = max(slots)
            missing = [p.index for p in fixed if p.index <= highest and p.index not in slots]
            if missing:
                ec.error(
                    "E091",
                    f"node '{node.name}': fixed output slots must form a contiguous "
                    f"prefix; output index {missing[0]} is unused",
                )


def check_types(ir: IR) -> None:
    """Validate IR structural invariants.

    Raises ``CompileError`` if any hard errors are found.
    Warnings are collected but do not cause a raise.
    """
    ec = ErrorCollector()

    # Build per-edge lookup: which edges arrive at each graph output pin?
    # graph_output_incoming[pin_idx] = list of edge indices
    graph_output_incoming: dict[int, list[int]] = {
        i: [] for i in range(len(ir.graph_outputs))
    }
    # graph_input_outgoing[pin_idx] = list of edge indices
    graph_input_outgoing: dict[int, list[int]] = {
        i: [] for i in range(len(ir.graph_inputs))
    }

    for edge_id, edge in enumerate(ir.edges):
        # Direct graph-boundary to graph-boundary connection is nonsensical
        if edge.src_node == -1 and edge.dst_node == -1:
            ec.error(
                "E080",
                f"edge {edge_id}: direct connection between two graph-boundary pins",
            )

        # Self-loop — legal only when the edge is a feedback wire (one-block delay)
        if edge.src_node >= 0 and edge.src_node == edge.dst_node and not edge.feedback_wire:
            ec.error(
                "E081",
                f"edge {edge_id}: self-loop on node {ir.nodes[edge.src_node].name}",
            )

        # Track graph output connectivity
        if edge.dst_node == -1:
            graph_output_incoming[edge.dst_pin].append(edge_id)

        # Track graph input usage
        if edge.src_node == -1:
            graph_input_outgoing[edge.src_pin].append(edge_id)

    # Graph output pins must each be driven by exactly one edge
    for pin_idx, gp in enumerate(ir.graph_outputs):
        incoming = graph_output_incoming[pin_idx]
        if not incoming:
            ec.error(
                "E082",
                f"graph output pin '{gp.name}' is not driven by any edge",
            )
        elif len(incoming) > 1:
            ec.error(
                "E083",
                f"graph output pin '{gp.name}' is driven by {len(incoming)} edges "
                f"(only one driver allowed)",
            )

    # Graph input pins that are declared but never consumed (warning)
    for pin_idx, gp in enumerate(ir.graph_inputs):
        if not graph_input_outgoing[pin_idx]:
            ec.warning(
                "W030",
                f"graph input pin '{gp.name}' is declared but never connected",
            )

    _check_input_pins(ir, ec)
    _check_output_pins(ir, ec)

    ec.raise_if_errors()
