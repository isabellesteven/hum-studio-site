"""Hum — portable audio DSP framework toolchain."""

__version__ = "0.1.0"
