"""FNV-1a 32-bit hash — single authoritative Python implementation.

Used by the toolchain to compute:
  - node type_id:  fnv1a_str("namespace.NodeName")
  - manifest checksums (with newline canonicalization)
  - graph checksum in the blob header

The C counterpart lives in runtime/hum_fnv.h.
Both must produce identical results for all inputs.
"""

_OFFSET_BASIS: int = 0x811C9DC5
_PRIME: int = 0x01000193
_MASK: int = 0xFFFFFFFF


def fnv1a_32(data: bytes) -> int:
    """Return the FNV-1a 32-bit hash of *data*."""
    h = _OFFSET_BASIS
    for byte in data:
        h = ((h ^ byte) * _PRIME) & _MASK
    return h



def canonicalize_text_bytes(data: bytes) -> bytes:
    """Return *data* with text newlines canonicalized to LF.

    Git checkouts may represent the same text file with LF or CRLF line endings.
    Manifest checksums are part of the compiler/runtime compatibility contract, so
    they must not depend on the host checkout's newline convention.
    """
    return data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")


def manifest_checksum(data: bytes) -> int:
    """Return the platform-independent checksum for a .humnode manifest."""
    return fnv1a_32(canonicalize_text_bytes(data))

def fnv1a_str(s: str) -> int:
    """Return the FNV-1a 32-bit hash of UTF-8-encoded *s*."""
    return fnv1a_32(s.encode("utf-8"))


def node_type_id(fully_qualified_name: str) -> int:
    """Compute the type_id for a node given its fully qualified name.

    Example:
        >>> hex(node_type_id("std.filters.BiquadLP"))
        '0x...'
    """
    return fnv1a_str(fully_qualified_name)
