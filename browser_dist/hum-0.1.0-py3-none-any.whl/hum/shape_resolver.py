"""Resolve per-instance pin channel shape before resource sizing.

Phase 3.1 refines the V1 channel-shape model:

* Concrete channel counts on graph/node pins are hard constraints.
* A connection equates the channel count of its source and destination.
* Every manifest pin declared ``channels = \"any\"`` is independent by default.
* Pins with the same non-empty ``channel_group`` on one node instance share a
  channel width.  Group names are local to that node instance.
* A legacy explicit ``channels`` node parameter, when supplied by the graph
  author, is a hard constraint only when the node has one logical adaptive
  channel group.
* An unconstrained adaptive component defaults to mono for backwards
  compatibility with isolated-node builder use.

After :func:`resolve_shapes`, all graph pins, node pin specs, and edge PinTypes
have concrete channel counts (>= 1), and ``ir.shapes_resolved`` is true.
Resource descriptors must be invoked only after this stage.
"""

from __future__ import annotations

from dataclasses import replace
from typing import Optional

from hum.errors import ErrorCollector
from hum.ir import IR, InstancePinSpec, PinType, pins_compatible


class _UnionFind:
    def __init__(self) -> None:
        self.parent: list[int] = []
        self.rank: list[int] = []

    def add(self) -> int:
        idx = len(self.parent)
        self.parent.append(idx)
        self.rank.append(0)
        return idx

    def find(self, x: int) -> int:
        p = self.parent[x]
        if p != x:
            self.parent[x] = self.find(p)
        return self.parent[x]

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return
        if self.rank[ra] < self.rank[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        if self.rank[ra] == self.rank[rb]:
            self.rank[ra] += 1


def _pin_for_index(pins: list[InstancePinSpec], pin_index: int) -> Optional[InstancePinSpec]:
    """Return the manifest pin spec represented by a resolved edge pin index.

    A sole variadic pin owns the explicit edge index space.  Mixed fixed and
    variadic pin lists are intentionally not modelled in V1.
    """
    variadic = [p for p in pins if p.variadic]
    fixed = [p for p in pins if not p.variadic]
    if variadic and not fixed:
        return variadic[0]
    return next((p for p in fixed if p.index == pin_index), None)


def resolve_shapes(
    ir: IR,
    errors: ErrorCollector,
    *,
    explicit_channel_constraints: Optional[dict[tuple[int, Optional[str]], int]] = None,
) -> None:
    """Resolve channel counts for every graph/node pin and edge in *ir*.

    ``explicit_channel_constraints`` maps ``(node_index, channel_group)`` to a
    legacy graph-authored channel-width value.  ``channel_group=None`` retains
    compatibility with an older scalar ``channels`` parameter and is accepted
    only when the node has one logical adaptive group.
    """
    explicit_channel_constraints = explicit_channel_constraints or {}
    uf = _UnionFind()

    # Endpoint maps.  Values are union-find variable IDs.
    graph_in_var: dict[int, int] = {}
    graph_out_var: dict[int, int] = {}
    node_in_var: dict[tuple[int, int], int] = {}
    node_out_var: dict[tuple[int, int], int] = {}
    # node index -> logical adaptive group key -> representative variable
    node_adaptive_groups: dict[int, dict[tuple, int]] = {}

    # var_id -> (PinType, adaptive, human-readable label)
    endpoint_meta: dict[int, tuple[PinType, bool, str]] = {}

    # Resolve the connected arity of every variadic pin before channel solving.
    # Input and output pin index spaces are already explicit on IR edges; fanout
    # from one output slot therefore contributes one slot, not one per edge.
    input_slots: dict[int, set[int]] = {}
    output_slots: dict[int, set[int]] = {}
    for edge in ir.edges:
        if edge.dst_node >= 0:
            input_slots.setdefault(edge.dst_node, set()).add(edge.dst_pin)
        if edge.src_node >= 0:
            output_slots.setdefault(edge.src_node, set()).add(edge.src_pin)

    for node_idx, node in enumerate(ir.nodes):
        for pins, slots in (
            (node.input_pins, input_slots.get(node_idx, set())),
            (node.output_pins, output_slots.get(node_idx, set())),
        ):
            variadic = [p for p in pins if p.variadic]
            fixed = [p for p in pins if not p.variadic]
            if variadic and not fixed:
                spec = variadic[0]
                spec.resolved_count = (max(slots) + 1) if slots else 0
            else:
                for spec in fixed:
                    spec.resolved_count = 1

    def add_endpoint(pt: PinType, adaptive: bool, label: str) -> int:
        v = uf.add()
        endpoint_meta[v] = (pt, adaptive, label)
        return v

    for i, gp in enumerate(ir.graph_inputs):
        adaptive = getattr(gp, "channels_any", gp.pin_type.channels == 0)
        graph_in_var[i] = add_endpoint(gp.pin_type, adaptive, f"graph input '{gp.name}'")
    for i, gp in enumerate(ir.graph_outputs):
        adaptive = getattr(gp, "channels_any", gp.pin_type.channels == 0)
        graph_out_var[i] = add_endpoint(gp.pin_type, adaptive, f"graph output '{gp.name}'")

    for node_idx, node in enumerate(ir.nodes):
        # channel_group is an explicit equality relation local to this node
        # instance.  Ungrouped adaptive pins remain independent.
        channel_groups: dict[str, int] = {}
        adaptive_groups: dict[tuple, int] = {}

        def register_pin(spec: InstancePinSpec, v: int, side: str, list_idx: int) -> None:
            if spec.channel_group is not None:
                prior = channel_groups.get(spec.channel_group)
                if prior is None:
                    channel_groups[spec.channel_group] = v
                else:
                    uf.union(prior, v)

            if spec.channels_any:
                key = ("group", spec.channel_group) if spec.channel_group is not None else (side, list_idx)
                adaptive_groups.setdefault(key, v)

        for list_idx, spec in enumerate(node.input_pins):
            if spec.pin_type is None:
                continue
            v = add_endpoint(
                spec.pin_type,
                spec.channels_any,
                f"node '{node.name}' input '{spec.name}'",
            )
            node_in_var[(node_idx, list_idx)] = v
            register_pin(spec, v, "in", list_idx)

        for list_idx, spec in enumerate(node.output_pins):
            if spec.pin_type is None:
                continue
            v = add_endpoint(
                spec.pin_type,
                spec.channels_any,
                f"node '{node.name}' output '{spec.name}'",
            )
            node_out_var[(node_idx, list_idx)] = v
            register_pin(spec, v, "out", list_idx)

        node_adaptive_groups[node_idx] = adaptive_groups

    def node_var(node_idx: int, pin_idx: int, *, is_output: bool) -> Optional[int]:
        node = ir.nodes[node_idx]
        pins = node.output_pins if is_output else node.input_pins
        spec = _pin_for_index(pins, pin_idx)
        if spec is None:
            return None
        list_idx = pins.index(spec)
        table = node_out_var if is_output else node_in_var
        return table.get((node_idx, list_idx))

    # Connections equate endpoint channel widths.
    edge_vars: list[tuple[Optional[int], Optional[int]]] = []
    for edge in ir.edges:
        src_v = graph_in_var.get(edge.src_pin) if edge.src_node < 0 else node_var(
            edge.src_node, edge.src_pin, is_output=True
        )
        dst_v = graph_out_var.get(edge.dst_pin) if edge.dst_node < 0 else node_var(
            edge.dst_node, edge.dst_pin, is_output=False
        )
        edge_vars.append((src_v, dst_v))
        if src_v is not None and dst_v is not None:
            uf.union(src_v, dst_v)

    # Gather hard concrete constraints per connected component.
    concrete: dict[int, set[int]] = {}
    labels: dict[int, list[str]] = {}
    for var_id, (pt, adaptive, label) in endpoint_meta.items():
        root = uf.find(var_id)
        labels.setdefault(root, []).append(label)
        if pt.channels > 0:
            concrete.setdefault(root, set()).add(pt.channels)

    def find_named_pin(node, name: str) -> Optional[InstancePinSpec]:
        matches = [p for p in node.input_pins + node.output_pins if p.name == name]
        return matches[0] if len(matches) == 1 else None

    # A pin may derive its channel width from the resolved arity of one named
    # variadic pin (MergeChannels is the current stdlib use).  This becomes a
    # hard concrete constraint on that pin's channel component.
    for node_idx, node in enumerate(ir.nodes):
        for side, pins, table in (
            ("in", node.input_pins, node_in_var),
            ("out", node.output_pins, node_out_var),
        ):
            for list_idx, spec in enumerate(pins):
                if spec.channels_from_count is None:
                    continue
                source_pin = find_named_pin(node, spec.channels_from_count)
                if source_pin is None or not source_pin.variadic:
                    errors.error(
                        "E022",
                        f"node '{node.name}': pin '{spec.name}' derives channels from "
                        f"invalid variadic pin '{spec.channels_from_count}'",
                    )
                    continue
                width = source_pin.resolved_count
                if width <= 0:
                    errors.error(
                        "E022",
                        f"node '{node.name}': pin '{spec.name}' cannot derive channels "
                        f"because variadic pin '{source_pin.name}' has no resolved slots",
                    )
                    continue
                v = table.get((node_idx, list_idx))
                if v is not None:
                    concrete.setdefault(uf.find(v), set()).add(width)

    # Legacy explicit channels parameters are hard constraints, but manifest
    # defaults are intentionally *not* constraints; otherwise a default mono
    # value would defeat inference from a connected stereo graph.  A scalar
    # legacy parameter is meaningful only for a node with one logical adaptive
    # group.  Phase 4 manifests use explicit compiler-sourced channel-group
    # parameters; this scalar path remains only for older third-party manifests.
    for (node_idx, group_name), width in explicit_channel_constraints.items():
        if node_idx < 0 or node_idx >= len(ir.nodes):
            continue
        node = ir.nodes[node_idx]
        groups = node_adaptive_groups.get(node_idx, {})
        if not groups:
            continue
        if group_name is None:
            if len(groups) != 1:
                errors.error(
                    "E022",
                    f"node '{node.name}': legacy channel-width parameter is ambiguous "
                    "because the node has multiple independent adaptive channel groups",
                )
                continue
            v = next(iter(groups.values()))
        else:
            key = ("group", group_name)
            v = groups.get(key)
            if v is None:
                errors.error(
                    "E022",
                    f"node '{node.name}': channel source references unknown adaptive "
                    f"group '{group_name}'",
                )
                continue
        concrete.setdefault(uf.find(v), set()).add(int(width))

    resolved: dict[int, int] = {}
    for root in {uf.find(v) for v in endpoint_meta}:
        values = concrete.get(root, set())
        if len(values) > 1:
            names = ", ".join(labels.get(root, [])[:4])
            errors.error(
                "E022",
                f"channel count mismatch in connected shape ({sorted(values)}): {names}",
            )
            continue
        if values:
            resolved[root] = next(iter(values))
        else:
            # Backwards-compatible deterministic fallback for an entirely
            # unconstrained adaptive component (e.g. an isolated Gain in a
            # builder unit test).  Executable connectivity is checked later by
            # the structural typechecker.
            resolved[root] = 1

    if errors.has_errors:
        return

    # Write resolved widths back into graph/node endpoint types.
    for var_id, (pt, _adaptive, _label) in endpoint_meta.items():
        pt.channels = resolved[uf.find(var_id)]

    # A variadic pin may derive its required slot count from another pin's
    # resolved channel width (SplitChannels is the current stdlib use).
    for node in ir.nodes:
        for spec in node.input_pins + node.output_pins:
            if spec.count_from_channels is None:
                continue
            source_pin = find_named_pin(node, spec.count_from_channels)
            if source_pin is None or source_pin.pin_type is None:
                errors.error(
                    "E022",
                    f"node '{node.name}': pin '{spec.name}' derives count from invalid "
                    f"pin '{spec.count_from_channels}'",
                )
                continue
            spec.resolved_count = source_pin.pin_type.channels

    if errors.has_errors:
        return

    # Rebuild each edge type from the now-concrete source endpoint and verify
    # the fully resolved connection against its destination endpoint.
    for edge, (src_v, dst_v) in zip(ir.edges, edge_vars):
        if src_v is None or dst_v is None:
            continue
        src_pt = endpoint_meta[src_v][0]
        dst_pt = endpoint_meta[dst_v][0]
        for err in pins_compatible(src_pt, dst_pt):
            code, msg = err.split(": ", 1)
            errors.error(code, msg)
        edge.pin_type = replace(src_pt)

    if errors.has_errors:
        return

    ir.shapes_resolved = True
