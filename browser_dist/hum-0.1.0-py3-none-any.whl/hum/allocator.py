"""Buffer and state allocator — v2 two-arena model.

Assigns a unique buffer to every edge and unique state memory to every node.
No buffer sharing / aliasing is performed.

After this stage:
  - ``edge.buffer`` is filled in for every edge.
  - ``ir.state_assignments`` is populated with one ``StateAssignment`` per node.

Memory region layout (Stage 2):
  - Audio buffers: last declared region (audio arena); offsets start at 0.
  - Node state / param-copy: first matching control region (all except the last).
    Falls back to the first region if no match.

The Python toolchain never needs to know C runtime struct sizes; control-arena
layout is owned entirely by the runtime.

Alignment: all allocations are 4-byte aligned (float32 natural alignment).
"""

from __future__ import annotations

from hum.ir import BufferAssignment, IR, MemRegion, Mutability, StateAssignment

# All audio samples are float32 (4 bytes)
_BYTES_PER_SAMPLE = 4
_ALIGNMENT = 4


def _align(offset: int, alignment: int = _ALIGNMENT) -> int:
    """Round *offset* up to the nearest multiple of *alignment*."""
    rem = offset % alignment
    return offset if rem == 0 else offset + (alignment - rem)


def _region_for_flags(regions: list[MemRegion], flags: list[str]) -> int:
    """Return the region_id best matching *flags*, falling back to the first region."""
    if flags:
        for r in regions:
            if all(f in r.flags for f in flags):
                return r.region_id
    return regions[0].region_id if regions else 0


def allocate(ir: IR) -> None:
    """Assign buffers (edge.buffer) and state (ir.state_assignments) in *ir*.

    Mutates the IR in place.
    """
    regions = ir.memory_regions
    if not regions:
        regions = [
            MemRegion(region_id=0, name="control", size=256 * 1024, flags=[]),
            MemRegion(region_id=1, name="audio",   size=4 * 1024 * 1024, flags=[]),
        ]

    # Audio buffers go to the last declared region; all others are control.
    audio_region_id = regions[-1].region_id
    ctrl_regions    = regions[:-1] if len(regions) > 1 else regions

    # Track current byte offset within each region (audio starts at 0).
    region_offset: dict[int, int] = {r.region_id: 0 for r in regions}

    def _alloc(region_id: int, size: int) -> int:
        """Allocate *size* aligned bytes in *region_id*; return the start offset."""
        off = _align(region_offset.get(region_id, 0))
        region_offset[region_id] = off + size
        return off

    # ── Signal buffers (one per producer output slot) ────────────────────────
    # Fanout edges from the same source endpoint alias one buffer.  This is the
    # actual graph semantics: an output slot produces one signal that may have
    # many consumers.  The old one-buffer-per-edge allocation left all but one
    # runtime fanout consumer reading buffers that the producer never wrote.
    source_buffers: dict[tuple[int, int], BufferAssignment] = {}
    for edge_id, edge in enumerate(ir.edges):
        key = (edge.src_node, edge.src_pin)
        existing = source_buffers.get(key)
        if existing is not None:
            edge.buffer = existing
            continue

        pt     = edge.pin_type
        size   = pt.channels * pt.block_size * _BYTES_PER_SAMPLE
        offset = _alloc(audio_region_id, size)
        buf = BufferAssignment(
            edge_id=edge_id,
            region_id=audio_region_id,
            offset=offset,
            size=size,
        )
        source_buffers[key] = buf
        edge.buffer = buf

    # ── Shadow buffers (one per feedback-source port, audio arena) ───────────
    # Allocated after all transient edge buffers to guarantee no aliasing.
    for sp_id, sp in enumerate(ir.shadow_ports):
        # Find a feedback edge for this port to get its pin_type (all edges
        # from the same port share the same type, verified by pins_compatible).
        ref_edge = next(
            e for e in ir.edges
            if e.feedback_wire and e.shadow_port_id == sp_id
        )
        pt   = ref_edge.pin_type
        size = pt.channels * pt.block_size * _BYTES_PER_SAMPLE
        offset = _alloc(audio_region_id, size)
        sp.buffer = BufferAssignment(
            edge_id=sp_id,   # repurposed: shadow port index
            region_id=audio_region_id,
            offset=offset,
            size=size,
        )

    # ── Node state + param-copy (control arena only) ──────────────────────────
    ir.state_assignments = []
    for node_idx, node in enumerate(ir.nodes):
        desc = node.descriptor

        # State memory
        state_region = _region_for_flags(ctrl_regions, desc.state_mem_flags)
        if desc.state_size > 0:
            state_offset = _alloc(state_region, desc.state_size)
        else:
            state_offset = 0

        # Param-copy memory (for parameterised nodes like FIRFilter)
        total_pc_size = sum(pc.size for pc in desc.param_copies)
        if total_pc_size > 0:
            pc_region = _region_for_flags(
                ctrl_regions,
                desc.param_copies[0].mem_flags if desc.param_copies else [],
            )
            pc_offset = _alloc(pc_region, total_pc_size)
        else:
            pc_offset  = -1
            total_pc_size = 0

        ir.state_assignments.append(StateAssignment(
            node_index=node_idx,
            region_id=state_region,
            state_offset=state_offset,
            param_copy_offset=pc_offset,
            param_copy_size=total_pc_size,
        ))

    ir.region_high_water = dict(region_offset)
