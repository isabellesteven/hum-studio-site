"""Python reference DSP implementations for node testing.

These implement the same algorithms used in the C nodes using pure Python/NumPy.
Used exclusively for testing — not optimized for production.

All filter coefficient formulas follow the Audio EQ Cookbook (R. Bristow-Johnson).
Biquad implementation: Direct Form II Transposed.
"""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np


# ---------------------------------------------------------------------------
# Biquad Direct Form II Transposed
# ---------------------------------------------------------------------------

def biquad_df2t(b0: float, b1: float, b2: float,
                a1: float, a2: float,
                x: np.ndarray) -> np.ndarray:
    """Process a single biquad stage.  Coefficients in normalized form (a0=1)."""
    w1, w2 = 0.0, 0.0
    y = np.empty_like(x)
    for i in range(len(x)):
        xi = float(x[i])
        yi = b0 * xi + w1
        w1 = b1 * xi - a1 * yi + w2
        w2 = b2 * xi - a2 * yi
        y[i] = yi
    return y


def biquad_cascade_df2t(stages: Sequence[tuple[float, float, float, float, float]],
                        x: np.ndarray) -> np.ndarray:
    """Process a cascade of biquad stages in sequence."""
    y = x.copy()
    for coeffs in stages:
        y = biquad_df2t(*coeffs, y)
    return y


# ---------------------------------------------------------------------------
# Coefficient computation (Audio EQ Cookbook)
# ---------------------------------------------------------------------------

def biquad_lp_coeffs(freq: float, q: float, sr: float) -> tuple[float, ...]:
    """Lowpass biquad coefficients."""
    w0    = 2.0 * math.pi * freq / sr
    cw    = math.cos(w0)
    alpha = math.sin(w0) / (2.0 * q)
    b1    = 1.0 - cw
    b0    = b1 * 0.5
    b2    = b0
    a0    = 1.0 + alpha
    a1    = -2.0 * cw
    a2    = 1.0 - alpha
    return b0/a0, b1/a0, b2/a0, a1/a0, a2/a0


def biquad_hp_coeffs(freq: float, q: float, sr: float) -> tuple[float, ...]:
    """Highpass biquad coefficients."""
    w0    = 2.0 * math.pi * freq / sr
    cw    = math.cos(w0)
    alpha = math.sin(w0) / (2.0 * q)
    b1    = -(1.0 + cw)
    b0    = -b1 * 0.5
    b2    = b0
    a0    = 1.0 + alpha
    a1    = -2.0 * cw
    a2    = 1.0 - alpha
    return b0/a0, b1/a0, b2/a0, a1/a0, a2/a0


def biquad_bp_coeffs(freq: float, q: float, sr: float) -> tuple[float, ...]:
    """Bandpass biquad coefficients (peak gain = Q)."""
    w0    = 2.0 * math.pi * freq / sr
    sw    = math.sin(w0)
    alpha = sw / (2.0 * q)
    b0    = sw * 0.5
    b1    = 0.0
    b2    = -b0
    a0    = 1.0 + alpha
    a1    = -2.0 * math.cos(w0)
    a2    = 1.0 - alpha
    return b0/a0, b1/a0, b2/a0, a1/a0, a2/a0


def biquad_ap_coeffs(freq: float, q: float, sr: float) -> tuple[float, ...]:
    """Allpass biquad coefficients."""
    w0    = 2.0 * math.pi * freq / sr
    alpha = math.sin(w0) / (2.0 * q)
    cw    = math.cos(w0)
    a0    =  1.0 + alpha
    b0    =  1.0 - alpha
    b1    = -2.0 * cw
    b2    =  1.0 + alpha
    a1    = -2.0 * cw
    a2    =  1.0 - alpha
    return b0/a0, b1/a0, b2/a0, a1/a0, a2/a0


def biquad_pk_coeffs(freq: float, q: float, gain_db: float, sr: float) -> tuple[float, ...]:
    """Peaking EQ biquad coefficients."""
    A     = 10.0 ** (gain_db / 40.0)
    w0    = 2.0 * math.pi * freq / sr
    sw    = math.sin(w0)
    cw    = math.cos(w0)
    alpha = sw / (2.0 * q)
    b0    = 1.0 + alpha * A
    b1    = -2.0 * cw
    b2    = 1.0 - alpha * A
    a0    = 1.0 + alpha / A
    a1    = -2.0 * cw
    a2    = 1.0 - alpha / A
    return b0/a0, b1/a0, b2/a0, a1/a0, a2/a0


def biquad_ls_coeffs(freq: float, gain_db: float, sr: float) -> tuple[float, ...]:
    """Low shelf biquad coefficients (slope=1)."""
    A     = 10.0 ** (gain_db / 40.0)
    w0    = 2.0 * math.pi * freq / sr
    cw    = math.cos(w0)
    sw    = math.sin(w0)
    alpha = sw * 0.5 * math.sqrt((A + 1.0/A) * (1.0/1.0 - 1.0) + 2.0)
    sq    = 2.0 * math.sqrt(A) * alpha
    b0    =  A * ((A + 1.0) - (A - 1.0)*cw + sq)
    b1    =  2.0 * A * ((A - 1.0) - (A + 1.0)*cw)
    b2    =  A * ((A + 1.0) - (A - 1.0)*cw - sq)
    a0    =  (A + 1.0) + (A - 1.0)*cw + sq
    a1    = -2.0 * ((A - 1.0) + (A + 1.0)*cw)
    a2    =  (A + 1.0) + (A - 1.0)*cw - sq
    return b0/a0, b1/a0, b2/a0, a1/a0, a2/a0


def biquad_hs_coeffs(freq: float, gain_db: float, sr: float) -> tuple[float, ...]:
    """High shelf biquad coefficients (slope=1)."""
    A     = 10.0 ** (gain_db / 40.0)
    w0    = 2.0 * math.pi * freq / sr
    cw    = math.cos(w0)
    sw    = math.sin(w0)
    alpha = sw * 0.5 * math.sqrt((A + 1.0/A) * (1.0/1.0 - 1.0) + 2.0)
    sq    = 2.0 * math.sqrt(A) * alpha
    b0    =  A * ((A + 1.0) + (A - 1.0)*cw + sq)
    b1    = -2.0 * A * ((A - 1.0) + (A + 1.0)*cw)
    b2    =  A * ((A + 1.0) + (A - 1.0)*cw - sq)
    a0    =  (A + 1.0) - (A - 1.0)*cw + sq
    a1    =  2.0 * ((A - 1.0) - (A + 1.0)*cw)
    a2    =  (A + 1.0) - (A - 1.0)*cw - sq
    return b0/a0, b1/a0, b2/a0, a1/a0, a2/a0


# ---------------------------------------------------------------------------
# DCBlock reference
# ---------------------------------------------------------------------------

def dcblock(r: float, x: np.ndarray) -> np.ndarray:
    """DC blocker: y[n] = x[n] - x[n-1] + r * y[n-1]."""
    y = np.empty_like(x)
    xp, yp = 0.0, 0.0
    for i in range(len(x)):
        xi = float(x[i])
        yi = xi - xp + r * yp
        y[i] = yi
        xp = xi; yp = yi
    return y


# ---------------------------------------------------------------------------
# ImpulseGen reference
# ---------------------------------------------------------------------------

def impulse_gen(period: int, amplitude: float, n_samples: int) -> np.ndarray:
    """Generate a periodic impulse train."""
    out = np.zeros(n_samples, dtype=np.float32)
    for i in range(n_samples):
        if i % period == 0:
            out[i] = amplitude
    return out


# ---------------------------------------------------------------------------
# PolyBlepOsc reference
# ---------------------------------------------------------------------------

def _poly_blep(t: float, dt: float) -> float:
    """PolyBLEP step-discontinuity residual (t, dt normalized to [0,1) phase)."""
    if t < dt:
        t /= dt
        return t + t - t * t - 1.0
    elif t > 1.0 - dt:
        t = (t - 1.0) / dt
        return t * t + t + t + 1.0
    return 0.0


def polyblep_osc(waveform: int, freq: float, amplitude: float,
                 n_samples: int, sr: float) -> np.ndarray:
    """Classic PolyBLEP oscillator reference.

    waveform: 0=sine, 1=saw, 2=square, 3=triangle (clamped to range).
    Mirrors the C node in runtime/nodes/node_generate.c (osc_process).
    """
    wf = int(max(0, min(3, waveform)))
    out = np.zeros(n_samples, dtype=np.float32)
    phase = 0.0
    tri = 0.0
    dt = freq / sr
    if dt < 0.0:
        dt = 0.0
    if dt > 0.5:
        dt = 0.5
    for i in range(n_samples):
        t = phase
        if wf == 1:                                  # saw
            v = 2.0 * t - 1.0
            v -= _poly_blep(t, dt)
        elif wf == 2:                                # square
            v = 1.0 if t < 0.5 else -1.0
            v += _poly_blep(t, dt)
            t2 = t + 0.5
            if t2 >= 1.0:
                t2 -= 1.0
            v -= _poly_blep(t2, dt)
        elif wf == 3:                                # triangle
            sq = 1.0 if t < 0.5 else -1.0
            sq += _poly_blep(t, dt)
            t2 = t + 0.5
            if t2 >= 1.0:
                t2 -= 1.0
            sq -= _poly_blep(t2, dt)
            tri = (1.0 - dt) * tri + dt * sq
            v = 4.0 * tri
        else:                                        # sine
            v = math.sin(2.0 * math.pi * t)
        out[i] = amplitude * v
        phase += dt
        if phase >= 1.0:
            phase -= 1.0
    return out


def naive_saw(freq: float, amplitude: float, n_samples: int, sr: float) -> np.ndarray:
    """Aliasing (non-band-limited) sawtooth — for anti-aliasing comparison tests."""
    out = np.zeros(n_samples, dtype=np.float32)
    phase = 0.0
    dt = freq / sr
    for i in range(n_samples):
        out[i] = amplitude * (2.0 * phase - 1.0)
        phase += dt
        if phase >= 1.0:
            phase -= 1.0
    return out


# ---------------------------------------------------------------------------
# Delay line reference
# ---------------------------------------------------------------------------

def delay_line(x: np.ndarray, delay_samples: int, wet: float = 1.0) -> np.ndarray:
    """Integer delay line with wet mix."""
    if delay_samples <= 0:
        return x.copy()
    n = len(x)
    y = np.zeros(n, dtype=x.dtype)
    for i in range(n):
        delayed = x[i - delay_samples] if i >= delay_samples else 0.0
        y[i] = x[i] * (1.0 - wet) + delayed * wet
    return y


# ---------------------------------------------------------------------------
# FIR filter reference
# ---------------------------------------------------------------------------

def fir_filter(taps: np.ndarray, x: np.ndarray) -> np.ndarray:
    """Causal FIR filter via direct convolution.  Output length == input length."""
    taps = np.asarray(taps, dtype=np.float64)
    x64  = x.astype(np.float64)
    y    = np.convolve(x64, taps, mode='full')[:len(x)]
    return y.astype(np.float32)


# ---------------------------------------------------------------------------
# Frequency response analysis helpers
# ---------------------------------------------------------------------------

def frequency_response(coeffs: tuple[float, ...], freqs: np.ndarray,
                        sr: float) -> np.ndarray:
    """Compute |H(e^jw)| for a single biquad stage using the z-transform.

    coeffs = (b0, b1, b2, a1, a2) in normalized form.
    Returns magnitude in linear scale.
    """
    b0, b1, b2, a1, a2 = coeffs
    w = 2.0 * np.pi * freqs / sr
    z = np.exp(1j * w)
    num = b0 + b1 * z**-1 + b2 * z**-2
    den = 1.0 + a1 * z**-1 + a2 * z**-2
    return np.abs(num / den)


def find_minus3db(coeffs: tuple[float, ...], sr: float,
                   f_low: float = 10.0, f_high: float | None = None,
                   n_points: int = 4096) -> float:
    """Find the -3 dB frequency of a lowpass/highpass biquad by bisection.

    Searches in the range [f_low, f_high] (default f_high = sr/2).
    Returns the frequency (Hz) where gain first drops below -3 dB
    (relative to DC for LP, or relative to Nyquist for HP).
    """
    if f_high is None:
        f_high = sr / 2.0
    freqs = np.geomspace(f_low, f_high, n_points)
    mag   = frequency_response(coeffs, freqs, sr)
    dc_gain = abs(sum(coeffs[:3]) / (1.0 + coeffs[3] + coeffs[4]))
    target  = dc_gain / (2.0 ** 0.5)  # -3 dB

    # Find first index where mag drops below target
    idx = np.argmax(mag < target)
    if idx == 0:
        return freqs[0]
    return float(freqs[idx])


def slope_db_per_octave(coeffs: tuple[float, ...], sr: float,
                         f_center: float, n_octaves: float = 1.0) -> float:
    """Estimate rolloff slope in dB/octave centered on f_center.

    Uses one octave span to measure slope.
    """
    f1 = f_center / (2.0 ** (n_octaves / 2.0))
    f2 = f_center * (2.0 ** (n_octaves / 2.0))
    freqs = np.array([f1, f2])
    mag   = frequency_response(coeffs, freqs, sr)
    db1   = 20.0 * math.log10(max(mag[0], 1e-20))
    db2   = 20.0 * math.log10(max(mag[1], 1e-20))
    return (db2 - db1) / n_octaves  # dB per octave
