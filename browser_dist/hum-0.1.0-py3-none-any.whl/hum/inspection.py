"""Developer-facing semantic inspection model for Hum graphs.

The runtime IR is optimized for validation, allocation, and blob emission.  This
module exposes a separate, versioned model for development tools: source
navigation, graph inspection, hover/completion context, profiling correlation,
and similar workflows.

The builder captures source/provenance facts while the AST is still available;
:func:`build_inspection` combines those facts with the fully-resolved IR after
shape resolution, scheduling, liveness, and allocation.
"""

from __future__ import annotations

import dataclasses
import json
from dataclasses import dataclass, field
from typing import Any, Optional

from hum.ir import IR, InstancePinSpec, Mutability, NodeInstance, PinType
from hum.manifest import NodeManifest


INSPECTION_SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# Source/provenance captured by the builder
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SourceSpan:
    """Half-open source span using 1-based line/column coordinates."""

    file: str
    line: int
    column: int
    end_line: int
    end_column: int

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass(frozen=True)
class GraphParamSource:
    name: str
    type_name: str
    source: SourceSpan


@dataclass(frozen=True)
class GraphSource:
    name: str
    source: SourceSpan
    params: tuple[GraphParamSource, ...] = ()


@dataclass(frozen=True)
class NodeSource:
    runtime_node_id: int
    instance_name: str
    instance_path: str
    parent_path: Optional[str]
    source_graph: str
    type_name: str
    fqn: str
    source: SourceSpan
    explicit_params: frozenset[str]
    manifest: NodeManifest


@dataclass(frozen=True)
class SubgraphSource:
    instance_name: str
    instance_path: str
    parent_path: Optional[str]
    source_graph: str
    type_name: str
    source: SourceSpan
    definition_source: SourceSpan
    arguments: dict[str, Any]


@dataclass(frozen=True)
class GraphPinSource:
    graph_name: str
    instance_path: Optional[str]
    name: str
    direction: str
    pin_type: PinType
    channels_any: bool
    source: SourceSpan


@dataclass(frozen=True)
class EdgeSource:
    source_graph: str
    instance_path: Optional[str]
    source: SourceSpan


@dataclass(frozen=True)
class ConnectionEndpointSource:
    kind: str  # "node" | "graph_input" | "graph_output"
    pin_name: str
    instance_path: Optional[str] = None
    slot: Optional[int] = None


@dataclass(frozen=True)
class ConnectionSource:
    source_graph: str
    instance_path: Optional[str]
    source_endpoint: ConnectionEndpointSource
    destination_endpoint: ConnectionEndpointSource
    feedback: bool
    feedback_init: float
    source: SourceSpan


@dataclass
class BuildMetadata:
    """Private compiler metadata needed to construct :class:`InspectionModel`.

    This is deliberately separate from :class:`hum.ir.IR`; it is tooling data,
    not runtime/blob state.
    """

    source_file: str
    graphs: dict[str, GraphSource] = field(default_factory=dict)
    nodes: dict[int, NodeSource] = field(default_factory=dict)
    subgraphs: list[SubgraphSource] = field(default_factory=list)
    graph_pins: list[GraphPinSource] = field(default_factory=list)
    edges: list[EdgeSource] = field(default_factory=list)
    connections: list[ConnectionSource] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Public inspection schema
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class InspectionProject:
    name: str
    entry: str


@dataclass(frozen=True)
class InspectionGraphParam:
    name: str
    type: str
    source: SourceSpan


@dataclass(frozen=True)
class InspectionGraph:
    name: str
    source: SourceSpan
    params: tuple[InspectionGraphParam, ...] = ()
    inputs: tuple["InspectionGraphPin", ...] = ()
    outputs: tuple["InspectionGraphPin", ...] = ()


@dataclass(frozen=True)
class InspectionPin:
    name: str
    direction: str
    index: int
    data_type: str
    channels: int
    block_size: int
    sample_rate: int
    variadic: bool = False
    resolved_count: int = 1
    channels_any: bool = False


@dataclass(frozen=True)
class InspectionParam:
    name: str
    type: str
    value: Any
    default: Any
    mutable: str
    minimum: Optional[float]
    maximum: Optional[float]
    compiler_source: Optional[str]
    explicit: bool


@dataclass(frozen=True)
class InspectionNode:
    runtime_node_id: int
    instance_name: str
    instance_path: str
    parent_path: Optional[str]
    source_graph: str
    type_name: str
    fqn: str
    type_id: int
    schedule_index: int
    description: str
    source: SourceSpan
    inputs: tuple[InspectionPin, ...]
    outputs: tuple[InspectionPin, ...]
    params: tuple[InspectionParam, ...]


@dataclass(frozen=True)
class InspectionSubgraph:
    instance_name: str
    instance_path: str
    parent_path: Optional[str]
    source_graph: str
    type_name: str
    source: SourceSpan
    definition_source: SourceSpan
    arguments: dict[str, Any]
    inputs: tuple["InspectionGraphPin", ...] = ()
    outputs: tuple["InspectionGraphPin", ...] = ()


@dataclass(frozen=True)
class InspectionGraphPin:
    name: str
    direction: str
    index: int
    data_type: str
    channels: int
    block_size: int
    sample_rate: int
    source: Optional[SourceSpan]


@dataclass(frozen=True)
class InspectionEndpoint:
    """One endpoint of a flattened runtime edge."""

    kind: str  # "node" | "graph_input" | "graph_output"
    pin_name: str
    pin_index: int
    slot: Optional[int] = None
    runtime_node_id: Optional[int] = None
    instance_path: Optional[str] = None


@dataclass(frozen=True)
class InspectionSignal:
    data_type: str
    channels: int
    block_size: int
    sample_rate: int


@dataclass(frozen=True)
class InspectionEdge:
    edge_id: int
    source_endpoint: InspectionEndpoint
    destination_endpoint: InspectionEndpoint
    signal: InspectionSignal
    feedback: bool
    feedback_init: float
    source_graph: Optional[str]
    instance_path: Optional[str]
    source: Optional[SourceSpan]


@dataclass(frozen=True)
class InspectionSourceEndpoint:
    kind: str
    pin_name: str
    instance_path: Optional[str] = None
    slot: Optional[int] = None


@dataclass(frozen=True)
class InspectionConnection:
    """Source-level connection before subgraphs are flattened."""

    connection_id: int
    source_graph: str
    instance_path: Optional[str]
    source_endpoint: InspectionSourceEndpoint
    destination_endpoint: InspectionSourceEndpoint
    feedback: bool
    feedback_init: float
    source: SourceSpan


@dataclass(frozen=True)
class InspectionModel:
    schema_version: int
    project: InspectionProject
    sample_rate: int
    fundamental_block: int
    block_divisor: int
    graphs: tuple[InspectionGraph, ...]
    subgraphs: tuple[InspectionSubgraph, ...]
    nodes: tuple[InspectionNode, ...]
    connections: tuple[InspectionConnection, ...]
    edges: tuple[InspectionEdge, ...]
    graph_inputs: tuple[InspectionGraphPin, ...]
    graph_outputs: tuple[InspectionGraphPin, ...]
    schedule: tuple[int, ...]

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-ready representation of this schema version."""
        return dataclasses.asdict(self)

    def to_json(self, *, indent: Optional[int] = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


# ---------------------------------------------------------------------------
# Model construction
# ---------------------------------------------------------------------------

def _pin_type_fields(pin_type: Optional[PinType]) -> tuple[str, int, int, int]:
    if pin_type is None:
        return ("unknown", 0, 0, 0)
    return (
        pin_type.data_type.value,
        pin_type.channels,
        pin_type.block_size,
        pin_type.sample_rate,
    )


def _inspection_pin(spec: InstancePinSpec, direction: str) -> InspectionPin:
    data_type, channels, block_size, sample_rate = _pin_type_fields(spec.pin_type)
    return InspectionPin(
        name=spec.name,
        direction=direction,
        index=spec.index,
        data_type=data_type,
        channels=channels,
        block_size=block_size,
        sample_rate=sample_rate,
        variadic=spec.variadic,
        resolved_count=spec.resolved_count,
        channels_any=spec.channels_any,
    )


def _inspection_params(node: NodeInstance, src: Optional[NodeSource]) -> tuple[InspectionParam, ...]:
    manifest_by_name = {p.name: p for p in src.manifest.params} if src is not None else {}
    result: list[InspectionParam] = []
    for name, value in node.params.items():
        spec = manifest_by_name.get(name)
        mut = node.param_mutability.get(name, Mutability.CONST)
        lo, hi = node.param_ranges.get(name, (None, None))
        result.append(InspectionParam(
            name=name,
            type=spec.param_type if spec is not None else type(value).__name__,
            value=value,
            default=spec.default if spec is not None else None,
            mutable=mut.value if isinstance(mut, Mutability) else str(mut),
            minimum=lo,
            maximum=hi,
            compiler_source=spec.source if spec is not None else None,
            explicit=(name in src.explicit_params) if src is not None else False,
        ))
    return tuple(result)


def _pin_for_edge(node: NodeInstance, pin_index: int, *, output: bool) -> tuple[str, Optional[int]]:
    specs = node.output_pins if output else node.input_pins
    for spec in specs:
        if spec.variadic:
            if 0 <= pin_index < spec.resolved_count:
                return spec.name, pin_index
        elif spec.index == pin_index:
            return spec.name, None
    return f"pin[{pin_index}]", None


def _edge_endpoint(ir: IR, node_idx: int, pin_idx: int, *, source: bool) -> InspectionEndpoint:
    if node_idx < 0:
        pins = ir.graph_inputs if source else ir.graph_outputs
        if 0 <= pin_idx < len(pins):
            name = pins[pin_idx].name
        else:
            name = f"pin[{pin_idx}]"
        return InspectionEndpoint(
            kind="graph_input" if source else "graph_output",
            pin_name=name,
            pin_index=pin_idx,
        )

    node = ir.nodes[node_idx]
    name, slot = _pin_for_edge(node, pin_idx, output=source)
    return InspectionEndpoint(
        kind="node",
        runtime_node_id=node_idx,
        instance_path=node.name,
        pin_name=name,
        pin_index=pin_idx,
        slot=slot,
    )


def _graph_pin_source(
    metadata: BuildMetadata,
    *,
    graph_name: str,
    instance_path: Optional[str],
    name: str,
    direction: str,
) -> Optional[SourceSpan]:
    for pin in metadata.graph_pins:
        if (
            pin.graph_name == graph_name
            and pin.instance_path == instance_path
            and pin.name == name
            and pin.direction == direction
        ):
            return pin.source
    return None


def build_inspection(ir: IR, metadata: BuildMetadata, project: Any) -> InspectionModel:
    """Build the public tooling model from a fully-resolved IR + builder metadata."""

    def source_graph_pins(graph_name: str, direction: str) -> tuple[InspectionGraphPin, ...]:
        # A reusable graph may be expanded more than once.  Its declaration
        # pins are identical across instances, so keep the first resolved copy.
        seen: set[str] = set()
        out: list[InspectionGraphPin] = []
        for pin in metadata.graph_pins:
            if pin.graph_name != graph_name or pin.direction != direction or pin.name in seen:
                continue
            seen.add(pin.name)
            out.append(InspectionGraphPin(
                name=pin.name,
                direction=direction,
                index=len(out),
                data_type=pin.pin_type.data_type.value,
                channels=pin.pin_type.channels,
                block_size=pin.pin_type.block_size,
                sample_rate=pin.pin_type.sample_rate,
                source=pin.source,
            ))
        return tuple(out)

    def instance_graph_pins(instance_path: str, direction: str) -> tuple[InspectionGraphPin, ...]:
        out: list[InspectionGraphPin] = []
        for pin in metadata.graph_pins:
            if pin.instance_path != instance_path or pin.direction != direction:
                continue
            out.append(InspectionGraphPin(
                name=pin.name,
                direction=direction,
                index=len(out),
                data_type=pin.pin_type.data_type.value,
                channels=pin.pin_type.channels,
                block_size=pin.pin_type.block_size,
                sample_rate=pin.pin_type.sample_rate,
                source=pin.source,
            ))
        return tuple(out)

    graphs = tuple(
        InspectionGraph(
            name=g.name,
            source=g.source,
            params=tuple(
                InspectionGraphParam(name=p.name, type=p.type_name, source=p.source)
                for p in g.params
            ),
            inputs=source_graph_pins(g.name, "input"),
            outputs=source_graph_pins(g.name, "output"),
        )
        for g in metadata.graphs.values()
    )

    nodes: list[InspectionNode] = []
    for node_idx, node in enumerate(ir.nodes):
        src = metadata.nodes.get(node_idx)
        instance_name = src.instance_name if src is not None else node.name.rsplit(".", 1)[-1]
        instance_path = src.instance_path if src is not None else node.name
        parent_path = src.parent_path if src is not None else (node.name.rpartition(".")[0] or None)
        source_graph = src.source_graph if src is not None else "main"
        type_name = src.type_name if src is not None else f"0x{node.type_id:08x}"
        fqn = src.fqn if src is not None else type_name
        source_span = src.source if src is not None else SourceSpan(metadata.source_file, 1, 1, 1, 1)
        description = src.manifest.description if src is not None else ""
        nodes.append(InspectionNode(
            runtime_node_id=node_idx,
            instance_name=instance_name,
            instance_path=instance_path,
            parent_path=parent_path,
            source_graph=source_graph,
            type_name=type_name,
            fqn=fqn,
            type_id=node.type_id,
            schedule_index=node.schedule_index,
            description=description,
            source=source_span,
            inputs=tuple(_inspection_pin(p, "input") for p in node.input_pins),
            outputs=tuple(_inspection_pin(p, "output") for p in node.output_pins),
            params=_inspection_params(node, src),
        ))

    subgraphs = tuple(
        InspectionSubgraph(
            instance_name=s.instance_name,
            instance_path=s.instance_path,
            parent_path=s.parent_path,
            source_graph=s.source_graph,
            type_name=s.type_name,
            source=s.source,
            definition_source=s.definition_source,
            arguments=s.arguments,
            inputs=instance_graph_pins(s.instance_path, "input"),
            outputs=instance_graph_pins(s.instance_path, "output"),
        )
        for s in metadata.subgraphs
    )

    graph_inputs = tuple(
        InspectionGraphPin(
            name=pin.name,
            direction="input",
            index=i,
            data_type=pin.pin_type.data_type.value,
            channels=pin.pin_type.channels,
            block_size=pin.pin_type.block_size,
            sample_rate=pin.pin_type.sample_rate,
            source=_graph_pin_source(
                metadata, graph_name="main", instance_path=None,
                name=pin.name, direction="input",
            ),
        )
        for i, pin in enumerate(ir.graph_inputs)
    )
    graph_outputs = tuple(
        InspectionGraphPin(
            name=pin.name,
            direction="output",
            index=i,
            data_type=pin.pin_type.data_type.value,
            channels=pin.pin_type.channels,
            block_size=pin.pin_type.block_size,
            sample_rate=pin.pin_type.sample_rate,
            source=_graph_pin_source(
                metadata, graph_name="main", instance_path=None,
                name=pin.name, direction="output",
            ),
        )
        for i, pin in enumerate(ir.graph_outputs)
    )

    edges: list[InspectionEdge] = []
    for edge_id, edge in enumerate(ir.edges):
        sig = edge.pin_type
        edge_src = metadata.edges[edge_id] if edge_id < len(metadata.edges) else None
        edges.append(InspectionEdge(
            edge_id=edge_id,
            source_endpoint=_edge_endpoint(ir, edge.src_node, edge.src_pin, source=True),
            destination_endpoint=_edge_endpoint(ir, edge.dst_node, edge.dst_pin, source=False),
            signal=InspectionSignal(
                data_type=sig.data_type.value,
                channels=sig.channels,
                block_size=sig.block_size,
                sample_rate=sig.sample_rate,
            ),
            feedback=edge.feedback_wire,
            feedback_init=edge.feedback_init,
            source_graph=edge_src.source_graph if edge_src else None,
            instance_path=edge_src.instance_path if edge_src else None,
            source=edge_src.source if edge_src else None,
        ))

    connections = tuple(
        InspectionConnection(
            connection_id=i,
            source_graph=c.source_graph,
            instance_path=c.instance_path,
            source_endpoint=InspectionSourceEndpoint(
                kind=c.source_endpoint.kind,
                pin_name=c.source_endpoint.pin_name,
                slot=c.source_endpoint.slot,
                instance_path=c.source_endpoint.instance_path,
            ),
            destination_endpoint=InspectionSourceEndpoint(
                kind=c.destination_endpoint.kind,
                pin_name=c.destination_endpoint.pin_name,
                slot=c.destination_endpoint.slot,
                instance_path=c.destination_endpoint.instance_path,
            ),
            feedback=c.feedback,
            feedback_init=c.feedback_init,
            source=c.source,
        )
        for i, c in enumerate(metadata.connections)
    )

    return InspectionModel(
        schema_version=INSPECTION_SCHEMA_VERSION,
        project=InspectionProject(name=project.name, entry=metadata.source_file),
        sample_rate=ir.sample_rate,
        fundamental_block=ir.fundamental_block,
        block_divisor=ir.block_divisor,
        graphs=graphs,
        subgraphs=subgraphs,
        nodes=tuple(nodes),
        connections=connections,
        edges=tuple(edges),
        graph_inputs=graph_inputs,
        graph_outputs=graph_outputs,
        schedule=tuple(ir.schedule),
    )
