"""Hum error types, collector, and formatting.

All toolchain stages report errors through ``ErrorCollector``.  Errors are
collected per-stage so multiple problems are reported at once.  At the end
of each stage, call ``collector.raise_if_errors()`` to abort the pipeline.

Error codes are compiler diagnostics; DEVELOPMENT.md describes testing policy:
  E001–E019   File and import resolution
  E020–E039   Parse errors
  E040–E059   Node and manifest resolution
  E060–E079   Pin type validation
  E080–E099   Graph structure (cycles, unconnected pins)
  E100–E119   Resource allocation
  E120–E139   Blob serialization
  W001–W019   Memory hint warnings
  W020–W039   Performance warnings
  W040–W059   Compatibility warnings
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SourceLocation:
    file:   str
    line:   int
    column: int = 1


@dataclass
class HumError:
    code:       str              # e.g. "E021"
    message:    str
    location:   Optional[SourceLocation] = None
    notes:      list[str] = field(default_factory=list)
    hints:      list[str] = field(default_factory=list)
    is_warning: bool = False

    def __str__(self) -> str:
        kind = "warning" if self.is_warning else "error"
        prefix = f"{kind}[{self.code}]: {self.message}"
        if self.location:
            loc = f"  --> {self.location.file}:{self.location.line}:{self.location.column}"
            lines = [prefix, loc]
        else:
            lines = [prefix]
        for note in self.notes:
            lines.append(f"   = note: {note}")
        for hint in self.hints:
            lines.append(f"   = hint: {hint}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        d: dict = {"code": self.code, "message": self.message}
        if self.location:
            d["file"]   = self.location.file
            d["line"]   = self.location.line
            d["column"] = self.location.column
        if self.notes:
            d["notes"] = self.notes
        if self.hints:
            d["hints"] = self.hints
        return d


class CompileError(Exception):
    """Raised when one or more hard errors are collected during compilation."""

    def __init__(self, errors: list[HumError]) -> None:
        self.errors = errors
        super().__init__("\n".join(str(e) for e in errors))


class ErrorCollector:
    """Accumulates errors and warnings across a pipeline stage."""

    def __init__(self) -> None:
        self._errors:   list[HumError] = []
        self._warnings: list[HumError] = []

    # ── Reporting ────────────────────────────────────────────────────────────

    def error(
        self,
        code: str,
        message: str,
        location: Optional[SourceLocation] = None,
        notes: Optional[list[str]] = None,
        hints: Optional[list[str]] = None,
    ) -> None:
        self._errors.append(HumError(
            code=code,
            message=message,
            location=location,
            notes=notes or [],
            hints=hints or [],
        ))

    def warning(
        self,
        code: str,
        message: str,
        location: Optional[SourceLocation] = None,
        notes: Optional[list[str]] = None,
    ) -> None:
        self._warnings.append(HumError(
            code=code,
            message=message,
            location=location,
            notes=notes or [],
            is_warning=True,
        ))

    # ── State inspection ──────────────────────────────────────────────────────

    @property
    def errors(self) -> list[HumError]:
        return list(self._errors)

    @property
    def warnings(self) -> list[HumError]:
        return list(self._warnings)

    @property
    def has_errors(self) -> bool:
        return bool(self._errors)

    # ── Stage boundaries ──────────────────────────────────────────────────────

    def raise_if_errors(self) -> None:
        """Raise ``CompileError`` if any hard errors have been collected."""
        if self._errors:
            raise CompileError(list(self._errors))

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_json(self) -> str:
        items = [e.to_dict() for e in (self._errors + self._warnings)]
        return json.dumps(items, indent=2)

    # ── Display ───────────────────────────────────────────────────────────────

    def print_all(self) -> None:
        for w in self._warnings:
            print(str(w))
        for e in self._errors:
            print(str(e))
