"""Hum builder — converts Lark parse tree to a partially-filled IR.

The build phase now has explicit internal stage boundaries:
    Parser → Structural Builder → Shape Resolver → Resource Sizing
           → TypeChecker → TopoSort → Liveness → Allocator → Serializer

The structural builder resolves imports/defines and constructs raw IR
nodes/edges/pins.  Shape resolution makes every instance pin concrete before
resource descriptors run.  Schedule, liveness, and allocations remain later
pipeline stages.

DESIGN.md describes stage invariants; LANGUAGE.md and NODE_MANIFEST.md define the input contracts.
"""

from __future__ import annotations

import ast
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from lark import Token, Tree

from hum.errors import CompileError, ErrorCollector, HumError, SourceLocation
from hum.ir import (
    DataType,
    Edge,
    EdgeLiveness,
    GraphPin,
    InstancePinSpec,
    IR,
    Mutability,
    NodeDescriptor,
    NodeInstance,
    PinType,
    ShadowPort,
    pins_compatible,
)
from hum.manifest import (
    NodeManifest, invoke_descriptor, load_package, resolve_manifest_descriptor,
)
from hum.inspection import (
    BuildMetadata,
    ConnectionEndpointSource,
    ConnectionSource,
    EdgeSource,
    GraphParamSource,
    GraphPinSource,
    GraphSource,
    NodeSource,
    SourceSpan,
    SubgraphSource,
)
from hum.parser import parse
from hum.project import Project
from hum.shape_resolver import resolve_shapes


# ---------------------------------------------------------------------------
# Build context
# ---------------------------------------------------------------------------

@dataclass
class SubgraphPinInfo:
    """Wiring map produced when a subgraph definition is expanded inline.

    After expansion, subgraph boundary pins no longer exist as edges; instead
    parent connections are wired directly to the internal leaf nodes recorded
    here.
    """
    # named input pin  -> list[(internal_node_idx, pin_idx, PinType)]
    # A list because the same input pin may fan out to multiple internal consumers.
    inputs:  dict[str, list[tuple[int, int, PinType]]]
    # named output pin -> (internal_node_idx, pin_idx, PinType)
    # Always a single internal producer per output pin.
    outputs: dict[str, tuple[int, int, PinType]]
    # Declared subgraph boundary types are retained so a flattened parent
    # connection cannot bypass a fixed-width subgraph contract.
    input_types:  dict[str, PinType] = field(default_factory=dict)
    output_types: dict[str, PinType] = field(default_factory=dict)


@dataclass
class _BuildContext:
    source:          str
    project:         Project
    pkg_dirs:        dict[str, Path]          # namespace -> stdlib pkg dir (takes precedence)
    errors:          ErrorCollector
    defines:         dict[str, Any]           # resolved compile-time constants
    protected_defines: set[str]               # names local defines may not shadow
    manifests:       dict[str, NodeManifest]  # simple_name -> manifest (from imports)
    node_index:      dict[str, int]           # MANGLED name -> index in IR.nodes (shared across scopes)
    node_type_names: dict[str, str]           # MANGLED name -> manifest type_name (shared)
    node_explicit_params: dict[str, set[str]] # MANGLED name -> graph-authored param names (shared)
    pin_index:       dict[tuple[str, str], int]  # (pin_name, direction) -> list_index (scope-local)
    graph_defs:      dict[str, Tree]          # graph name -> graph_decl AST (subgraph definitions)
    subgraph_pins:   dict[str, SubgraphPinInfo]  # MANGLED inst name -> pin map (shared)
    expanding:       set[str]                 # graph type names currently being expanded (cycle guard)
    source_file:     str = "<source>"
    block_divisor:   int = 1
    name_prefix:     str = ""                 # prepended to all node names registered in this scope
    graph_name:      str = "main"             # source graph currently being expanded
    metadata:        BuildMetadata = field(default_factory=lambda: BuildMetadata("<source>"))


def _child_context(
    parent:        _BuildContext,
    inst_name:     str,
    extra_defines: dict[str, Any],
) -> _BuildContext:
    """Create a child context for expanding a subgraph instance.

    Shared (mutations visible to parent and siblings):
        node_index, node_type_names, subgraph_pins, manifests, errors,
        graph_defs, expanding
    Scoped-local (independent copy per expansion):
        pin_index, defines, name_prefix, block_divisor
    """
    child_defines = dict(parent.defines)
    child_defines.update(extra_defines)
    return _BuildContext(
        source=parent.source,
        project=parent.project,
        pkg_dirs=parent.pkg_dirs,
        errors=parent.errors,
        defines=child_defines,
        protected_defines=set(extra_defines),
        manifests=parent.manifests,
        node_index=parent.node_index,
        node_type_names=parent.node_type_names,
        node_explicit_params=parent.node_explicit_params,
        pin_index={},
        graph_defs=parent.graph_defs,
        subgraph_pins=parent.subgraph_pins,
        expanding=parent.expanding,
        source_file=parent.source_file,
        block_divisor=parent.block_divisor,
        name_prefix=parent.name_prefix + inst_name + ".",
        graph_name=parent.graph_name,
        metadata=parent.metadata,
    )


# ---------------------------------------------------------------------------
# Location / span helpers
# ---------------------------------------------------------------------------

def _loc(node: Token | Tree, source_file: str) -> SourceLocation:
    if isinstance(node, Token):
        return SourceLocation(
            file=source_file,
            line=node.line or 1,
            column=node.column or 1,
        )
    return SourceLocation(
        file=source_file,
        line=node.meta.line or 1,
        column=node.meta.column or 1,
    )


def _source_span(node: Token | Tree, source_file: str) -> SourceSpan:
    """Return a tooling source span while the parser's position data exists."""
    if isinstance(node, Token):
        line = node.line or 1
        column = node.column or 1
        end_line = getattr(node, "end_line", None) or line
        end_column = getattr(node, "end_column", None)
        if end_column is None:
            end_column = column + len(str(node))
        return SourceSpan(source_file, line, column, end_line, end_column)
    line = node.meta.line or 1
    column = node.meta.column or 1
    end_line = getattr(node.meta, "end_line", None) or line
    end_column = getattr(node.meta, "end_column", None) or column
    return SourceSpan(source_file, line, column, end_line, end_column)


def _span(tree: Tree, source: str) -> str:
    """Recover the source text for a tree (used for keyword-only rules with no
    terminal children, e.g. ``pin_dir``, ``data_type``, ``block_size_val``)."""
    return source[tree.meta.start_pos:tree.meta.end_pos].strip()


# ---------------------------------------------------------------------------
# Expression evaluator
# ---------------------------------------------------------------------------

def _eval_expr(
    tree: Tree,
    ctx: _BuildContext,
    lookup: Optional[Callable[[str, Token], Any]] = None,
) -> Any:
    """Evaluate an expression tree.

    ``lookup`` is used by ``_process_defines`` so forward references between
    definitions are independent of declaration order.  A bare name may resolve
    to any compile-time value (needed for bool/string graph params); arithmetic
    operators still require numeric operands.
    """
    d = tree.data
    if d == "int_lit":
        return int(str(tree.children[0]))
    if d == "float_lit":
        return float(str(tree.children[0]))
    if d == "name_ref":
        name = str(tree.children[0])
        if lookup is not None:
            return lookup(name, tree.children[0])
        if name not in ctx.defines:
            ctx.errors.error(
                "E020",
                f"undefined name '{name}' in expression",
                location=_loc(tree.children[0], ctx.source_file),
            )
            return 0
        return ctx.defines[name]
    if d == "neg":
        v = _eval_expr(tree.children[0], ctx, lookup)
        if not isinstance(v, (int, float)) or isinstance(v, bool):
            ctx.errors.error("E020", "unary '-' requires a numeric value", location=_loc(tree, ctx.source_file))
            return 0
        return -v
    if d == "add":
        a = _eval_expr(tree.children[0], ctx, lookup)
        b = _eval_expr(tree.children[1], ctx, lookup)
        if not _both_numeric(a, b):
            ctx.errors.error("E020", "'+' requires numeric operands", location=_loc(tree, ctx.source_file))
            return 0
        return a + b
    if d == "sub":
        a = _eval_expr(tree.children[0], ctx, lookup)
        b = _eval_expr(tree.children[1], ctx, lookup)
        if not _both_numeric(a, b):
            ctx.errors.error("E020", "'-' requires numeric operands", location=_loc(tree, ctx.source_file))
            return 0
        return a - b
    if d == "mul":
        a = _eval_expr(tree.children[0], ctx, lookup)
        b = _eval_expr(tree.children[1], ctx, lookup)
        if not _both_numeric(a, b):
            ctx.errors.error("E020", "'*' requires numeric operands", location=_loc(tree, ctx.source_file))
            return 0
        return a * b
    if d == "div":
        a = _eval_expr(tree.children[0], ctx, lookup)
        b = _eval_expr(tree.children[1], ctx, lookup)
        if not _both_numeric(a, b):
            ctx.errors.error("E020", "'/' requires numeric operands", location=_loc(tree, ctx.source_file))
            return 0
        if b == 0:
            ctx.errors.error(
                "E020",
                "division by zero in expression",
                location=_loc(tree, ctx.source_file),
            )
            return 1
        return a // b if isinstance(a, int) and isinstance(b, int) else a / b
    ctx.errors.error("E020", f"unknown expression node: {d}")
    return 0


def _both_numeric(a: Any, b: Any) -> bool:
    return (
        isinstance(a, (int, float)) and not isinstance(a, bool)
        and isinstance(b, (int, float)) and not isinstance(b, bool)
    )


# ---------------------------------------------------------------------------
# Param value parsing
# ---------------------------------------------------------------------------

def _load_binary_file(rel_path: str, project_dir: Path, ctx: _BuildContext) -> list[float]:
    full = project_dir / rel_path
    try:
        raw = full.read_bytes()
    except OSError:
        ctx.errors.error("E001", f"cannot open load() file: '{rel_path}'")
        return []
    if len(raw) % 4 != 0:
        ctx.errors.error(
            "E020",
            f"load() file '{rel_path}' has {len(raw)} bytes; float32 data requires a multiple of 4 bytes",
        )
        return []
    n = len(raw) // 4
    return list(struct.unpack(f"<{n}f", raw))


def _parse_param_value(pv_tree: Tree, ctx: _BuildContext) -> Any:
    """Convert a ``param_value`` tree into a Python value.

    Does *not* validate type or range against ``ParamSpec`` — that happens in
    ``_process_node_decl``.
    """
    child = pv_tree.children[0]

    if isinstance(child, Token):
        if child.type == "BOOL":
            return str(child) == "true"
        if child.type == "ESCAPED_STRING":
            return ast.literal_eval(str(child))
        return str(child)

    d = child.data
    if d == "load_call":
        rel_path = ast.literal_eval(str(child.children[0]))
        return _load_binary_file(rel_path, ctx.project.project_dir, ctx)
    if d == "design_call":
        ctx.errors.error(
            "E049",
            "design() is a v2 feature; not implemented in this toolchain version",
            location=_loc(child, ctx.source_file),
        )
        return None
    if d == "array_val":
        return [_parse_param_value(item, ctx) for item in child.children]
    # Expression tree (int_lit, float_lit, name_ref, add, sub, mul, div, neg)
    return _eval_expr(child, ctx)


def _extract_node_raw_params(node_decl: Tree, ctx: _BuildContext) -> dict[str, Any]:
    """Return the raw param name→value map from a node_decl's node_params block."""
    raw: dict[str, Any] = {}
    for c in node_decl.children[2:]:
        if isinstance(c, Tree) and c.data == "node_params":
            if c.children:
                for pa in c.children[0].children:
                    name_tok = pa.children[0]
                    name = str(name_tok)
                    if name in raw:
                        ctx.errors.error(
                            "E048",
                            f"duplicate parameter assignment '{name}'",
                            location=_loc(name_tok, ctx.source_file),
                        )
                        continue
                    raw[name] = _parse_param_value(pa.children[1], ctx)
            break
    return raw


# ---------------------------------------------------------------------------
# Pin type resolution helpers
# ---------------------------------------------------------------------------

_DATA_TYPE_MAP: dict[str, DataType] = {
    "float32":  DataType.FLOAT32,
    "fixed32":  DataType.FIXED32,
    "ufixed32": DataType.UFIXED32,
}

_MUTABILITY_MAP: dict[str, Mutability] = {
    "param":  Mutability.PARAM,
    "const":  Mutability.CONST,
    "array":  Mutability.ARRAY,
}


def _resolve_data_type(dt_tree: Tree, source: str) -> DataType:
    return _DATA_TYPE_MAP.get(_span(dt_tree, source), DataType.FLOAT32)


def _resolve_channels(cv_tree: Tree) -> int:
    # channels_val: INTEGER | "any"
    # "any" (no children) returns 0 — an adaptive width resolved in Phase 3.
    return int(str(cv_tree.children[0])) if cv_tree.children else 0


def _resolve_block_size(bsv_tree: Tree, source: str, fundamental_block: int) -> int:
    # block_size_val: INTEGER | "graph"
    return int(str(bsv_tree.children[0])) if bsv_tree.children else fundamental_block


def _pin_props_to_pin_type(pin_props: list[Tree], source: str, ctx: _BuildContext) -> PinType:
    """Build a ``PinType`` from the ordered ``pin_prop`` trees of a ``pin_decl``."""
    data_type  = DataType.FLOAT32
    channels   = 1
    block_size = ctx.project.fundamental_block

    seen: set[str] = set()
    for pp in pin_props:
        inner = pp.children[0]
        prop_name = inner.data
        if prop_name in seen:
            ctx.errors.error(
                "E048",
                f"duplicate pin property '{prop_name}'",
                location=_loc(pp, ctx.source_file),
            )
            continue
        seen.add(prop_name)
        if inner.data == "data_type":
            data_type = _resolve_data_type(inner, source)
        elif inner.data == "channels_val":
            channels = _resolve_channels(inner)
        elif inner.data == "block_size_val":
            block_size = _resolve_block_size(inner, source, ctx.project.fundamental_block)

    return PinType(
        data_type=data_type,
        channels=channels,
        block_size=block_size,
        sample_rate=ctx.project.sample_rate // ctx.block_divisor,
    )


def _pin_type_from_spec(spec_channels: int | str, spec_block_size: int | str,
                        data_type: DataType, ctx: _BuildContext) -> PinType:
    """Build a PinType from a manifest PinSpec's channels/block_size fields."""
    channels   = spec_channels   if isinstance(spec_channels,   int) else 0  # 0 = "any"
    block_size = spec_block_size if isinstance(spec_block_size, int) else ctx.project.fundamental_block
    return PinType(
        data_type=data_type,
        channels=channels,
        block_size=block_size,
        sample_rate=ctx.project.sample_rate // ctx.block_divisor,
    )


# ---------------------------------------------------------------------------
# Annotation helpers
# ---------------------------------------------------------------------------

def _annotation_mutability(annotations: list[Tree]) -> Optional[tuple[Mutability, Token]]:
    """Return the (mutability, name-token) of the first mutability annotation.

    The name token is returned so callers can locate diagnostics at the
    annotation site (e.g. ``@param`` on a const param).
    """
    for ann in annotations:
        name_tok = ann.children[0]
        name     = str(name_tok).lower()
        if name in _MUTABILITY_MAP:
            return _MUTABILITY_MAP[name], name_tok
    return None


def _resolve_param_mutability(
    spec, requested: Optional[Mutability], tok: Optional[Token],
    val: Any, inst_name: str, ctx: _BuildContext,
) -> Mutability:
    """Resolve a param's runtime mutability from its graph annotation.

    Design: an *undecorated* param is a compile-time constant. A decoration
    (``@param`` / ``@array``) opts the param into tunability, but only within
    the capability the node's manifest declares — ``spec.mutable`` is the
    ceiling — and only when the annotation matches the param's kind (scalar
    ``@param`` vs vector ``@array``). ``@const`` is always permitted.
    """
    # No annotation → compile-time constant, regardless of the manifest ceiling.
    if requested is None or requested is Mutability.CONST:
        return Mutability.CONST

    loc      = _loc(tok, ctx.source_file)
    is_array = isinstance(val, list)

    # Ceiling: the node author may forbid tuning outright (structural const,
    # e.g. num_taps / channels feed compile-time sizing and cannot be tuned).
    if spec.mutable is Mutability.CONST:
        ctx.errors.error(
            "E046",
            f"node '{inst_name}': param '{spec.name}' is a compile-time constant "
            f"and cannot be made tunable",
            location=loc,
        )
        return Mutability.CONST

    # Kind: @param is scalar-only, @array is vector-only.
    if requested is Mutability.PARAM and is_array:
        ctx.errors.error(
            "E046",
            f"node '{inst_name}': param '{spec.name}' is an array; "
            f"use '@array' instead of '@param'",
            location=loc,
        )
        return Mutability.ARRAY   # recover as the correct kind
    if requested is Mutability.ARRAY and not is_array:
        ctx.errors.error(
            "E046",
            f"node '{inst_name}': param '{spec.name}' is a scalar; "
            f"use '@param' instead of '@array'",
            location=loc,
        )
        return Mutability.PARAM   # recover as the correct kind

    return requested


# ---------------------------------------------------------------------------
# Import processing
# ---------------------------------------------------------------------------

def _pkg_dir_for_namespace(ns: str, ctx: _BuildContext) -> Optional[Path]:
    """Resolve the package directory for a namespace, checking pkg_dirs first."""
    return ctx.pkg_dirs.get(ns) or ctx.project.dependency_paths().get(ns)


def _process_imports(import_nodes: list[Tree], ctx: _BuildContext) -> None:
    for imp in import_nodes:
        ns_tok    = imp.children[0]
        namespace = ast.literal_eval(str(ns_tok))

        pkg_dir = _pkg_dir_for_namespace(namespace, ctx)
        if pkg_dir is None:
            ctx.errors.error(
                "E001",
                f"package not found: '{namespace}'",
                location=_loc(ns_tok, ctx.source_file),
                hints=[f"Add a dependency for '{namespace}' in hum.toml"],
            )
            continue

        try:
            pkg_manifests = load_package(pkg_dir)
        except Exception as exc:
            ctx.errors.error(
                "E002",
                f"failed to load package '{namespace}': {exc}",
                location=_loc(ns_tok, ctx.source_file),
            )
            continue

        selective = [c for c in imp.children if isinstance(c, Tree) and c.data == "selective_import"]
        if selective:
            for name_tok in selective[0].children:
                name = str(name_tok)
                if name not in pkg_manifests:
                    ctx.errors.error(
                        "E002",
                        f"node '{name}' not found in package '{namespace}'",
                        location=_loc(name_tok, ctx.source_file),
                    )
                else:
                    if name in ctx.manifests:
                        ctx.errors.error(
                            "E048",
                            f"imported node name '{name}' conflicts with an earlier import",
                            location=_loc(name_tok, ctx.source_file),
                        )
                    else:
                        ctx.manifests[name] = pkg_manifests[name]
        else:
            for name, manifest in pkg_manifests.items():
                if name in ctx.manifests:
                    ctx.errors.error(
                        "E048",
                        f"imported node name '{name}' conflicts with an earlier import",
                        location=_loc(ns_tok, ctx.source_file),
                    )
                else:
                    ctx.manifests[name] = manifest


# ---------------------------------------------------------------------------
# Define processing
# ---------------------------------------------------------------------------

def _process_defines(define_nodes: list[Tree], ctx: _BuildContext) -> None:
    """Resolve a lexical batch of defines independent of declaration order."""
    pending: dict[str, tuple[Token, Tree]] = {}
    for defn in define_nodes:
        name_tok  = defn.children[0]
        name      = str(name_tok)
        expr_tree = defn.children[1]
        if name in pending:
            ctx.errors.error(
                "E048",
                f"duplicate define '{name}'",
                location=_loc(name_tok, ctx.source_file),
            )
            continue
        if name in ctx.protected_defines:
            ctx.errors.error(
                "E048",
                f"define '{name}' conflicts with a graph parameter of the same name",
                location=_loc(name_tok, ctx.source_file),
            )
            continue
        pending[name] = (name_tok, expr_tree)

    resolved: dict[str, Any] = {}
    resolving: set[str] = set()

    def resolve_name(name: str, tok: Token) -> Any:
        if name in resolved:
            return resolved[name]
        if name in pending:
            if name in resolving:
                ctx.errors.error(
                    "E020",
                    f"cyclic define reference involving '{name}'",
                    location=_loc(tok, ctx.source_file),
                )
                return 0
            resolving.add(name)
            value = _eval_expr(pending[name][1], ctx, resolve_name)
            resolving.discard(name)
            resolved[name] = value
            return value
        if name in ctx.defines:
            return ctx.defines[name]
        ctx.errors.error(
            "E020",
            f"undefined name '{name}' in expression",
            location=_loc(tok, ctx.source_file),
        )
        return 0

    for name, (tok, _) in pending.items():
        resolve_name(name, tok)
    ctx.defines.update(resolved)


def _coerce_typed_value(type_name: str, value: Any) -> tuple[bool, Any]:
    """Return ``(ok, coerced)`` for a scalar V1 compile-time value."""
    if type_name in ("float", "float32"):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return False, value
        return True, float(value)
    if type_name == "int":
        if isinstance(value, bool):
            return False, value
        if isinstance(value, int):
            return True, value
        if isinstance(value, float) and value.is_integer():
            return True, int(value)
        return False, value
    if type_name == "bool":
        return isinstance(value, bool), value
    if type_name == "string":
        return isinstance(value, str), value
    return False, value


def _param_placeholder(spec) -> Any:
    """Return a type-correct temporary value for a compiler-sourced param."""
    if spec.default is not None:
        return spec.default
    if spec.param_type in ("float", "float32"):
        return 0.0
    if spec.param_type == "int":
        return 0
    if spec.param_type == "bool":
        return False
    if spec.param_type == "string":
        return ""
    return None


def _validate_node_param_value(spec, value: Any, inst_name: str, ctx: _BuildContext) -> Any:
    """Validate/coerce one manifest parameter value, including array params."""
    expects_array = spec.mutable is Mutability.ARRAY or isinstance(spec.default, list)
    if expects_array:
        if not isinstance(value, list):
            ctx.errors.error(
                "E043",
                f"node '{inst_name}': param '{spec.name}' requires an array of {spec.param_type}",
            )
            return value
        out: list[Any] = []
        for i, item in enumerate(value):
            ok, coerced = _coerce_typed_value(spec.param_type, item)
            if not ok:
                ctx.errors.error(
                    "E043",
                    f"node '{inst_name}': param '{spec.name}[{i}]' requires {spec.param_type} "
                    f"but got {type(item).__name__}",
                )
                out.append(item)
            else:
                out.append(coerced)
        return out

    if isinstance(value, list):
        ctx.errors.error(
            "E043",
            f"node '{inst_name}': param '{spec.name}' requires scalar {spec.param_type} but got array",
        )
        return value
    ok, coerced = _coerce_typed_value(spec.param_type, value)
    if not ok:
        ctx.errors.error(
            "E043",
            f"node '{inst_name}': param '{spec.name}' requires {spec.param_type} "
            f"but got {type(value).__name__}",
        )
        return value
    return coerced


def _graph_signature(graph_decl: Tree, ctx: _BuildContext) -> list[tuple[str, str, Token]]:
    """Return ``[(name, type, token), ...]`` and diagnose duplicate params."""
    out: list[tuple[str, str, Token]] = []
    seen: set[str] = set()
    for child in graph_decl.children[1:-1]:
        if not isinstance(child, Tree) or child.data != "graph_param_list":
            continue
        for gp in child.children:
            name_tok = gp.children[0]
            name = str(name_tok)
            type_name = _span(gp.children[1], ctx.source)
            if name in seen:
                ctx.errors.error(
                    "E048",
                    f"duplicate graph parameter '{name}'",
                    location=_loc(name_tok, ctx.source_file),
                )
                continue
            seen.add(name)
            out.append((name, type_name, name_tok))
    return out


def _resolve_subgraph_arguments(
    graph_decl: Tree,
    node_decl: Tree,
    inst_name: str,
    ctx: _BuildContext,
) -> tuple[dict[str, Any], set[str]]:
    raw = _extract_node_raw_params(node_decl, ctx)
    signature = _graph_signature(graph_decl, ctx)
    by_name = {name: (type_name, tok) for name, type_name, tok in signature}

    for name in raw:
        if name not in by_name:
            ctx.errors.error(
                "E047",
                f"subgraph '{inst_name}': unknown argument '{name}'",
                location=_loc(node_decl.children[0], ctx.source_file),
            )

    resolved: dict[str, Any] = {}
    for name, type_name, tok in signature:
        if name not in raw:
            ctx.errors.error(
                "E047",
                f"subgraph '{inst_name}': missing required argument '{name}'",
                location=_loc(node_decl.children[0], ctx.source_file),
            )
            continue
        ok, value = _coerce_typed_value(type_name, raw[name])
        if not ok:
            ctx.errors.error(
                "E047",
                f"subgraph '{inst_name}': argument '{name}' requires {type_name} "
                f"but got {type(raw[name]).__name__}",
                location=_loc(tok, ctx.source_file),
            )
            continue
        resolved[name] = value
    return resolved, set(by_name)


# ---------------------------------------------------------------------------
# Pin declaration
# ---------------------------------------------------------------------------

def _process_pin_decl(pin_decl: Tree, ctx: _BuildContext, ir: IR) -> None:
    children  = pin_decl.children
    name_tok  = children[0]
    pin_name  = str(name_tok)
    pin_dir   = children[1]
    pin_props = [p for p in children[2:] if isinstance(p, Tree) and p.data == "pin_prop"]

    direction = _span(pin_dir, ctx.source)   # "input" or "output"
    key = (pin_name, direction)

    if key in ctx.pin_index:
        ctx.errors.error(
            "E060",
            f"duplicate graph pin name: '{pin_name}' ({direction})",
            location=_loc(name_tok, ctx.source_file),
        )
        return

    pin_type = _pin_props_to_pin_type(pin_props, ctx.source, ctx)
    channels_any = any(
        pp.children[0].data == "channels_val" and not pp.children[0].children
        for pp in pin_props
    )
    gp = GraphPin(
        name=pin_name,
        direction=direction,
        pin_type=pin_type,
        channels_any=channels_any,
    )

    if direction == "input":
        idx = len(ir.graph_inputs)
        ir.graph_inputs.append(gp)
    else:
        idx = len(ir.graph_outputs)
        ir.graph_outputs.append(gp)
    ctx.pin_index[key] = idx
    ctx.metadata.graph_pins.append(GraphPinSource(
        graph_name=ctx.graph_name,
        instance_path=ctx.name_prefix.rstrip(".") or None,
        name=pin_name,
        direction=direction,
        pin_type=pin_type,
        channels_any=channels_any,
        source=_source_span(pin_decl, ctx.metadata.source_file),
    ))


# ---------------------------------------------------------------------------
# Subgraph expansion
# ---------------------------------------------------------------------------

def _expand_subgraph(
    graph_decl:   Tree,
    mangled_name: str,
    child_ctx:    _BuildContext,
    ir:           IR,
) -> SubgraphPinInfo:
    """Expand a subgraph definition inline into *ir*.

    ``mangled_name`` is the fully-qualified instance name (e.g. ``"sf"``).
    All internal nodes are registered in ``ir`` using the child context's
    name prefix.  Returns a ``SubgraphPinInfo`` recording how the subgraph's
    named pins map to the internal leaf-node ports they resolve to.
    """
    graph_body = graph_decl.children[-1]

    # Sub-IR captures this subgraph's pin declarations so we know their types.
    # These pins are NOT added to the parent IR — they become wiring metadata only.
    sub_ir = IR(
        sample_rate=ir.sample_rate,
        fundamental_block=ir.fundamental_block,
        block_divisor=ir.block_divisor,
        memory_regions=list(ir.memory_regions),
    )

    # Pass 1 — graph-wide declarations.  Declaration order is not semantic:
    # block_divisor and defines are resolved before any pin/node is built.
    local_defines: list[Tree] = []
    divisor_decl: Optional[Tree] = None
    for item in graph_body.children:
        inner = item.children[0]
        if inner.data == "block_divisor_decl":
            if divisor_decl is not None:
                child_ctx.errors.error(
                    "E048",
                    "duplicate block_divisor declaration",
                    location=_loc(inner, child_ctx.source_file),
                )
            else:
                divisor_decl = inner
        elif inner.data == "define_decl":
            local_defines.append(inner)

    if divisor_decl is not None:
        divisor = int(str(divisor_decl.children[0]))
        if divisor <= 0:
            child_ctx.errors.error(
                "E089",
                "block_divisor must be greater than zero",
                location=_loc(divisor_decl, child_ctx.source_file),
            )
        else:
            sub_ir.block_divisor = divisor
            child_ctx.block_divisor = divisor
    _process_defines(local_defines, child_ctx)

    # Pass 2 — pin decls + node decls (nodes go into the parent ir)
    for item in graph_body.children:
        inner = item.children[0]
        if inner.data == "pin_decl":
            _process_pin_decl(inner, child_ctx, sub_ir)
        elif inner.data == "node_decl":
            _process_node_decl(inner, child_ctx, ir)

    # Build the pin-info skeleton from what was declared
    inputs:  dict[str, list[tuple[int, int, PinType]]] = {}
    outputs: dict[str, Optional[tuple[int, int, PinType]]] = {}
    input_types:  dict[str, PinType] = {}
    output_types: dict[str, PinType] = {}
    for (name, direction) in child_ctx.pin_index:
        if direction == "input":
            inputs[name] = []
            idx = child_ctx.pin_index[(name, direction)]
            input_types[name] = sub_ir.graph_inputs[idx].pin_type
        else:
            outputs[name] = None
            idx = child_ctx.pin_index[(name, direction)]
            output_types[name] = sub_ir.graph_outputs[idx].pin_type

    # Pass 3 — connections
    #   graph_pin_ref on src  → subgraph input fan-out  → record consumers in inputs[]
    #   graph_pin_ref on dst  → subgraph output driver   → record producer in outputs[]
    #   both node_pin_ref     → internal edge             → append to ir.edges
    for item in graph_body.children:
        inner = item.children[0]
        if inner.data != "connection":
            continue

        src_ref   = inner.children[0]
        # children[1] is the wire_op sub-tree; dst is children[2]
        wire_op   = inner.children[1]
        dst_ref   = inner.children[2]
        src_graph = src_ref.data == "graph_pin_ref"
        dst_graph = dst_ref.data == "graph_pin_ref"

        # Boundary connections are handled specially below rather than through
        # _process_connection(), so preserve their source-level form here.
        if src_graph or dst_graph:
            is_feedback = wire_op.data in ("feedback", "feedback_with_init")
            init_value = _extract_feedback_init(wire_op, child_ctx) if is_feedback else 0.0
            _record_source_connection(inner, child_ctx, is_feedback, init_value)

        if src_graph and not dst_graph:
            if wire_op.data != "regular":
                child_ctx.errors.error(
                    "E085",
                    "feedback wire (~>) cannot cross a subgraph boundary",
                    location=_loc(inner, child_ctx.source_file),
                )
                continue
            pin_name = str(src_ref.children[0])
            dst = _resolve_pin_ref(dst_ref, child_ctx, ir, is_src=False)
            if dst is None:
                continue
            dst_node, dst_pin, dst_pt = dst
            idx = child_ctx.pin_index.get((pin_name, "input"))
            if idx is None:
                child_ctx.errors.error(
                    "E062",
                    f"subgraph has no input pin '{pin_name}'",
                    location=_loc(src_ref.children[0], child_ctx.source_file),
                )
                continue
            src_pt = sub_ir.graph_inputs[idx].pin_type
            for err_str in pins_compatible(src_pt, dst_pt):
                code, msg = err_str.split(": ", 1)
                child_ctx.errors.error(code, msg, location=_loc(inner, child_ctx.source_file))
            # Preserve a concrete subgraph boundary contract in the flattened
            # leaf-node shape model.  channels_any on the leaf pin remains true,
            # so the Phase-3 resolver can still unify all adaptive pins on the
            # instance while treating this value as a hard constraint.
            if src_pt.channels > 0 and dst_pt.channels == 0:
                dst_pt.channels = src_pt.channels
            inputs.setdefault(pin_name, []).append((dst_node, dst_pin, dst_pt))

        elif not src_graph and dst_graph:
            if wire_op.data != "regular":
                child_ctx.errors.error(
                    "E085",
                    "feedback wire (~>) cannot cross a subgraph boundary",
                    location=_loc(inner, child_ctx.source_file),
                )
                continue
            pin_name = str(dst_ref.children[0])
            src = _resolve_pin_ref(src_ref, child_ctx, ir, is_src=True)
            if src is None:
                continue
            src_node, src_pin, src_pt = src
            idx = child_ctx.pin_index.get((pin_name, "output"))
            if idx is None:
                child_ctx.errors.error(
                    "E062",
                    f"subgraph has no output pin '{pin_name}'",
                    location=_loc(dst_ref.children[0], child_ctx.source_file),
                )
                continue
            dst_pt = sub_ir.graph_outputs[idx].pin_type
            for err_str in pins_compatible(src_pt, dst_pt):
                code, msg = err_str.split(": ", 1)
                child_ctx.errors.error(code, msg, location=_loc(inner, child_ctx.source_file))
            if dst_pt.channels > 0 and src_pt.channels == 0:
                src_pt.channels = dst_pt.channels
            if outputs.get(pin_name) is not None:
                child_ctx.errors.error(
                    "E083",
                    f"subgraph output pin '{pin_name}' has more than one driver",
                    location=_loc(inner, child_ctx.source_file),
                )
            else:
                outputs[pin_name] = (src_node, src_pin, src_pt)

        elif not src_graph and not dst_graph:
            _process_connection(inner, child_ctx, ir)

        else:
            child_ctx.errors.error(
                "E049",
                "direct graph-pin-to-graph-pin connections within a subgraph are not supported",
                location=_loc(inner, child_ctx.source_file),
            )

    for pin_name, producer in outputs.items():
        if producer is None:
            child_ctx.errors.error(
                "E082",
                f"subgraph output pin '{pin_name}' is not driven by any edge",
            )

    return SubgraphPinInfo(
        inputs=inputs,
        outputs=outputs,  # type: ignore[arg-type]
        input_types=input_types,
        output_types=output_types,
    )


# ---------------------------------------------------------------------------
# Node declaration
# ---------------------------------------------------------------------------

def _process_node_decl(node_decl: Tree, ctx: _BuildContext, ir: IR) -> None:
    children       = node_decl.children
    inst_name_tok  = children[0]
    type_name_tok  = children[1]
    inst_name      = str(inst_name_tok)
    type_name      = str(type_name_tok)
    mangled        = ctx.name_prefix + inst_name

    # Uniqueness (mangled so nested scopes don't collide with each other)
    if mangled in ctx.node_index:
        ctx.errors.error(
            "E040",
            f"duplicate node name: '{inst_name}'",
            location=_loc(inst_name_tok, ctx.source_file),
        )
        return

    # ── Subgraph type? ────────────────────────────────────────────────────────
    if type_name in ctx.graph_defs:
        if type_name in ctx.expanding:
            ctx.errors.error(
                "E049",
                f"recursive subgraph expansion: '{type_name}'",
                location=_loc(type_name_tok, ctx.source_file),
            )
            return
        ctx.expanding.add(type_name)
        graph_decl = ctx.graph_defs[type_name]
        graph_args, graph_param_names = _resolve_subgraph_arguments(
            graph_decl, node_decl, inst_name, ctx
        )
        child      = _child_context(ctx, inst_name, graph_args)
        child.graph_name = type_name
        child.protected_defines = graph_param_names
        ctx.metadata.subgraphs.append(SubgraphSource(
            instance_name=inst_name,
            instance_path=mangled,
            parent_path=ctx.name_prefix.rstrip(".") or None,
            source_graph=ctx.graph_name,
            type_name=type_name,
            source=_source_span(node_decl, ctx.metadata.source_file),
            definition_source=_source_span(graph_decl, ctx.metadata.source_file),
            arguments=dict(graph_args),
        ))
        pin_info   = _expand_subgraph(graph_decl, mangled, child, ir)
        ctx.subgraph_pins[mangled] = pin_info
        ctx.expanding.discard(type_name)
        return

    # ── Leaf node type lookup ─────────────────────────────────────────────────
    if type_name not in ctx.manifests:
        ctx.errors.error(
            "E041",
            f"unknown node type: '{type_name}'; did you import the package?",
            location=_loc(type_name_tok, ctx.source_file),
            hints=[f"Import the package containing '{type_name}'"],
        )
        return

    manifest = ctx.manifests[type_name]

    # ── Collect params from tree ──────────────────────────────────────────────
    raw_params: dict[str, Any]       = {}
    raw_mutability: dict[str, Mutability] = {}
    raw_mut_tok:    dict[str, Token]      = {}   # annotation site, for diagnostics

    node_params_tree: Optional[Tree] = None
    for c in children[2:]:
        if isinstance(c, Tree) and c.data == "node_params":
            node_params_tree = c
            break

    if node_params_tree is not None and node_params_tree.children:
        param_list = node_params_tree.children[0]   # Tree('param_assign_list')
        for pa in param_list.children:
            # pa: Tree('param_assign') with children [NAME, param_value, annotation*]
            p_name_tok = pa.children[0]
            p_val_tree = pa.children[1]
            p_anns     = [c for c in pa.children[2:] if isinstance(c, Tree) and c.data == "annotation"]
            p_name     = str(p_name_tok)
            if p_name in raw_params:
                ctx.errors.error(
                    "E048",
                    f"duplicate parameter assignment '{p_name}'",
                    location=_loc(p_name_tok, ctx.source_file),
                )
                continue
            raw_params[p_name] = _parse_param_value(p_val_tree, ctx)
            for ann in p_anns:
                ann_name = str(ann.children[0]).lower()
                if ann_name == "smooth":
                    ctx.errors.error(
                        "E044",
                        "@smooth is no longer supported; use @param instead",
                        location=_loc(ann.children[0], ctx.source_file),
                    )
                elif ann_name not in _MUTABILITY_MAP:
                    ctx.errors.error(
                        "E049",
                        f"unsupported parameter annotation '@{ann_name}'",
                        location=_loc(ann.children[0], ctx.source_file),
                    )
            ann_mut = _annotation_mutability(p_anns)
            if ann_mut is not None:
                raw_mutability[p_name], raw_mut_tok[p_name] = ann_mut

    # Node-level annotations are reserved syntax but have no V1 semantics yet.
    for c in children[2:]:
        if isinstance(c, Tree) and c.data == "annotation":
            ann_name = str(c.children[0])
            ctx.errors.error(
                "E049",
                f"node annotation '@{ann_name}' is reserved but not implemented",
                location=_loc(c.children[0], ctx.source_file),
            )

    # ── Resolve params against manifest ──────────────────────────────────────
    manifest_by_name = {s.name: s for s in manifest.params}
    resolved_params: dict[str, Any]       = {}
    resolved_mutability: dict[str, Mutability] = {}
    resolved_ranges: dict[str, tuple]    = {}

    for spec in manifest.params:
        supplied = spec.name in raw_params
        val = raw_params[spec.name] if supplied else (
            _param_placeholder(spec) if spec.source is not None else spec.default
        )
        val = _validate_node_param_value(spec, val, inst_name, ctx)
        # User-authored values retain the existing range-warning behavior.
        # Compiler-sourced placeholders are replaced after shape resolution.
        if (supplied or spec.source is None) and isinstance(val, (int, float)) and not isinstance(val, bool):
            if spec.min_val is not None and val < spec.min_val:
                ctx.errors.warning(
                    "W020",
                    f"param '{spec.name}' value {val} is below minimum {spec.min_val}",
                    location=_loc(inst_name_tok, ctx.source_file),
                )
            if spec.max_val is not None and val > spec.max_val:
                ctx.errors.warning(
                    "W020",
                    f"param '{spec.name}' value {val} is above maximum {spec.max_val}",
                    location=_loc(inst_name_tok, ctx.source_file),
                )
        resolved_params[spec.name]      = val
        resolved_mutability[spec.name]  = _resolve_param_mutability(
            spec, raw_mutability.get(spec.name), raw_mut_tok.get(spec.name),
            val, inst_name, ctx,
        )
        resolved_ranges[spec.name]      = (spec.min_val, spec.max_val)

    # Unknown-param check
    for p_name in raw_params:
        if p_name not in manifest_by_name:
            ctx.errors.error(
                "E042",
                f"node '{inst_name}' ({type_name}): unknown parameter '{p_name}'",
                location=_loc(inst_name_tok, ctx.source_file),
            )

    # Resource sizing is deliberately deferred until after instance-shape and
    # compiler-sourced parameter resolution.  Both declarative formulas and the
    # Python fallback must observe a fully concrete node instance.
    descriptor = NodeDescriptor(state_size=0, state_mem_flags=[])

    # ── Resolve compute trigger param names → indices ─────────────────────────
    param_name_to_index = {s.name: i for i, s in enumerate(manifest.params)}
    trigger_indices: list[int] = []
    for tname in manifest.compute_trigger_params:
        if tname in param_name_to_index:
            trigger_indices.append(param_name_to_index[tname])
        else:
            ctx.errors.error(
                "E042",
                f"node '{inst_name}' ({type_name}): compute trigger_params references "
                f"unknown param '{tname}'",
                location=_loc(inst_name_tok, ctx.source_file),
            )

    # ── Assemble NodeInstance ─────────────────────────────────────────────────
    node = NodeInstance(
        name=mangled,
        type_id=manifest.type_id,
        descriptor=descriptor,
        params=resolved_params,
        schedule_index=0,
        param_mutability=resolved_mutability,
        manifest_checksum=manifest.checksum,
        derived_size=manifest.derived_size,
        compute_cost=manifest.compute_cost,
        compute_trigger_indices=trigger_indices,
        param_ranges=resolved_ranges,
        input_pins=[
            InstancePinSpec(
                name=ps.name,
                index=i,
                pin_type=_pin_type_from_spec(ps.channels, ps.block_size, ps.data_type, ctx),
                channels_any=(ps.channels == "any"),
                channel_group=ps.channel_group,
                variadic=(ps.count == "variable"),
                resolved_count=1,
                count_from_channels=ps.count_from_channels,
                channels_from_count=ps.channels_from_count,
                min_count=ps.min_count,
                max_count=ps.max_count,
            )
            for i, ps in enumerate(manifest.inputs)
        ],
        output_pins=[
            InstancePinSpec(
                name=ps.name,
                index=i,
                pin_type=_pin_type_from_spec(ps.channels, ps.block_size, ps.data_type, ctx),
                channels_any=(ps.channels == "any"),
                channel_group=ps.channel_group,
                variadic=(ps.count == "variable"),
                resolved_count=1,
                count_from_channels=ps.count_from_channels,
                channels_from_count=ps.channels_from_count,
                min_count=ps.min_count,
                max_count=ps.max_count,
            )
            for i, ps in enumerate(manifest.outputs)
        ],
    )
    node_idx = len(ir.nodes)
    ir.nodes.append(node)
    ctx.metadata.nodes[node_idx] = NodeSource(
        runtime_node_id=node_idx,
        instance_name=inst_name,
        instance_path=mangled,
        parent_path=ctx.name_prefix.rstrip(".") or None,
        source_graph=ctx.graph_name,
        type_name=type_name,
        fqn=manifest.fqn,
        source=_source_span(node_decl, ctx.metadata.source_file),
        explicit_params=frozenset(raw_params),
        manifest=manifest,
    )
    ctx.node_index[mangled]      = node_idx
    ctx.node_type_names[mangled] = type_name
    ctx.node_explicit_params[mangled] = set(raw_params)


# ---------------------------------------------------------------------------
# Connection processing
# ---------------------------------------------------------------------------

def _resolve_pin_ref(
    ref:    Tree,
    ctx:    _BuildContext,
    ir:     IR,
    is_src: bool,
) -> Optional[tuple[int, int, PinType]]:
    """Return ``(node_index, pin_idx, PinType)`` or ``None`` on error.

    ``node_index = -1`` for a graph-boundary pin.
    For source refs, ``pin_idx`` is an index into the node's *outputs* list.
    For destination refs, ``pin_idx`` is an index into the node's *inputs* list.
    """
    if ref.data == "node_pin_ref":
        node_name_tok = ref.children[0]
        pin_name_tok  = ref.children[1]
        node_name     = str(node_name_tok)
        pin_name      = str(pin_name_tok)
        mangled       = ctx.name_prefix + node_name

        # Subgraph instance? Route through the recorded pin map.
        if mangled in ctx.subgraph_pins:
            pin_info = ctx.subgraph_pins[mangled]
            if is_src:
                if pin_name not in pin_info.outputs or pin_info.outputs[pin_name] is None:
                    ctx.errors.error(
                        "E061",
                        f"subgraph '{node_name}' has no output pin '{pin_name}'",
                        location=_loc(pin_name_tok, ctx.source_file),
                    )
                    return None
                src_node, src_pin, _internal_pt = pin_info.outputs[pin_name]
                # Present the declared subgraph boundary type to the parent
                # connection checker.  The flattened producer pin has already
                # inherited any concrete boundary channel constraint.
                return (src_node, src_pin, pin_info.output_types[pin_name])
            else:
                # Fan-out inputs are handled by _process_connection before this function
                ctx.errors.error(
                    "E061",
                    f"subgraph '{node_name}' input pin '{pin_name}' reached _resolve_pin_ref "
                    f"(internal error)",
                    location=_loc(pin_name_tok, ctx.source_file),
                )
                return None

        if mangled not in ctx.node_index:
            ctx.errors.error(
                "E061",
                f"undefined node: '{node_name}'",
                location=_loc(node_name_tok, ctx.source_file),
            )
            return None

        node_idx = ctx.node_index[mangled]
        node = ir.nodes[node_idx]

        # Source → look in outputs; destination → look in inputs
        pin_list = node.output_pins if is_src else node.input_pins
        for ps in pin_list:
            if ps.name == pin_name:
                has_index = len(ref.children) > 2
                if has_index and not ps.variadic:
                    ctx.errors.error(
                        "E063",
                        f"pin '{pin_name}' on '{node_name}' is not variadic and cannot be indexed",
                        location=_loc(ref.children[2], ctx.source_file),
                    )
                    return None
                # For variable-count pins, use the explicit [N] index so each
                # connection gets a distinct dst_pin/src_pin in the IR edge.
                pin_idx = ps.index
                if ps.variadic and has_index:
                    idx_tree = ref.children[2]
                    if idx_tree.data == "index":
                        pin_idx = int(str(idx_tree.children[0]))
                if ps.pin_type is None:
                    ctx.errors.error("E061", f"node '{node_name}' pin '{pin_name}' has no shape metadata")
                    return None
                return (node_idx, pin_idx, ps.pin_type)

        # Fallback: try the other list too so we can give a better error
        other = node.input_pins if is_src else node.output_pins
        for ps in other:
            if ps.name == pin_name:
                direction = "output" if is_src else "input"
                ctx.errors.error(
                    "E061",
                    f"pin '{pin_name}' on '{node_name}' is an {direction} pin; "
                    f"expected {'output' if is_src else 'input'}",
                    location=_loc(pin_name_tok, ctx.source_file),
                )
                return None

        ctx.errors.error(
            "E061",
            f"node '{node_name}' has no pin named '{pin_name}'",
            location=_loc(pin_name_tok, ctx.source_file),
        )
        return None

    if ref.data == "graph_pin_ref":
        pin_name_tok = ref.children[0]
        pin_name     = str(pin_name_tok)

        # src ref → data flows in from outside → graph input pin
        # dst ref → data flows out to outside  → graph output pin
        direction = "input" if is_src else "output"
        key = (pin_name, direction)

        if key not in ctx.pin_index:
            other_dir = "output" if is_src else "input"
            if (pin_name, other_dir) in ctx.pin_index:
                ctx.errors.error(
                    "E062",
                    f"graph pin '{pin_name}' is a {other_dir} pin; "
                    f"cannot be used as a connection {'source' if is_src else 'destination'}",
                    location=_loc(pin_name_tok, ctx.source_file),
                )
            else:
                ctx.errors.error(
                    "E062",
                    f"undefined graph pin: '{pin_name}'",
                    location=_loc(pin_name_tok, ctx.source_file),
                )
            return None

        idx = ctx.pin_index[key]
        pt  = ir.graph_inputs[idx].pin_type if is_src else ir.graph_outputs[idx].pin_type
        return (-1, idx, pt)

    ctx.errors.error("E061", f"unexpected pin ref type: {ref.data}")
    return None


def _extract_feedback_init(wire_op: Tree, ctx: _BuildContext) -> float:
    """Return the init scalar from a feedback_with_init wire_op tree, or 0.0."""
    if wire_op.data == "feedback_with_init":
        val = _eval_expr(wire_op.children[0], ctx)
        return float(val)
    return 0.0


def _connection_endpoint_source(
    ref: Tree, ctx: _BuildContext, *, is_src: bool
) -> ConnectionEndpointSource:
    if ref.data == "graph_pin_ref":
        return ConnectionEndpointSource(
            kind="graph_input" if is_src else "graph_output",
            pin_name=str(ref.children[0]),
            instance_path=ctx.name_prefix.rstrip(".") or None,
        )

    node_name = str(ref.children[0])
    pin_name = str(ref.children[1])
    slot: Optional[int] = None
    if len(ref.children) > 2:
        idx_tree = ref.children[2]
        if isinstance(idx_tree, Tree) and idx_tree.data == "index":
            slot = int(str(idx_tree.children[0]))
    return ConnectionEndpointSource(
        kind="node",
        pin_name=pin_name,
        instance_path=ctx.name_prefix + node_name,
        slot=slot,
    )


def _record_source_connection(
    connection: Tree,
    ctx: _BuildContext,
    is_feedback: bool,
    init_value: float,
) -> None:
    ctx.metadata.connections.append(ConnectionSource(
        source_graph=ctx.graph_name,
        instance_path=ctx.name_prefix.rstrip(".") or None,
        source_endpoint=_connection_endpoint_source(connection.children[0], ctx, is_src=True),
        destination_endpoint=_connection_endpoint_source(connection.children[2], ctx, is_src=False),
        feedback=is_feedback,
        feedback_init=init_value,
        source=_source_span(connection, ctx.metadata.source_file),
    ))


def _register_shadow_port(ir: IR, src_node: int, src_pin: int,
                           init_value: float, location: Any,
                           ctx: _BuildContext) -> int:
    """Return the index of the ShadowPort for (src_node, src_pin).

    Creates one if it doesn't exist yet.  Emits E086 if a second feedback edge
    from the same port declares a different init value.
    """
    for idx, sp in enumerate(ir.shadow_ports):
        if sp.src_node == src_node and sp.src_pin == src_pin:
            if sp.init_value != init_value:
                ctx.errors.error(
                    "E086",
                    f"feedback edges from the same output port must agree on 'init' "
                    f"(found {sp.init_value} and {init_value})",
                    location=location,
                )
            return idx
    ir.shadow_ports.append(ShadowPort(
        src_node=src_node,
        src_pin=src_pin,
        init_value=init_value,
    ))
    return len(ir.shadow_ports) - 1


def _append_edge(ir: IR, edge: Edge, connection: Tree, ctx: _BuildContext) -> None:
    """Append a runtime edge and its source/provenance record atomically."""
    ir.edges.append(edge)
    ctx.metadata.edges.append(EdgeSource(
        source_graph=ctx.graph_name,
        instance_path=ctx.name_prefix.rstrip(".") or None,
        source=_source_span(connection, ctx.metadata.source_file),
    ))


def _process_connection(connection: Tree, ctx: _BuildContext, ir: IR) -> None:
    src_ref  = connection.children[0]
    wire_op  = connection.children[1]
    dst_ref  = connection.children[2]

    is_feedback = wire_op.data in ("feedback", "feedback_with_init")
    init_value  = _extract_feedback_init(wire_op, ctx) if is_feedback else 0.0
    _record_source_connection(connection, ctx, is_feedback, init_value)

    # Fan-out: if dst is a subgraph input pin, create one edge per internal consumer.
    if dst_ref.data == "node_pin_ref":
        dst_node_name = str(dst_ref.children[0])
        dst_pin_name  = str(dst_ref.children[1])
        dst_mangled   = ctx.name_prefix + dst_node_name
        if dst_mangled in ctx.subgraph_pins:
            if is_feedback:
                ctx.errors.error(
                    "E085",
                    "feedback wire (~>) cannot target a subgraph input pin",
                    location=_loc(connection, ctx.source_file),
                )
                return
            consumers = ctx.subgraph_pins[dst_mangled].inputs.get(dst_pin_name)
            if consumers is not None:
                src = _resolve_pin_ref(src_ref, ctx, ir, is_src=True)
                if src is None:
                    return
                src_node, src_pin, src_pt = src
                for dst_node_idx, dst_pin_idx, dst_pt in consumers:
                    for err_str in pins_compatible(src_pt, dst_pt):
                        code, msg = err_str.split(": ", 1)
                        ctx.errors.error(code, msg, location=_loc(connection, ctx.source_file))
                    _append_edge(ir, Edge(
                        src_node=src_node,
                        src_pin=src_pin,
                        dst_node=dst_node_idx,
                        dst_pin=dst_pin_idx,
                        pin_type=src_pt,
                        liveness=EdgeLiveness(born=0, dies=0),
                        buffer=None,
                    ), connection, ctx)
                return

    src = _resolve_pin_ref(src_ref, ctx, ir, is_src=True)
    dst = _resolve_pin_ref(dst_ref, ctx, ir, is_src=False)

    if src is None or dst is None:
        return

    src_node, src_pin, src_pt = src
    dst_node, dst_pin, dst_pt = dst

    for err_str in pins_compatible(src_pt, dst_pt):
        code, msg = err_str.split(": ", 1)
        ctx.errors.error(code, msg, location=_loc(connection, ctx.source_file))

    shadow_port_id: Optional[int] = None
    if is_feedback:
        shadow_port_id = _register_shadow_port(
            ir, src_node, src_pin, init_value,
            _loc(connection, ctx.source_file), ctx,
        )

    _append_edge(ir, Edge(
        src_node=src_node,
        src_pin=src_pin,
        dst_node=dst_node,
        dst_pin=dst_pin,
        pin_type=src_pt,
        liveness=EdgeLiveness(born=0, dies=0),
        buffer=None,
        feedback_wire=is_feedback,
        feedback_init=init_value,
        shadow_port_id=shadow_port_id,
    ), connection, ctx)


# ---------------------------------------------------------------------------
# Phase-4 shape, system-parameter, and resource resolution
# ---------------------------------------------------------------------------

def _resolved_channel_group_width(node: NodeInstance, group_name: str) -> Optional[int]:
    """Return the resolved width of one explicit channel group on *node*."""
    widths = {
        p.pin_type.channels
        for pins in (node.input_pins, node.output_pins)
        for p in pins
        if p.channels_any and p.channel_group == group_name and p.pin_type is not None
    }
    if len(widths) != 1:
        return None
    return next(iter(widths))


def _resolved_adaptive_channels(node: NodeInstance) -> Optional[int]:
    """Compatibility width for a node with one logical adaptive channel group."""
    groups: dict[tuple, set[int]] = {}
    for side, pins in (("in", node.input_pins), ("out", node.output_pins)):
        for p in pins:
            if not p.channels_any or p.pin_type is None:
                continue
            key = ("group", p.channel_group) if p.channel_group is not None else (side, p.index)
            groups.setdefault(key, set()).add(p.pin_type.channels)
    if len(groups) != 1:
        return None
    widths = next(iter(groups.values()))
    return next(iter(widths)) if len(widths) == 1 else None


def _system_param_value(spec, node: NodeInstance, ctx: _BuildContext) -> Any:
    """Resolve one manifest ``source`` binding after instance-shape resolution."""
    source = spec.source
    if source == "graph.sample_rate":
        raw = ctx.project.sample_rate
    elif source == "graph.block_size":
        raw = ctx.project.fundamental_block
    elif source is not None and source.startswith("channel_group:"):
        group = source.split(":", 1)[1]
        raw = _resolved_channel_group_width(node, group)
        if raw is None:
            raise ValueError(f"cannot resolve channel group '{group}'")
    elif source is not None and source.startswith("pin_count:"):
        pin_name = source.split(":", 1)[1]
        matches = [
            p for pins in (node.input_pins, node.output_pins)
            for p in pins if p.name == pin_name
        ]
        if len(matches) != 1:
            raise ValueError(f"cannot resolve unique pin count for '{pin_name}'")
        raw = matches[0].resolved_count
    else:
        raise ValueError(f"unsupported compiler parameter source {source!r}")

    ok, value = _coerce_typed_value(spec.param_type, raw)
    if not ok:
        raise ValueError(f"source {source!r} cannot produce {spec.param_type}")
    return value


def _resolve_instance_shapes_and_resources(ir: IR, ctx: _BuildContext) -> None:
    """Resolve instance shape, compiler-sourced params, then node resources."""
    explicit_channels: dict[tuple[int, Optional[str]], int] = {}
    for node_idx, node in enumerate(ir.nodes):
        type_name = ctx.node_type_names.get(node.name)
        manifest = ctx.manifests.get(type_name) if type_name is not None else None
        if manifest is None:
            continue
        explicit = ctx.node_explicit_params.get(node.name, set())
        for spec in manifest.params:
            if spec.name not in explicit:
                continue
            if spec.source is not None and spec.source.startswith("channel_group:"):
                value = node.params.get(spec.name)
                if isinstance(value, int) and not isinstance(value, bool):
                    explicit_channels[(node_idx, spec.source.split(":", 1)[1])] = value
            elif spec.name == "channels":
                # Compatibility with third-party pre-Phase-4 manifests.
                value = node.params.get(spec.name)
                if isinstance(value, int) and not isinstance(value, bool):
                    explicit_channels[(node_idx, None)] = value

    resolve_shapes(ir, ctx.errors, explicit_channel_constraints=explicit_channels)
    if ctx.errors.has_errors:
        return

    # Materialize compiler-owned values into their existing serialized param
    # slots.  Explicit legacy values are accepted only when they agree with the
    # compiler-derived value, preserving migration compatibility without
    # allowing the graph to override system facts.
    for node in ir.nodes:
        type_name = ctx.node_type_names.get(node.name)
        manifest = ctx.manifests.get(type_name) if type_name is not None else None
        if manifest is None:
            continue
        explicit = ctx.node_explicit_params.get(node.name, set())
        for spec in manifest.params:
            if spec.source is None:
                continue
            try:
                derived = _system_param_value(spec, node, ctx)
            except ValueError as exc:
                ctx.errors.error(
                    "E050",
                    f"node '{node.name}': cannot resolve compiler parameter '{spec.name}': {exc}",
                )
                continue
            if spec.name in explicit and node.params.get(spec.name) != derived:
                # Channel-group conflicts are normally caught by shape resolution;
                # this also covers graph.sample_rate / graph.block_size legacy values.
                ctx.errors.error(
                    "E050",
                    f"node '{node.name}': compiler parameter '{spec.name}' is {derived} "
                    f"from {spec.source}, but graph supplied {node.params.get(spec.name)}",
                )
                continue
            node.params[spec.name] = derived

    if ctx.errors.has_errors:
        return

    # Pre-Phase-4 third-party manifests may still carry an ordinary scalar
    # channels parameter.  Preserve the Phase-3 compatibility behavior.
    for node in ir.nodes:
        type_name = ctx.node_type_names.get(node.name)
        manifest = ctx.manifests.get(type_name) if type_name is not None else None
        if manifest is None:
            continue
        for spec in manifest.params:
            if spec.name == "channels" and spec.source is None:
                width = _resolved_adaptive_channels(node)
                if width is not None:
                    node.params["channels"] = width

    # Resource sizing happens only after every node instance and system param is concrete.
    for node in ir.nodes:
        type_name = ctx.node_type_names.get(node.name)
        manifest = ctx.manifests.get(type_name) if type_name is not None else None
        if manifest is None:
            continue
        try:
            if manifest.descriptor_provider == "python":
                ns = manifest.namespace
                pkg_dir = _pkg_dir_for_namespace(ns, ctx)
                if pkg_dir is None:
                    ctx.errors.error(
                        "E045",
                        f"cannot find package directory for '{ns}' to run descriptor",
                    )
                    continue
                node.descriptor = invoke_descriptor(manifest, node.params, pkg_dir)
            else:
                node.descriptor = resolve_manifest_descriptor(manifest, node.params)
        except RuntimeError as exc:
            ctx.errors.error("E045", str(exc))


# ---------------------------------------------------------------------------
# Graph processing (two-pass)
# ---------------------------------------------------------------------------

def _process_graph(graph_decl: Tree, ctx: _BuildContext) -> IR:
    graph_body = graph_decl.children[-1]

    ir = IR(
        sample_rate=ctx.project.sample_rate,
        fundamental_block=ctx.project.fundamental_block,
        block_divisor=1,
        memory_regions=list(ctx.project.memory_regions),
    )

    # ── Pass 1: block_divisor + graph-local defines ───────────────────────────
    local_defines: list[Tree] = []
    divisor_decl: Optional[Tree] = None
    for item in graph_body.children:
        inner = item.children[0]
        if inner.data == "block_divisor_decl":
            if divisor_decl is not None:
                ctx.errors.error(
                    "E048",
                    "duplicate block_divisor declaration",
                    location=_loc(inner, ctx.source_file),
                )
            else:
                divisor_decl = inner
        elif inner.data == "define_decl":
            local_defines.append(inner)

    if divisor_decl is not None:
        divisor = int(str(divisor_decl.children[0]))
        if divisor <= 0:
            ctx.errors.error(
                "E089",
                "block_divisor must be greater than zero",
                location=_loc(divisor_decl, ctx.source_file),
            )
        else:
            ir.block_divisor = divisor
            ctx.block_divisor = divisor
    _process_defines(local_defines, ctx)

    # ── Pass 2: pin decls + node decls (subgraph expansion happens here) ─────
    for item in graph_body.children:
        inner = item.children[0]
        if inner.data == "pin_decl":
            _process_pin_decl(inner, ctx, ir)
        elif inner.data == "node_decl":
            _process_node_decl(inner, ctx, ir)

    # ── Pass 3: connections (all nodes/subgraphs are now registered) ─────────
    for item in graph_body.children:
        inner = item.children[0]
        if inner.data == "connection":
            _process_connection(inner, ctx, ir)

    if not ctx.errors.has_errors:
        _resolve_instance_shapes_and_resources(ir, ctx)
    return ir


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _capture_graph_sources(
    graph_nodes: list[Tree], source: str, source_file: str
) -> dict[str, GraphSource]:
    """Capture graph declarations without adding another semantic pass."""
    result: dict[str, GraphSource] = {}
    for graph_decl in graph_nodes:
        name = str(graph_decl.children[0])
        params: list[GraphParamSource] = []
        for child in graph_decl.children[1:-1]:
            if not isinstance(child, Tree) or child.data != "graph_param_list":
                continue
            for gp in child.children:
                name_tok = gp.children[0]
                params.append(GraphParamSource(
                    name=str(name_tok),
                    type_name=_span(gp.children[1], source),
                    source=_source_span(gp, source_file),
                ))
        result[name] = GraphSource(
            name=name,
            source=_source_span(graph_decl, source_file),
            params=tuple(params),
        )
    return result


def _inspection_source_file(project: Project) -> str:
    """Prefer a stable project-relative entry path for tooling metadata."""
    try:
        return project.entry.resolve().relative_to(project.project_dir.resolve()).as_posix()
    except (OSError, ValueError):
        return str(project.entry)


def build_with_metadata(
    source:   str,
    project:  Project,
    pkg_dirs: dict[str, Path],
) -> tuple[IR, BuildMetadata]:
    """Convert source to IR and retain compiler-owned tooling provenance.

    ``pkg_dirs`` maps namespace strings (e.g. ``"std.filters"``) to the
    absolute path of the package directory containing ``humpkg.toml``.
    These supplement (and take precedence over) dependencies declared in
    ``project``'s ``hum.toml``.

    Raises:
        ``lark.UnexpectedInput`` on parse errors.
        ``CompileError`` on semantic errors.
    """
    tree = parse(source)

    # Collect top-level declarations (top_level_decl is transparent)
    import_nodes = [c for c in tree.children if isinstance(c, Tree) and c.data == "import_decl"]
    define_nodes = [c for c in tree.children if isinstance(c, Tree) and c.data == "define_decl"]
    graph_nodes  = [c for c in tree.children if isinstance(c, Tree) and c.data == "graph_decl"]

    if not graph_nodes:
        raise CompileError([HumError(code="E003", message="no graph declaration found in source")])

    # Separate root graph ("main") from subgraph definitions.
    graph_defs: dict[str, Tree] = {}
    root_graph: Optional[Tree]  = None
    graph_names: set[str] = set()
    for g in graph_nodes:
        name = str(g.children[0])
        if name in graph_names:
            raise CompileError([HumError(
                code="E048",
                message=f"duplicate graph declaration '{name}'",
                location=_loc(g.children[0], str(project.entry)),
            )])
        graph_names.add(name)
        if name == "main":
            root_graph = g
        else:
            graph_defs[name] = g
    if root_graph is None:
        raise CompileError([HumError(
            code="E003",
            message="executable source requires an explicit 'graph main' declaration",
        )])

    source_file = str(project.entry)
    inspection_source_file = _inspection_source_file(project)
    metadata = BuildMetadata(
        source_file=inspection_source_file,
        graphs=_capture_graph_sources(graph_nodes, source, inspection_source_file),
    )

    ctx = _BuildContext(
        source=source,
        project=project,
        pkg_dirs=dict(pkg_dirs),
        errors=ErrorCollector(),
        defines={},
        protected_defines=set(),
        manifests={},
        node_index={},
        node_type_names={},
        node_explicit_params={},
        pin_index={},
        graph_defs=graph_defs,
        subgraph_pins={},
        expanding=set(),
        source_file=source_file,
        graph_name="main",
        metadata=metadata,
    )

    # The executable root has no caller from which compile-time graph arguments
    # could be supplied, so V1 does not permit parameters on graph main.
    if _graph_signature(root_graph, ctx):
        ctx.errors.error(
            "E047",
            "graph main cannot declare parameters",
            location=_loc(root_graph.children[0], ctx.source_file),
        )

    # Stage 1: defines + imports
    _process_defines(define_nodes, ctx)
    _process_imports(import_nodes, ctx)
    ctx.errors.raise_if_errors()   # ← BOUNDARY: abort if packages missing

    # Stage 2: compile the root graph
    ir = _process_graph(root_graph, ctx)
    ctx.errors.raise_if_errors()   # ← BOUNDARY: report all graph-body errors

    return ir, metadata


def build(
    source:   str,
    project:  Project,
    pkg_dirs: dict[str, Path],
) -> IR:
    """Compatibility wrapper returning only the runtime IR.

    New tooling should use :func:`build_with_metadata`; the runtime/compiler
    semantics of :func:`build` are unchanged.
    """
    ir, _metadata = build_with_metadata(source, project, pkg_dirs)
    return ir
