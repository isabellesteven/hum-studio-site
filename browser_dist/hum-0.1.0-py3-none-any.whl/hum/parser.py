"""Hum DSL parser — wraps Lark with the hum.lark grammar.

Phase 1 note: this module only constructs a parse tree (AST).
Transformation to IR objects happens in a later stage.
This is the first pipeline stage:
    Parser → Builder → TypeChecker → TopoSort → Liveness → Allocator → Serializer
"""

from __future__ import annotations

from pathlib import Path
from functools import lru_cache

from lark import Lark, Tree, UnexpectedInput

_GRAMMAR_PATH = Path(__file__).parent / "grammar.lark"


@lru_cache(maxsize=1)
def _get_parser() -> Lark:
    """Return a cached Lark parser instance."""
    grammar = _GRAMMAR_PATH.read_text(encoding="utf-8")
    return Lark(
        grammar,
        parser="lalr",
        lexer="contextual",
        propagate_positions=True,
    )


def parse(source: str) -> Tree:
    """Parse *source* and return a Lark parse tree.

    Raises ``lark.UnexpectedInput`` (or a subclass) on parse error.
    """
    return _get_parser().parse(source)


def parse_file(path: str | Path) -> Tree:
    """Read *path* and parse it."""
    source = Path(path).read_text(encoding="utf-8")
    return parse(source)
