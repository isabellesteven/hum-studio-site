"""Project configuration — loads ``hum.toml``.

DEVELOPMENT.md documents the project/build model.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-reuse-import]

from hum.ir import MemRegion


@dataclass
class DependencySpec:
    """One entry from ``[dependencies]``."""
    path: Optional[str] = None   # v1: path-based only


@dataclass
class CodegenConfig:
    generate_param_header:  bool = True
    generate_arena_header:  bool = True
    generate_tuning_table:  bool = True
    header_output_dir:      str  = "inc"


@dataclass
class Project:
    """Parsed ``hum.toml`` for a Hum project."""
    name:               str
    version:            str
    fundamental_block:  int
    sample_rate:        int
    entry:              Path          # resolved relative to project_dir
    output_dir:         Path          # resolved relative to project_dir
    warnings_as_errors: list[str]
    memory_regions:     list[MemRegion]
    dependencies:       dict[str, DependencySpec]
    codegen:            CodegenConfig
    project_dir:        Path          # directory containing hum.toml

    def dependency_paths(self) -> dict[str, Path]:
        """Return ``{namespace: absolute_path}`` for all path-based deps."""
        result: dict[str, Path] = {}
        for ns, spec in self.dependencies.items():
            if spec.path is not None:
                p = Path(spec.path)
                if not p.is_absolute():
                    p = (self.project_dir / p).resolve()
                result[ns] = p
        return result


def load_project(path: Path) -> Project:
    """Load and validate a ``hum.toml`` file.

    ``path`` may be either the directory containing ``hum.toml`` or the file
    itself.
    """
    if path.is_dir():
        path = path / "hum.toml"
    project_dir = path.parent.resolve()

    raw  = path.read_bytes()
    data = tomllib.loads(raw.decode("utf-8"))

    proj     = data.get("project", {})
    build    = data.get("build", {})
    codegen  = data.get("codegen", {})
    mem_data = data.get("memory", {})
    deps     = data.get("dependencies", {})

    # Memory regions — converted directly to ir.MemRegion
    # size is optional; 0 means "unspecified — host decides".
    regions: list[MemRegion] = []
    for r in mem_data.get("regions", []):
        regions.append(MemRegion(
            region_id=r["id"],
            name=r.get("name", str(r["id"])),
            size=r.get("size", 0),
            flags=r.get("flags", []),
        ))
    # Ensure two default regions when none declared: control (256 KB) + audio (4 MB)
    if not regions:
        regions.append(MemRegion(region_id=0, name="control", size=256 * 1024, flags=[]))
        regions.append(MemRegion(region_id=1, name="audio",   size=4 * 1024 * 1024, flags=[]))

    # Dependencies
    dep_specs: dict[str, DependencySpec] = {}
    for ns, spec in deps.items():
        if isinstance(spec, dict):
            dep_specs[ns] = DependencySpec(path=spec.get("path"))
        elif isinstance(spec, str):
            dep_specs[ns] = DependencySpec(path=spec)

    # Codegen
    cg = CodegenConfig(
        generate_param_header=codegen.get("generate_param_header", True),
        generate_arena_header=codegen.get("generate_arena_header", True),
        generate_tuning_table=codegen.get("generate_tuning_table", True),
        header_output_dir=codegen.get("header_output_dir", "inc"),
    )

    entry      = project_dir / build.get("entry", "src/main.hum")
    output_dir = project_dir / build.get("output_dir", "build")

    return Project(
        name=proj.get("name", "unnamed"),
        version=proj.get("version", "0.0.0"),
        fundamental_block=build.get("fundamental_block", 256),
        sample_rate=build.get("sample_rate", 48000),
        entry=entry,
        output_dir=output_dir,
        warnings_as_errors=build.get("warnings_as_errors", []),
        memory_regions=regions,
        dependencies=dep_specs,
        codegen=cg,
        project_dir=project_dir,
    )
