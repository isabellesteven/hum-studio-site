"""Hum Intermediate Representation (IR).

The IR is the Python object graph that passes between toolchain stages:

    Parser → Builder → Shape Resolver → Resource Sizing → Type Checker
           → Topo Sort → Liveness → Allocator → Serializer

All IR objects are plain dataclasses.  They are serialisable to JSON via
``dataclasses.asdict`` for the ``hum inspect --ir`` command.

DESIGN.md describes IR stage invariants.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

# ---------------------------------------------------------------------------
# Primitive types
# ---------------------------------------------------------------------------

# Index of an edge in IR.edges.  Using a named alias keeps signatures readable.
EdgeId = int


class DataType(Enum):
    FLOAT32 = "float32"
    FIXED32 = "fixed32"
    UFIXED32 = "ufixed32"


class Mutability(Enum):
    CONST  = "const"
    PARAM  = "param"
    ARRAY  = "array"   # double-buffered vector, swapped at block boundary


# ---------------------------------------------------------------------------
# Pin / edge types
# ---------------------------------------------------------------------------

@dataclass
class PinType:
    """Describes the signal carried by a connection edge."""
    data_type:   DataType
    channels:    int   # >= 1; 0 means "any" (wildcard, resolved after graph build)
    block_size:  int   # samples per channel per execution
    sample_rate: int   # Hz


@dataclass
class EdgeLiveness:
    """Half-open lifetime interval [born, dies) in schedule-step units.

    ``born`` is the schedule step at which the edge's buffer is first written
    (i.e. the index of the producing node in the schedule).
    ``dies`` is the schedule step *after* which no node reads from the buffer.

    Always computed (even though the v1 allocator ignores liveness) so that
    future allocators need no IR changes.
    """
    born: int   # schedule step at which edge is first written
    dies: int   # schedule step after which edge is no longer read


# ---------------------------------------------------------------------------
# Memory regions
# ---------------------------------------------------------------------------

@dataclass
class MemRegion:
    """A host-declared memory arena.

    Mirrors the ``[[memory.regions]]`` entries in ``hum.toml`` and the
    ``HumMemRegion`` C struct.  Flags are string tokens: "fast", "dma_safe",
    "external".
    """
    region_id: int
    name:      str
    size:      int         # bytes
    flags:     list[str]   # e.g. ["fast"]


# ---------------------------------------------------------------------------
# Buffer / state allocation
# ---------------------------------------------------------------------------

@dataclass
class BufferAssignment:
    """Resolved placement of one edge's audio buffer in a memory arena."""
    edge_id:   EdgeId
    region_id: int   # which MemRegion
    offset:    int   # byte offset within that arena
    size:      int   # bytes


@dataclass
class ParamCopy:
    """A parameter array that must be copied into a fast-memory arena at load.

    v1 constraint: only ``mutable = const`` arrays may use copy_at_init.
    """
    name:      str
    size:      int         # bytes
    mem_flags: list[str]   # e.g. ["fast"]


# ---------------------------------------------------------------------------
# Node descriptor
# ---------------------------------------------------------------------------

@dataclass
class NodeDescriptor:
    """Per-instance resource requirements, produced by the descriptor function.

    Normally this is resolved from the manifest's ``[memory]`` section, whose
    ``state_size`` may be static or a restricted expression over concrete
    parameters.  ``descriptor.provider = "python"`` remains an escape hatch
    for unusual compile-time resource logic.
    """
    state_size:      int
    state_mem_flags: list[str]
    param_copies:    list[ParamCopy] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Node instance
# ---------------------------------------------------------------------------

@dataclass
class InstancePinSpec:
    """A node instance pin template with its current resolved shape.

    ``index`` is the pin's manifest position for fixed pins.  A sole variadic
    pin owns the explicit edge index space instead.  ``channels_any`` records
    the manifest declaration even after ``pin_type.channels`` has been resolved
    to a concrete value by the Phase-3 shape resolver.
    """
    name:         str
    index:        int
    pin_type:     Optional[PinType] = None
    channels_any: bool = False
    channel_group: Optional[str] = None
    variadic:     bool = False
    resolved_count: int = 1
    count_from_channels: Optional[str] = None
    channels_from_count: Optional[str] = None
    min_count:    Optional[int] = None
    max_count:    Optional[int] = None


@dataclass
class NodeInstance:
    """A single instantiated node inside a graph."""
    name:              str
    type_id:           int          # FNV-1a hash of fully qualified node name
    descriptor:        NodeDescriptor
    params:            dict         # resolved parameter values (name → value)
    schedule_index:    int          # position in execution order (set by topo sort)
    param_mutability:  dict = field(default_factory=dict)  # name → Mutability
    manifest_checksum: int = 0      # FNV-1a of the .humnode file bytes (for blob)
    derived_size:             int = 0   # bytes per derived state buffer (0 = no compute)
    compute_cost:             int = 0   # 0=light, 1=medium, 2=heavy (for host scheduling hints)
    compute_trigger_indices:  list = field(default_factory=list)  # list[int] param indices
    param_ranges:      dict = field(default_factory=dict)  # name → (min, max) | (None, None)
    input_pins:        list = field(default_factory=list)  # list[InstancePinSpec]
    output_pins:       list = field(default_factory=list)  # list[InstancePinSpec]


# ---------------------------------------------------------------------------
# Shadow port (one-block delay register, per feedback-source output port)
# ---------------------------------------------------------------------------

@dataclass
class ShadowPort:
    """A one-block delay register for a feedback-source output port.

    Keyed by (src_node, src_pin).  All feedback_wire edges from the same
    source port share one ShadowPort — and therefore one shadow buffer.
    Populated by the builder; buffer assigned by the allocator.
    """
    src_node:   int
    src_pin:    int
    init_value: float
    buffer: Optional[BufferAssignment] = None   # set by allocator


# ---------------------------------------------------------------------------
# Edge
# ---------------------------------------------------------------------------

@dataclass
class Edge:
    """A directed connection between two node pins (or a graph boundary pin).

    ``src_node`` / ``dst_node`` are indices into ``IR.nodes``.
    A value of -1 indicates a graph-level pin (boundary).
    """
    src_node: int   # index into IR.nodes; -1 = graph input boundary
    src_pin:  int
    dst_node: int   # index into IR.nodes; -1 = graph output boundary
    dst_pin:  int
    pin_type: PinType
    liveness: EdgeLiveness            # always computed
    buffer:   Optional[BufferAssignment] = None   # set by allocator
    feedback_wire:  bool  = False     # True → one-block unit-delay edge
    feedback_init:  float = 0.0       # scalar broadcast into shadow buffer at init
    shadow_port_id: Optional[int] = None  # index into IR.shadow_ports (set by builder)


# ---------------------------------------------------------------------------
# Top-level IR
# ---------------------------------------------------------------------------

@dataclass
class GraphPin:
    """A graph-level I/O pin declared with the ``pin`` keyword.

    Represents the graph's external interface.  Boundary edges reference
    these via ``src_node=-1`` (graph input) or ``dst_node=-1`` (graph output).
    Each pin is a single named signal; array-indexed pins are not supported.
    """
    name:         str
    direction:    str    # "input" | "output"
    pin_type:     PinType
    channels_any: bool = False


@dataclass
class StateAssignment:
    """Resolved placement of one node's state (and param-copy) memory."""
    node_index:        int
    region_id:         int
    state_offset:      int   # byte offset within the region arena
    param_copy_offset: int   # byte offset for param-copy data (-1 if none)
    param_copy_size:   int   # total bytes for all param copies of this node


@dataclass
class IR:
    """The fully validated, typed pipeline graph.

    Constructed incrementally as toolchain stages run.  Each stage adds or
    fills in fields; earlier stages leave later-stage fields at their
    defaults.
    """
    sample_rate:       int
    fundamental_block: int
    block_divisor:     int
    nodes:             list[NodeInstance] = field(default_factory=list)
    edges:             list[Edge]         = field(default_factory=list)
    shadow_ports:      list[ShadowPort]   = field(default_factory=list)
    schedule:          list[int]          = field(default_factory=list)
    memory_regions:    list[MemRegion]    = field(default_factory=list)
    graph_inputs:      list[GraphPin]     = field(default_factory=list)
    graph_outputs:     list[GraphPin]     = field(default_factory=list)
    state_assignments: list[StateAssignment] = field(default_factory=list)
    region_high_water: dict               = field(default_factory=dict)
    shapes_resolved:   bool               = False
    # region_high_water: maps region_id (int) → allocator high-water mark (int bytes).
    # Populated by allocator.allocate(); used by codegen to emit HUM_REGION_N_MIN_BYTES.


# ---------------------------------------------------------------------------
# Pin compatibility check  (section 4)
# ---------------------------------------------------------------------------

def pins_compatible(src: PinType, dst: PinType) -> list[str]:
    """Return a list of error codes for incompatible pin pairs.

    An empty list means the pins are compatible.
    channels=0 means "any" — channel mismatch is suppressed when either side is 0.
    """
    errors: list[str] = []
    if src.data_type   != dst.data_type:   errors.append("E021: data type mismatch")
    if src.channels != 0 and dst.channels != 0 and src.channels != dst.channels:
        errors.append("E022: channel count mismatch")
    if src.block_size  != dst.block_size:  errors.append("E023: block size mismatch")
    if src.sample_rate != dst.sample_rate: errors.append("E024: sample rate mismatch")
    return errors
