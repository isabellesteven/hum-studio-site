"""Hum toolchain command-line interface.

Usage:
    hum build [--project PATH]
    hum check [--project PATH]
    hum inspect --ir  SOURCE_FILE [--project PATH]
    hum inspect --blob BLOB_FILE
    hum map BLOB_FILE
    hum hash NODE_FQN
    hum list-nodes [--project PATH]

DEVELOPMENT.md documents the CLI/build workflow.
"""

from __future__ import annotations

import dataclasses
import json
import struct
import sys
from pathlib import Path

from hum.compiler import compile_graph
from hum.errors import CompileError
from hum.fnv import fnv1a_32, node_type_id
from hum.artifacts import _render_map, _build_tuning_json, _build_hum_params_h
from hum.manifest import load_package
from hum.project import load_project
from hum.serializer import serialize, _HEADER_SIZE, _SECTION_ENTRY_SIZE


# ---------------------------------------------------------------------------
# Pipeline helper
# ---------------------------------------------------------------------------

def _load_pkg_dirs(project) -> dict[str, Path]:
    """Build the pkg_dirs map from project dependency paths."""
    return project.dependency_paths()


def _run_pipeline(project, source: str, pkg_dirs: dict[str, Path]):
    """Run all pipeline stages; return the fully-allocated IR."""
    return compile_graph(source, project, pkg_dirs).ir


def _run_compilation(project, source: str, pkg_dirs: dict[str, Path]):
    """Run all stages and retain both runtime IR and inspection metadata."""
    return compile_graph(source, project, pkg_dirs)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_build(args) -> int:
    """Build project → .humblob + debug artifacts."""
    project_path = Path(args.project) if args.project else Path.cwd()
    try:
        project = load_project(project_path)
    except Exception as exc:
        print(f"error: failed to load project: {exc}", file=sys.stderr)
        return 1

    pkg_dirs = _load_pkg_dirs(project)
    try:
        source = project.entry.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"error: cannot read entry file '{project.entry}': {exc}", file=sys.stderr)
        return 1

    try:
        compilation = _run_compilation(project, source, pkg_dirs)
        ir = compilation.ir
    except CompileError as exc:
        for e in exc.errors:
            print(str(e), file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    # Warn when a region's declared size is set but smaller than actual usage.
    for region in ir.memory_regions:
        if region.size > 0:
            used = ir.region_high_water.get(region.region_id, 0)
            if used > region.size:
                print(
                    f"warning: region '{region.name}' (id={region.region_id}) "
                    f"uses {used} bytes but declared size is {region.size} bytes",
                    file=sys.stderr,
                )

    project.output_dir.mkdir(parents=True, exist_ok=True)

    # Write .humblob
    blob = serialize(ir)
    stem = project.entry.stem
    blob_path = project.output_dir / f"{stem}.humblob"
    blob_path.write_bytes(blob)
    print(f"wrote {blob_path}  ({len(blob)} bytes)")

    # Write developer-facing semantic inspection JSON.  This is a separate,
    # versioned tooling schema; it is not part of the runtime blob ABI.
    inspection_path = project.output_dir / f"{stem}.inspection.json"
    inspection_path.write_text(compilation.inspection.to_json(indent=2), encoding="utf-8")
    print(f"wrote {inspection_path}")

    # Write map file
    map_path = project.output_dir / f"{stem}.map"
    map_path.write_text(_render_map(ir, blob), encoding="utf-8")

    # Write tuning JSON
    blob_checksum = struct.unpack_from('<I', blob, 36)[0] if len(blob) >= 40 else 0
    tuning = _build_tuning_json(ir, project.name, blob_checksum)
    if tuning["params"]:
        tuning_path = project.output_dir / f"{stem}.tuning.json"
        tuning_path.write_text(json.dumps(tuning, indent=2), encoding="utf-8")
        print(f"wrote {tuning_path}  ({len(tuning['params'])} tunable params)")

    # Write generated hum_params.h (always — region setup is needed even when
    # there are no tunable params)
    params_h_path = project.output_dir / "hum_params.h"
    params_h_path.write_text(_build_hum_params_h(tuning, ir), encoding="utf-8")
    print(f"wrote {params_h_path}")

    return 0


def cmd_check(args) -> int:
    """Validate project without writing output files."""
    project_path = Path(args.project) if args.project else Path.cwd()
    try:
        project = load_project(project_path)
    except Exception as exc:
        print(f"error: failed to load project: {exc}", file=sys.stderr)
        return 1

    pkg_dirs = _load_pkg_dirs(project)
    try:
        source = project.entry.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"error: cannot read entry file '{project.entry}': {exc}", file=sys.stderr)
        return 1

    try:
        _run_pipeline(project, source, pkg_dirs)
        print("OK — no errors")
        return 0
    except CompileError as exc:
        for e in exc.errors:
            print(str(e), file=sys.stderr)
        return 1


def cmd_inspect(args) -> int:
    """Inspect source IR or binary blob."""
    if args.ir:
        return _inspect_ir(args)
    if args.blob:
        return _inspect_blob(args)
    print("error: --ir or --blob required", file=sys.stderr)
    return 1


def _inspect_ir(args) -> int:
    source_path = Path(args.ir)
    project_path = Path(args.project) if args.project else source_path.parent
    try:
        project = load_project(project_path)
    except Exception as exc:
        print(f"error: failed to load project: {exc}", file=sys.stderr)
        return 1

    pkg_dirs = _load_pkg_dirs(project)
    try:
        source = source_path.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"error: cannot read '{source_path}': {exc}", file=sys.stderr)
        return 1

    try:
        ir = _run_pipeline(project, source, pkg_dirs)
    except CompileError as exc:
        for e in exc.errors:
            print(str(e), file=sys.stderr)
        return 1

    print(json.dumps(dataclasses.asdict(ir), indent=2, default=str))
    return 0


def _inspect_blob(args) -> int:
    blob_path = Path(args.blob)
    try:
        blob = blob_path.read_bytes()
    except OSError as exc:
        print(f"error: cannot read '{blob_path}': {exc}", file=sys.stderr)
        return 1

    return _print_blob_info(blob)


def _print_blob_info(blob: bytes) -> int:
    if len(blob) < _HEADER_SIZE:
        print("error: blob too small to contain a valid header", file=sys.stderr)
        return 1

    magic = blob[:4]
    if magic != b"HUM\x00":
        print(f"error: bad magic {magic!r} (expected b'HUM\\x00')", file=sys.stderr)
        return 1

    fmt_ver, api_ver, flags = blob[4], blob[5], blob[6]
    blob_size       = struct.unpack_from("<I", blob, 8)[0]
    sec_dir_offset  = struct.unpack_from("<I", blob, 12)[0]
    sec_count       = struct.unpack_from("<I", blob, 16)[0]
    sample_rate     = struct.unpack_from("<I", blob, 20)[0]
    fundamental_blk = struct.unpack_from("<H", blob, 24)[0]
    node_count      = struct.unpack_from("<H", blob, 26)[0]
    edge_count      = struct.unpack_from("<H", blob, 28)[0]
    param_count     = struct.unpack_from("<H", blob, 30)[0]
    region_count    = blob[32]
    graph_checksum  = struct.unpack_from("<I", blob, 36)[0]

    print(f"Hum Blob")
    print(f"  format_version   : {fmt_ver}")
    print(f"  api_version      : {api_ver}")
    print(f"  flags            : 0x{flags:02x}")
    print(f"  blob_size        : {blob_size} bytes")
    print(f"  sample_rate      : {sample_rate} Hz")
    print(f"  fundamental_block: {fundamental_blk} samples")
    print(f"  node_count       : {node_count}")
    print(f"  edge_count       : {edge_count}")
    print(f"  param_count      : {param_count}")
    print(f"  region_count     : {region_count}")
    print(f"  graph_checksum   : 0x{graph_checksum:08x}")
    print()

    # Section directory
    _SEC_NAMES = {
        0x0001: "NODE_TABLE",
        0x0002: "SCHEDULE",
        0x0003: "PARAM_DATA",
        0x0004: "STATE_DESC",
        0x0005: "BUFFER_DESC",
        0x0006: "TUNING_DESC",
        0x0007: "STRING_TABLE",
        0x00FF: "CHECKSUM",
    }
    print(f"Sections ({sec_count}):")
    for i in range(sec_count):
        base = sec_dir_offset + i * _SECTION_ENTRY_SIZE
        sec_type    = struct.unpack_from("<H", blob, base + 0)[0]
        sec_ver     = struct.unpack_from("<H", blob, base + 2)[0]
        sec_offset  = struct.unpack_from("<I", blob, base + 4)[0]
        sec_size    = struct.unpack_from("<I", blob, base + 8)[0]
        entry_count = struct.unpack_from("<I", blob, base + 12)[0]
        name = _SEC_NAMES.get(sec_type, f"0x{sec_type:04x}")
        print(f"  [{i}] {name:<14} v{sec_ver}  offset={sec_offset}  "
              f"size={sec_size}  entries={entry_count}")

    return 0


def cmd_map(args) -> int:
    """Show resolved memory layout of a compiled blob."""
    blob_path = Path(args.blob_file)
    try:
        blob = blob_path.read_bytes()
    except OSError as exc:
        print(f"error: cannot read '{blob_path}': {exc}", file=sys.stderr)
        return 1

    if blob[:4] != b"HUM\x00":
        print("error: not a valid .humblob file", file=sys.stderr)
        return 1

    # Parse what we can from the blob without the IR
    node_count = struct.unpack_from("<H", blob, 26)[0]
    edge_count = struct.unpack_from("<H", blob, 28)[0]
    print(f"Memory map: {blob_path.name}")
    print(f"  nodes : {node_count}")
    print(f"  edges : {edge_count}")
    print(f"  total : {len(blob)} bytes")
    return 0


def cmd_send(args) -> int:
    """Transmit a compiled blob (and optional tuning JSON) via TCP or serial."""
    target = Path(args.target)

    # Resolve blob path
    if target.suffix == ".humblob":
        blob_path = target
    else:
        try:
            project = load_project(target)
        except Exception as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        stem = project.entry.stem
        blob_path = project.output_dir / f"{stem}.humblob"

    if not blob_path.exists():
        print(
            f"error: blob not found: {blob_path}\n"
            f"       run 'hum build' first",
            file=sys.stderr,
        )
        return 1

    blob = blob_path.read_bytes()
    print(f"blob: {blob_path}  ({len(blob)} bytes)")

    # Resolve tuning JSON path
    tuning_data: bytes | None = None
    if not args.no_tuning:
        tuning_path = blob_path.with_suffix("").with_suffix(".tuning.json")
        if tuning_path.exists():
            tuning_data = tuning_path.read_bytes()
            print(f"tuning: {tuning_path}  ({len(tuning_data)} bytes)")

    # Open transport
    transport = _open_transport(args)
    if transport is None:
        return 1

    try:
        rc = _send_blob(transport, blob)
        if rc != 0:
            return rc
        if tuning_data:
            rc = _send_tuning(transport, tuning_data)
            if rc != 0:
                return rc
        return 0
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    finally:
        transport.close()


def _send_blob(transport, blob: bytes) -> int:
    print(f"sending LOAD {len(blob)} ...")
    transport.send(f"LOAD {len(blob)}\n".encode())
    resp = transport.readline()
    if resp != "OK LOAD ready":
        print(f"error: unexpected LOAD response: {resp!r}", file=sys.stderr)
        return 1
    transport.send(blob)
    resp = transport.readline()
    if resp != f"OK LOAD {len(blob)}":
        print(f"error: load failed: {resp!r}", file=sys.stderr)
        return 1
    print(f"blob loaded ({len(blob)} bytes)")
    return 0


def _send_tuning(transport, data: bytes) -> int:
    print(f"sending TUNING {len(data)} ...")
    transport.send(f"TUNING {len(data)}\n".encode())
    resp = transport.readline()
    if resp != "OK TUNING ready":
        print(f"error: unexpected TUNING response: {resp!r}", file=sys.stderr)
        return 1
    transport.send(data)
    resp = transport.readline()
    if resp != f"OK TUNING {len(data)}":
        print(f"error: tuning failed: {resp!r}", file=sys.stderr)
        return 1
    print(f"tuning loaded ({len(data)} bytes)")
    return 0


def _send_set_array(transport, node_id: int, param_id: int,
                    data: bytes, count: int) -> int:
    """Send SET_ARRAY header + binary float32 payload."""
    print(f"SET_ARRAY {node_id} {param_id} ({count} floats) ...")
    transport.send(f"SET_ARRAY {node_id} {param_id} {count}\n".encode())
    resp = transport.readline()
    if resp != "OK SET_ARRAY ready":
        print(f"error: unexpected response: {resp!r}", file=sys.stderr)
        return 1
    transport.send(data)
    resp = transport.readline()
    if not resp.startswith(f"OK SET_ARRAY {node_id} {param_id}"):
        print(f"error: set-array failed: {resp!r}", file=sys.stderr)
        return 1
    print(f"done ({count} × float32)")
    return 0


def _recv_get_array_chunk(transport, node_id: int, param_id: int,
                          offset: int) -> "tuple[list[float], int]":
    """Send GET_ARRAY and collect one chunk of float values.

    Returns (values, total_length).  Raises RuntimeError on ERR response.
    """
    transport.send(f"GET_ARRAY {node_id} {param_id} {offset}\n".encode())
    values: list[float] = []
    total = 0
    while True:
        resp = transport.readline()
        if resp == "OK GET_ARRAY":
            return values, total
        if resp.startswith("ERR"):
            raise RuntimeError(f"GET_ARRAY failed: {resp}")
        # "OK GET_ARRAY <node_id> <param_id> <total_length> <abs_index> <value>"
        parts = resp.split()
        if len(parts) == 7 and parts[1] == "GET_ARRAY":
            try:
                total = int(parts[4])
                values.append(float(parts[6]))
            except (ValueError, IndexError):
                pass


def _recv_get_array_all(transport, node_id: int,
                        param_id: int) -> list[float]:
    """Read the full array by issuing chunked GET_ARRAY calls as needed."""
    values: list[float] = []
    offset = 0
    while True:
        chunk, total = _recv_get_array_chunk(transport, node_id, param_id, offset)
        values.extend(chunk)
        offset += len(chunk)
        if offset >= total or not chunk:
            break
    return values


def _load_tuning_for_args(args) -> "dict | None":
    """Load the tuning JSON dict for the given args.

    Looks at args.tuning (explicit path) first, then args.project (auto-discover).
    Returns None and prints an error on failure.
    """
    import json as _json
    if getattr(args, "tuning", None):
        path = Path(args.tuning)
    elif getattr(args, "project", None):
        try:
            project = load_project(Path(args.project))
        except Exception as exc:
            print(f"error: {exc}", file=sys.stderr)
            return None
        stem = project.entry.stem
        path = project.output_dir / f"{stem}.tuning.json"
    else:
        print("error: specify --project PATH or --tuning JSON_FILE", file=sys.stderr)
        return None
    try:
        return _json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"error: cannot load tuning JSON {path}: {exc}", file=sys.stderr)
        return None


def _resolve_array_param(args) -> "tuple[int, int, int] | None":
    """Resolve (node_id, param_id, count) for an @array param.

    Prefers --node-id / --param-id numeric flags (count from --count or 0 meaning
    'unknown').  Otherwise looks up args.param_name in the tuning JSON.

    Returns (node_id, param_id, count) or None on error.
    count is 0 when using numeric IDs and the caller should skip count validation.
    """
    if getattr(args, "node_id", None) is not None and \
            getattr(args, "param_id", None) is not None:
        return args.node_id, args.param_id, 0  # count unknown; skip validation

    tuning = _load_tuning_for_args(args)
    if tuning is None:
        return None
    name = getattr(args, "param_name", None)
    entry = next((p for p in tuning.get("params", []) if p["name"] == name), None)
    if entry is None:
        print(f"error: param {name!r} not found in tuning JSON", file=sys.stderr)
        return None
    if entry.get("type") != "float32[]":
        print(f"error: {name!r} is not an @array param (type={entry.get('type')!r})",
              file=sys.stderr)
        return None
    return entry["node_id"], entry["param_id"], entry["count"]


def cmd_set_array(args) -> int:
    """Send a SET_ARRAY command to update an @array parameter at runtime."""
    import struct as _struct

    # 1. Build binary float32 payload
    if getattr(args, "values_file", None):
        try:
            raw = Path(args.values_file).read_bytes()
        except OSError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        count = len(raw) // 4
        data = raw[:count * 4]
    else:
        try:
            floats = [float(v) for v in args.values]
        except ValueError as exc:
            print(f"error: bad value: {exc}", file=sys.stderr)
            return 1
        data = b"".join(_struct.pack("<f", f) for f in floats)
        count = len(floats)

    if count == 0:
        print("error: no values provided", file=sys.stderr)
        return 1

    # 2. Resolve (node_id, param_id, expected_count)
    resolved = _resolve_array_param(args)
    if resolved is None:
        return 1
    node_id, param_id, expected_count = resolved
    if expected_count > 0 and count != expected_count:
        print(f"error: expected {expected_count} values, got {count}", file=sys.stderr)
        return 1

    # 3. Send
    transport = _open_transport(args)
    if transport is None:
        return 1
    try:
        return _send_set_array(transport, node_id, param_id, data, count)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    finally:
        transport.close()


def cmd_get_array(args) -> int:
    """Send a GET_ARRAY command to read an @array parameter from a running graph."""
    # 1. Resolve (node_id, param_id)
    resolved = _resolve_array_param(args)
    if resolved is None:
        return 1
    node_id, param_id, _ = resolved

    # 2. Open transport and read
    transport = _open_transport(args)
    if transport is None:
        return 1
    try:
        values = _recv_get_array_all(transport, node_id, param_id)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    finally:
        transport.close()

    # 3. Print
    if args.csv:
        print(", ".join(repr(v) for v in values))
    else:
        for v in values:
            print(v)
    return 0


class _TcpTransport:
    def __init__(self, host: str, port: int):
        import socket
        self._sock = socket.create_connection((host, port), timeout=10.0)
        self._buf = b""

    def send(self, data: bytes) -> None:
        self._sock.sendall(data)

    def readline(self, timeout: float = 30.0) -> str:
        self._sock.settimeout(timeout)
        while b"\n" not in self._buf:
            chunk = self._sock.recv(4096)
            if not chunk:
                raise EOFError("connection closed")
            self._buf += chunk
        line, self._buf = self._buf.split(b"\n", 1)
        return line.decode("ascii", errors="replace").rstrip("\r")

    def close(self) -> None:
        try:
            self._sock.close()
        except OSError:
            pass


class _SerialTransport:
    def __init__(self, port: str, baud: int):
        try:
            import serial  # type: ignore[import]
        except ImportError:
            raise ImportError(
                "pyserial not installed — run: pip install pyserial"
            )
        self._s = serial.Serial(port, baud, timeout=30.0)
        self._s.reset_input_buffer()

    def send(self, data: bytes) -> None:
        self._s.write(data)

    def readline(self, timeout: float = 30.0) -> str:
        self._s.timeout = timeout
        raw = self._s.readline()
        return raw.decode("ascii", errors="replace").rstrip("\r\n")

    def close(self) -> None:
        try:
            self._s.close()
        except Exception:
            pass


def _open_transport(args):
    """Open a TCP or serial transport based on args. Returns None on error."""
    if args.tcp:
        try:
            host, port_str = args.tcp.rsplit(":", 1)
            port = int(port_str)
            return _TcpTransport(host, port)
        except Exception as exc:
            print(f"error: cannot connect to {args.tcp}: {exc}", file=sys.stderr)
            return None
    elif args.serial:
        try:
            return _SerialTransport(args.serial, args.baud)
        except ImportError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return None
        except Exception as exc:
            print(f"error: cannot open {args.serial}: {exc}", file=sys.stderr)
            return None
    else:
        print("error: specify --tcp HOST:PORT or --serial PORT", file=sys.stderr)
        return None


def cmd_hash(args) -> int:
    """Print the FNV-1a type_id for a fully-qualified node name."""
    fqn = args.name
    tid = node_type_id(fqn)
    print(f"{fqn}  →  0x{tid:08x}  ({tid})")
    return 0


def cmd_list_nodes(args) -> int:
    """List all available node types from project dependencies."""
    project_path = Path(args.project) if args.project else Path.cwd()
    try:
        project = load_project(project_path)
    except Exception as exc:
        print(f"error: failed to load project: {exc}", file=sys.stderr)
        return 1

    dep_paths = project.dependency_paths()
    if not dep_paths:
        print("No dependencies declared in hum.toml.")
        return 0

    for ns, pkg_dir in sorted(dep_paths.items()):
        try:
            manifests = load_package(pkg_dir)
        except Exception as exc:
            print(f"  {ns}: error loading package — {exc}")
            continue
        for name, m in sorted(manifests.items()):
            print(f"  {m.fqn:<40}  type_id=0x{m.type_id:08x}")

    return 0


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def _make_parser():
    import argparse

    parser = argparse.ArgumentParser(
        prog="hum",
        description="Hum audio DSP framework toolchain",
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # build
    p_build = sub.add_parser("build", help="compile project to .humblob")
    p_build.add_argument("--project", metavar="PATH",
                         help="path to hum.toml or project directory")

    # check
    p_check = sub.add_parser("check", help="validate without writing output")
    p_check.add_argument("--project", metavar="PATH")

    # inspect
    p_insp = sub.add_parser("inspect", help="inspect source IR or compiled blob")
    p_insp.add_argument("--ir",   metavar="SOURCE_FILE",
                        help="dump IR of a .hum source file as JSON")
    p_insp.add_argument("--blob", metavar="BLOB_FILE",
                        help="dump header and section info of a .humblob")
    p_insp.add_argument("--project", metavar="PATH",
                        help="project directory (needed with --ir)")

    # map
    p_map = sub.add_parser("map", help="show memory layout of a compiled blob")
    p_map.add_argument("blob_file", metavar="BLOB_FILE")

    # hash
    p_hash = sub.add_parser("hash", help="compute FNV-1a type_id for a node name")
    p_hash.add_argument("name", metavar="NODE_FQN",
                        help='e.g. "std.filters.BiquadLP"')

    # list-nodes
    p_list = sub.add_parser("list-nodes", help="list available node types")
    p_list.add_argument("--project", metavar="PATH")

    # send
    p_send = sub.add_parser(
        "send",
        help="transmit compiled blob (and optional tuning) to a running hum-rt",
    )
    p_send.add_argument(
        "target", metavar="PROJECT_OR_BLOB",
        help="project directory, hum.toml, or .humblob file",
    )
    _send_transport = p_send.add_mutually_exclusive_group()
    _send_transport.add_argument(
        "--tcp", metavar="HOST:PORT",
        help="connect via TCP (e.g. 127.0.0.1:5555)",
    )
    _send_transport.add_argument(
        "--serial", metavar="PORT",
        help="connect via serial port (e.g. /dev/ttyUSB0 or COM3)",
    )
    p_send.add_argument(
        "--baud", metavar="N", type=int, default=115200,
        help="serial baud rate (default: 115200)",
    )
    p_send.add_argument(
        "--no-tuning", action="store_true",
        help="skip sending tuning JSON even if sidecar file exists",
    )

    # set-array
    p_sa = sub.add_parser(
        "set-array",
        help="update an @array param on a running graph",
    )
    p_sa.add_argument("param_name", metavar="NODE.PARAM",
                      help='dotted param name, e.g. "fir1.taps"')
    p_sa_val = p_sa.add_mutually_exclusive_group()
    p_sa_val.add_argument(
        "values", nargs="*", metavar="VALUE", default=[],
        help="inline float values (space-separated)",
    )
    p_sa_val.add_argument(
        "--file", dest="values_file", metavar="PATH.f32",
        help="binary little-endian float32 file (e.g. numpy arr.tofile())",
    )
    p_sa.add_argument("--project", metavar="PATH",
                      help="project directory or hum.toml (for name resolution)")
    p_sa.add_argument("--tuning",  metavar="JSON_FILE",
                      help="path to .tuning.json (default: auto-discover from --project)")
    p_sa.add_argument("--node-id",  dest="node_id",  type=int, default=None,
                      help="numeric node_id (bypasses name resolution)")
    p_sa.add_argument("--param-id", dest="param_id", type=int, default=None,
                      help="numeric param_id (bypasses name resolution)")
    _sa_transport = p_sa.add_mutually_exclusive_group()
    _sa_transport.add_argument("--tcp",    metavar="HOST:PORT")
    _sa_transport.add_argument("--serial", metavar="PORT")
    p_sa.add_argument("--baud", type=int, default=115200)

    # get-array
    p_ga = sub.add_parser(
        "get-array",
        help="read an @array param from a running graph",
    )
    p_ga.add_argument("param_name", metavar="NODE.PARAM",
                      help='dotted param name, e.g. "fir1.taps"')
    p_ga.add_argument("--project", metavar="PATH")
    p_ga.add_argument("--tuning",  metavar="JSON_FILE")
    p_ga.add_argument("--node-id",  dest="node_id",  type=int, default=None)
    p_ga.add_argument("--param-id", dest="param_id", type=int, default=None)
    p_ga.add_argument("--csv", action="store_true",
                      help="print as single comma-separated line")
    _ga_transport = p_ga.add_mutually_exclusive_group()
    _ga_transport.add_argument("--tcp",    metavar="HOST:PORT")
    _ga_transport.add_argument("--serial", metavar="PORT")
    p_ga.add_argument("--baud", type=int, default=115200)

    # gen-checksums
    p_genchk = sub.add_parser("gen-checksums",
                               help="regenerate runtime/nodes/hum_node_checksums.h")
    p_genchk.add_argument("--out",   metavar="PATH", default=None,
                           help="output path (default: runtime/nodes/hum_node_checksums.h)")
    p_genchk.add_argument("--check", action="store_true",
                           help="verify header is current; exit 1 if stale")

    return parser


def main(argv=None) -> int:
    parser = _make_parser()
    args = parser.parse_args(argv)

    def cmd_gen_checksums(args) -> int:
        from pathlib import Path
        from tools.gen_checksums import gen_checksums, check_checksums, _OUT_FILE
        out = Path(args.out) if args.out else _OUT_FILE
        if args.check:
            return 0 if check_checksums(out) else 1
        gen_checksums(out)
        return 0

    dispatch = {
        "build":          cmd_build,
        "check":          cmd_check,
        "inspect":        cmd_inspect,
        "map":            cmd_map,
        "hash":           cmd_hash,
        "list-nodes":     cmd_list_nodes,
        "send":           cmd_send,
        "set-array":      cmd_set_array,
        "get-array":      cmd_get_array,
        "gen-checksums":  cmd_gen_checksums,
    }

    if args.command is None:
        parser.print_help()
        return 0

    fn = dispatch.get(args.command)
    if fn is None:
        parser.print_help()
        return 1

    return fn(args)


if __name__ == "__main__":
    sys.exit(main())
