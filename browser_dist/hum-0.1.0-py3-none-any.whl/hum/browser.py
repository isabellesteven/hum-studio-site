"""In-memory compile front-end for browser / Pyodide use.

``hum.cli`` is the file + argv front-end; this module is the in-memory front-end.
Both drive the *same* compile pipeline (``build → check_types → topo_sort →
compute_liveness → allocate → serialize``) and the same artifact builders in
``hum.artifacts`` — nothing here re-implements compile logic.

Key differences from the CLI suited to a browser REPL:

* Results are returned as Python objects (bytes / dict / str), not written to
  disk — so a page can hand the ``.humblob`` straight to JavaScript.
* The standard-library node packages are located *inside the installed wheel*
  (``hum/_stdlib/std.*``) via :func:`bundled_pkg_dirs`, so a graph can be
  compiled with zero filesystem setup beyond the wheel itself.

Nothing in this module imports sockets, serial, or subprocess, so it loads
cleanly under Pyodide.  ``numpy`` is *not* required — it is only used by
``hum.dsp_ref`` (test/reference DSP), never on the compile path.

Typical use::

    from hum.browser import compile_source
    res = compile_source(open("/proj/src/main.hum").read(),
                         namespaces=["std.io", "std.gain"])
    blob = res.blob            # bytes
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Optional

from hum.artifacts import _build_hum_params_h, _build_tuning_json, _render_map
from hum.compiler import compile_graph
from hum.inspection import InspectionModel
from hum.ir import MemRegion
from hum.project import CodegenConfig, Project, load_project
from hum.serializer import serialize


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class CompileResult:
    """Everything ``hum build`` would have written, returned in memory.

    ``blob`` is the compiled ``.humblob`` (hand this to the runtime / JS).
    ``tuning`` mirrors ``<stem>.tuning.json`` as a Python dict.
    ``params_h`` / ``map`` mirror the corresponding text files.
    ``warnings`` holds any non-fatal messages (e.g. region over high-water).
    """
    blob:     bytes
    tuning:   dict
    params_h: str
    map:      str
    inspection: InspectionModel
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Bundled standard library (packaged inside the wheel at hum/_stdlib/)
# ---------------------------------------------------------------------------

def bundled_stdlib_dir() -> Path:
    """Return the path to the bundled ``_stdlib`` tree inside the wheel.

    Under Pyodide the wheel is unpacked onto the (MEM)FS, so this resolves to a
    real directory that the builder can read and that descriptor modules can be
    imported from.
    """
    return Path(str(resources.files("hum"))) / "_stdlib"


def bundled_namespaces() -> list[str]:
    """List the ``std.*`` namespaces bundled in the wheel."""
    base = bundled_stdlib_dir()
    if not base.is_dir():
        return []
    return sorted(
        p.name for p in base.iterdir()
        if p.is_dir() and (p / "humpkg.toml").exists()
    )


def bundled_pkg_dirs(namespaces: Optional[list[str]] = None) -> dict[str, Path]:
    """Map each requested namespace to its bundled package directory.

    ``namespaces=None`` returns every bundled package.  Raises
    ``FileNotFoundError`` if a requested namespace is not bundled.
    """
    base = bundled_stdlib_dir()
    if namespaces is None:
        namespaces = bundled_namespaces()
    result: dict[str, Path] = {}
    for ns in namespaces:
        pkg_dir = base / ns
        if not (pkg_dir / "humpkg.toml").exists():
            available = ", ".join(bundled_namespaces()) or "(none)"
            raise FileNotFoundError(
                f"bundled stdlib package not found: {ns!r} (looked in {pkg_dir}). "
                f"Available: {available}"
            )
        result[ns] = pkg_dir
    return result


# ---------------------------------------------------------------------------
# Pipeline + artifact assembly (shared by both entry points)
# ---------------------------------------------------------------------------

def _default_regions() -> list[MemRegion]:
    """The two default regions ``load_project`` uses when none are declared."""
    return [
        MemRegion(region_id=0, name="control", size=256 * 1024, flags=[]),
        MemRegion(region_id=1, name="audio",   size=4 * 1024 * 1024, flags=[]),
    ]


def _run_pipeline(project: Project, source: str,
                  pkg_dirs: dict[str, Path]) -> "tuple":
    """Run all compile stages; return ``(compilation, warnings)``.

    Raises ``lark.UnexpectedInput`` on parse errors and
    ``hum.errors.CompileError`` (carrying ``.errors``) on semantic errors.
    """
    compilation = compile_graph(source, project, pkg_dirs)
    ir = compilation.ir

    warnings: list[str] = []
    for region in ir.memory_regions:
        if region.size > 0:
            used = ir.region_high_water.get(region.region_id, 0)
            if used > region.size:
                warnings.append(
                    f"region '{region.name}' (id={region.region_id}) uses {used} "
                    f"bytes but declared size is {region.size} bytes"
                )
    return compilation, warnings


def _make_result(compilation, project_name: str, warnings: list[str]) -> CompileResult:
    """Serialize ``ir`` and build all artifacts — mirrors ``cmd_build``."""
    ir = compilation.ir
    blob = serialize(ir)
    blob_checksum = struct.unpack_from("<I", blob, 36)[0] if len(blob) >= 40 else 0
    tuning = _build_tuning_json(ir, project_name, blob_checksum)
    return CompileResult(
        blob=blob,
        tuning=tuning,
        params_h=_build_hum_params_h(tuning, ir),
        map=_render_map(ir, blob),
        inspection=compilation.inspection,
        warnings=warnings,
    )


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------

def compile_source(
    source:            str,
    *,
    namespaces:        list[str],
    sample_rate:       int = 48000,
    fundamental_block: int = 256,
    memory_regions:    Optional[list[MemRegion]] = None,
    project_name:      str = "project",
    base_dir:          Optional[str] = None,
) -> CompileResult:
    """Compile ``.hum`` *source* text directly, with no ``hum.toml`` on disk.

    ``namespaces`` selects which bundled ``std.*`` packages the graph may
    ``import`` (e.g. ``["std.io", "std.gain"]``).  ``base_dir`` is only needed
    if the source uses ``load(...)`` to read binary files relative to a project
    directory in MEMFS.
    """
    regions = memory_regions if memory_regions is not None else _default_regions()
    project = Project(
        name=project_name,
        version="0.0.0",
        fundamental_block=fundamental_block,
        sample_rate=sample_rate,
        entry=Path("main.hum"),
        output_dir=Path("build"),
        warnings_as_errors=[],
        memory_regions=regions,
        dependencies={},
        codegen=CodegenConfig(),
        project_dir=Path(base_dir) if base_dir else Path("."),
    )
    pkg_dirs = bundled_pkg_dirs(namespaces)
    compilation, warnings = _run_pipeline(project, source, pkg_dirs)
    return _make_result(compilation, project_name, warnings)


def compile_project(
    project_dir: str,
    *,
    extra_namespaces: Optional[list[str]] = None,
) -> CompileResult:
    """Compile a project laid out in MEMFS (``hum.toml`` + entry ``.hum``).

    Dependency resolution works exactly like the CLI, with one addition: any
    declared ``std.*`` dependency whose path does not exist on the (MEM)FS falls
    back to the copy bundled in the wheel.  This lets a page keep the natural
    ``hum.toml`` workflow without shipping the stdlib files itself.

    ``extra_namespaces`` force-injects additional bundled packages (useful when
    a graph imports a namespace that ``hum.toml`` does not declare).
    """
    project = load_project(Path(project_dir))
    source = project.entry.read_text(encoding="utf-8")

    pkg_dirs = dict(project.dependency_paths())
    # Fall back to bundled copies for declared deps missing on the filesystem.
    available = set(bundled_namespaces())
    for ns, path in list(pkg_dirs.items()):
        if ns in available and not Path(path).exists():
            pkg_dirs[ns] = bundled_pkg_dirs([ns])[ns]
    # Force-inject any explicitly requested bundled namespaces.
    for ns, path in bundled_pkg_dirs(extra_namespaces or []).items():
        pkg_dirs.setdefault(ns, path)

    compilation, warnings = _run_pipeline(project, source, pkg_dirs)
    return _make_result(compilation, project.name, warnings)
