"""Build artifacts from a fully-allocated IR.

These helpers render the human/machine-readable outputs that ``hum build``
writes to disk: the memory map, the tuning descriptor JSON, and the generated
``hum_params.h`` C header.  They are factored out of ``hum.cli`` so that both the
file/argv front-end (``hum.cli``) and the in-memory front-end (``hum.browser``)
can produce identical artifacts without one importing the other's internals.
"""

from __future__ import annotations

from hum.ir import Mutability


def _render_map(ir, blob: bytes) -> str:
    """Render a human-readable memory layout map."""
    lines = ["Hum Memory Map", "=" * 40]
    lines.append(f"sample_rate      : {ir.sample_rate} Hz")
    lines.append(f"fundamental_block: {ir.fundamental_block} samples")
    lines.append(f"block_divisor    : {ir.block_divisor}")
    lines.append(f"blob_size        : {len(blob)} bytes")
    lines.append("")

    lines.append("Schedule:")
    for step, node_idx in enumerate(ir.schedule):
        node = ir.nodes[node_idx]
        lines.append(f"  [{step:3d}] {node.name}")

    lines.append("")
    lines.append("Buffers (edges):")
    for edge_id, edge in enumerate(ir.edges):
        buf = edge.buffer
        if buf:
            pt = edge.pin_type
            src = f"node[{edge.src_node}]" if edge.src_node >= 0 else "graph_in"
            dst = f"node[{edge.dst_node}]" if edge.dst_node >= 0 else "graph_out"
            lines.append(
                f"  edge[{edge_id:3d}] {src}.{edge.src_pin} → {dst}.{edge.dst_pin}"
                f"  region={buf.region_id}  offset={buf.offset:#010x}  "
                f"size={buf.size}  ({pt.channels}ch × {pt.block_size} × f32)"
            )

    lines.append("")
    lines.append("State:")
    for sa in ir.state_assignments:
        node = ir.nodes[sa.node_index]
        lines.append(
            f"  node[{sa.node_index:3d}] {node.name:<20}"
            f"  region={sa.region_id}  offset={sa.state_offset:#010x}"
            f"  state={node.descriptor.state_size}B"
        )
        if sa.param_copy_size > 0:
            lines.append(
                f"           param_copy  offset={sa.param_copy_offset:#010x}"
                f"  size={sa.param_copy_size}B"
            )

    return "\n".join(lines) + "\n"


def _build_tuning_json(ir, project_name: str, blob_checksum: int = 0) -> dict:
    """Build the tuning descriptor dict from the IR.

    Includes all @param and @array parameters across all nodes.
    Scalar @param entries use type "float32" with a scalar default.
    Array @array entries use type "float32[]" with count and the full default list.
    """
    nodes = []
    params = []
    for node_idx, node in enumerate(ir.nodes):
        nodes.append({"node_id": node_idx, "node": node.name})
        for pname, mut in node.param_mutability.items():
            if mut not in (Mutability.PARAM, Mutability.ARRAY):
                continue
            val = node.params.get(pname)
            if isinstance(val, list):
                # @array param — emit full array; no min/max (ranges don't apply)
                params.append({
                    "name":     f"{node.name}.{pname}",
                    "node":     node.name,
                    "node_id":  node_idx,
                    "param_id": _param_id_for(node, pname),
                    "type":     "float32[]",
                    "count":    len(val),
                    "mutable":  "array",
                    "default":  [float(v) for v in val],
                    "min":      None,
                    "max":      None,
                })
            else:
                # @param scalar
                lo, hi = node.param_ranges.get(pname, (None, None))
                params.append({
                    "name":     f"{node.name}.{pname}",
                    "node":     node.name,
                    "node_id":  node_idx,
                    "param_id": _param_id_for(node, pname),
                    "type":     "float32",
                    "mutable":  "param",
                    "default":  float(val) if val is not None else 0.0,
                    "min":      float(lo) if lo is not None else None,
                    "max":      float(hi) if hi is not None else None,
                })
    return {
        "project":        project_name,
        "blob_version":   1,
        "blob_checksum":  blob_checksum,
        "nodes":          nodes,
        "params":         sorted(params, key=lambda p: p["name"]),
    }


def _param_id_for(node, pname: str) -> int:
    """Return the param_id (0-based index) for a named param in a node."""
    for idx, name in enumerate(node.params.keys()):
        if name == pname:
            return idx
    return 0


_MUT_CODE_MAP = {
    "param":  "HUM_MUTABLE_PARAM",
    "array":  "HUM_MUTABLE_ARRAY",
}

_TYPE_CODE_MAP = {
    "float32": "HUM_FLOAT32",
}


def _compute_runtime_min_bytes(ir) -> int:
    """Conservative lower bound for HUM_CAP_CONTROL arena bytes on 32-bit ARM.

    Covers all ctrl-arena allocations made by hum_init on a target with 4-byte
    pointers and no arena-specific memory flags (e.g. Daisy Seed):
      - HumNodeInstance array
      - HumDerivedCtrl array + derived double-buffers
      - HumArrayParam array + array param double-buffers
      - Per-node live_params[], HumScalarParam[], state, param-copies
      - HumRuntimeScheduleEntry array + per-entry HumPinBuffer[] arrays

    Struct sizes match the Cortex-M7 (32-bit pointer) ABI.
    """
    # 32-bit ARM struct sizes (4-byte pointers, natural alignment)
    SZ_NODE_INSTANCE  = 40   # HumNodeInstance
    SZ_DERIVED_CTRL   = 24   # HumDerivedCtrl
    SZ_SCALAR_PARAM   = 16   # HumScalarParam
    SZ_SCHEDULE_ENTRY = 16   # HumRuntimeScheduleEntry
    SZ_PIN_BUFFER     = 8    # HumPinBuffer
    SZ_ARRAY_PARAM    = 28   # HumArrayParam
    SZ_FLOAT          = 4

    node_count  = len(ir.nodes)
    sched_count = len(ir.schedule)
    total       = 0

    # Node instance array
    total += node_count * SZ_NODE_INSTANCE

    n_derived   = 0
    n_arr_total = 0
    for node in ir.nodes:
        n_total  = len(node.params)
        n_scalar = sum(1 for m in node.param_mutability.values()
                       if m == Mutability.PARAM)
        n_arr    = sum(1 for m in node.param_mutability.values()
                       if m == Mutability.ARRAY)

        total += n_total  * SZ_FLOAT         # live_params[]
        total += n_scalar * SZ_SCALAR_PARAM  # HumScalarParam[]
        total += node.descriptor.state_size  # node state (ctrl on no-flag targets)

        if node.derived_size > 0:
            n_derived += 1
            total += 2 * node.derived_size   # derived double-buffer

        # Array param double-buffers
        for pname, mut in node.param_mutability.items():
            if mut == Mutability.ARRAY:
                val = node.params.get(pname, [])
                n_elem = len(val) if isinstance(val, list) else 1
                total += 2 * n_elem * SZ_FLOAT
        n_arr_total += n_arr

    # Param-copies (const array params, also in ctrl arena)
    for sa in ir.state_assignments:
        total += sa.param_copy_size

    # Derived ctrl blocks
    total += n_derived * SZ_DERIVED_CTRL

    # Array param ctrl blocks
    total += n_arr_total * SZ_ARRAY_PARAM

    # Schedule entry array
    total += sched_count * SZ_SCHEDULE_ENTRY

    # Per-entry HumPinBuffer[] arrays (inputs + outputs)
    for node_idx in ir.schedule:
        in_cnt  = sum(1 for e in ir.edges if e.dst_node == node_idx)
        out_cnt = sum(1 for e in ir.edges if e.src_node == node_idx)
        total  += (in_cnt + out_cnt) * SZ_PIN_BUFFER

    # Fixed overhead for alignment rounding and minor bookkeeping
    total += 256

    return total


def _build_hum_params_h(tuning: dict, ir) -> str:
    """Generate the hum_params.h C header from a tuning descriptor and IR."""
    lines = [
        "/* hum_params.h — generated by hum build, do not edit */",
        "#pragma once",
        '#include "hum.h"',
        "",
    ]

    params = tuning["params"]
    count  = len(params)
    project = tuning["project"].upper().replace("-", "_").replace(".", "_")

    lines.append(f"#define HUM_PARAM_COUNT_{project} {count}")
    lines.append("")

    # Macro defines for each param
    for p in params:
        safe = (p["name"].replace(".", "_").replace("-", "_").upper())
        lines.append(f"#define HUM_PARAM_{safe}_NODE_ID   {p['node_id']}U")
        lines.append(f"#define HUM_PARAM_{safe}_PARAM_ID  {p['param_id']}U")

    if params:
        lines.append("")
    lines.append(f"static const HumTuningEntry hum_tuning_entries[{max(count,1)}] = {{")
    for p in params:
        mut_code = _MUT_CODE_MAP.get(p["mutable"], "HUM_MUTABLE_PARAM")
        # Array params carry their defaults as a list; the C struct holds one scalar
        # placeholder (0.0f).  The actual array data is managed by the tuning agent.
        default_scalar = (
            p["default"][0] if isinstance(p["default"], list) else p["default"]
        )
        lines.append(
            f'    {{ "{p["name"]}", {p["node_id"]}U, {p["param_id"]}U, '
            f'{mut_code}, {default_scalar:.6f}f }},'
        )
    if not params:
        lines.append("    { NULL, 0, 0, 0, 0.0f },")
    lines.append("};")
    lines.append("")

    # Memory region setup
    # HUM_RUNTIME_REGION_ID must not match any blob region_id.  It identifies
    # the HUM_CAP_CONTROL arena used by the runtime for internal bookkeeping
    # (nodes, schedule, state).  Keeping it separate from blob data regions
    # prevents hum_arena_alloc from overwriting audio pin buffers.
    used_ids = {r.region_id for r in ir.memory_regions}
    runtime_id = next(v for v in range(0xFF, -1, -1) if v not in used_ids)
    lines.append("/* Host memory regions")
    lines.append(" *")
    lines.append(" * Provide one HumMemRegion per HUM_REGION_n_ID (blob data) plus one")
    lines.append(" * for HUM_RUNTIME_REGION_ID (runtime bookkeeping, not in the blob).")
    lines.append(" * The HUM_CAP_CONTROL arena MUST use HUM_RUNTIME_REGION_ID —")
    lines.append(" * see hum.h HUM_CAP_CONTROL for details. */")
    lines.append(f"#define HUM_RUNTIME_REGION_ID     0x{runtime_id:02X}U")
    lines.append("")
    lines.append(f"#define HUM_REGION_COUNT           {len(ir.memory_regions)}U")
    for i, region in enumerate(ir.memory_regions):
        flags_note = ", ".join(region.flags)
        comment = f"  /* {region.name}" + (f": {flags_note}" if flags_note else "") + " */"
        min_bytes = ir.region_high_water.get(region.region_id, 0)
        lines.append(f"#define HUM_REGION_{i}_ID          {region.region_id}U{comment}")
        lines.append(f"#define HUM_REGION_{i}_MIN_BYTES   {min_bytes}U  /* allocator high-water mark */")
    lines.append("")

    # HUM_CAP_CONTROL arena lower bound (runtime bookkeeping + node state).
    # Computed for 32-bit ARM (4-byte pointers); regenerate after changing the graph.
    runtime_min = _compute_runtime_min_bytes(ir)
    lines.append(f"#define HUM_RUNTIME_MIN_BYTES      {runtime_min}U  /* hum_init ctrl-arena usage, 32-bit ARM */")
    lines.append("")

    return "\n".join(lines)
