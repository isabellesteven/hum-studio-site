"""Node manifest and package loading.

A ``.humnode`` TOML file defines one node type.
A ``humpkg.toml`` file defines a package (collection of nodes).

NODE_MANIFEST.md defines the manifest contract.

Key invariants:
- ``type_id``  = ``fnv.node_type_id(namespace + "." + name)``
- ``checksum`` = ``fnv.manifest_checksum(file_bytes)``  (newline-canonicalized text bytes)
"""

from __future__ import annotations

import ast
import importlib
import operator
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-reuse-import]

from hum.fnv import manifest_checksum, node_type_id
from hum.ir import DataType, Mutability, NodeDescriptor, ParamCopy


# ---------------------------------------------------------------------------
# Manifest sub-structures
# ---------------------------------------------------------------------------

@dataclass
class PinSpec:
    """Specification for one pin (or pin array) from [[pins.inputs/.outputs]]."""
    name:       str
    channels:   int | str        # int >= 1, or "any"
    block_size: int | str        # int >= 1, or "graph"
    data_type:  DataType
    count:      str | None       # "variable" for variable pin count
    channel_group: Optional[str] = None  # equality group local to one node instance
    count_from_channels: Optional[str] = None  # variadic arity = channels of named pin
    channels_from_count: Optional[str] = None  # channel width = arity of named variadic pin
    min_count:  Optional[int] = None
    max_count:  Optional[int] = None


@dataclass
class ParamSpec:
    """Specification for one parameter from [[params]]."""
    name:       str
    param_type: str              # "float32" | "int" | "bool" | "string"
    default:    Any
    min_val:    Optional[float] = None
    max_val:    Optional[float] = None
    mutable:    Mutability = Mutability.CONST
    source:     Optional[str] = None  # compiler-derived/system value source


_COMPUTE_COST_MAP = {"light": 0, "medium": 1, "heavy": 2}


@dataclass
class NodeManifest:
    """The complete contract for a node type, loaded from a .humnode file."""
    name:                str
    namespace:           str
    fqn:                 str       # fully-qualified: "namespace.name"
    version:             str
    api_version:         int
    description:         str
    type_id:             int       # FNV-1a of fqn
    checksum:            int       # FNV-1a of newline-canonicalized .humnode bytes
    descriptor_provider: str       # "builtin" | "python"
    descriptor_module:   Optional[str]
    descriptor_function: Optional[str]
    inputs:              list[PinSpec]
    outputs:             list[PinSpec]
    params:              list[ParamSpec]
    state_size:          int       # static bytes; 0 when state_size_expr is used
    state_mem_flags:     list[str]
    state_size_expr:     Optional[str] = None  # declarative per-instance byte formula
    derived_size:              int = 0    # bytes per derived state buffer; 0 = no compute
    compute_cost:              int = 0    # 0=light, 1=medium, 2=heavy
    compute_trigger_params:    list = field(default_factory=list)  # list[str] param names


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_DATA_TYPE_MAP = {
    "float32":  DataType.FLOAT32,
    "fixed32":  DataType.FIXED32,
    "ufixed32": DataType.UFIXED32,
}

_MUTABLE_MAP = {
    "const":  Mutability.CONST,
    "param":  Mutability.PARAM,
    "array":  Mutability.ARRAY,
}

_DERIVED_PARAM_SOURCES = {"graph.sample_rate", "graph.block_size"}


def _validate_param_source(source: Optional[str], name: str) -> Optional[str]:
    if source is None:
        return None
    if not isinstance(source, str) or not source.strip():
        raise ValueError(f"source for param {name!r} must be a non-empty string")
    if source in _DERIVED_PARAM_SOURCES:
        return source
    if source.startswith("channel_group:") and source.split(":", 1)[1].strip():
        return source
    if source.startswith("pin_count:") and source.split(":", 1)[1].strip():
        return source
    raise ValueError(
        f"unknown source {source!r} for param {name!r}; expected graph.sample_rate, "
        "graph.block_size, channel_group:<name>, or pin_count:<name>"
    )


_ALLOWED_BINOPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.FloorDiv: operator.floordiv,
}
_ALLOWED_UNARYOPS = {ast.UAdd: operator.pos, ast.USub: operator.neg}


def resource_expression_names(expr: str) -> set[str]:
    """Return variable names referenced by a declarative resource expression.

    The expression language is intentionally tiny: integer literals, names,
    parentheses, ``+``, ``-``, ``*`` and ``//``.
    """
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as exc:
        raise ValueError(f"invalid resource expression {expr!r}: {exc.msg}") from exc

    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            names.add(node.id)
        elif isinstance(node, (ast.Expression, ast.Load, ast.Constant, ast.BinOp, ast.UnaryOp)):
            continue
        elif isinstance(node, tuple(_ALLOWED_BINOPS) + tuple(_ALLOWED_UNARYOPS)):
            continue
        else:
            raise ValueError(
                f"unsupported syntax {type(node).__name__} in resource expression {expr!r}"
            )
    return names


def evaluate_resource_expression(expr: str, values: dict[str, Any]) -> int:
    """Evaluate the restricted integer resource-expression language."""
    tree = ast.parse(expr, mode="eval")

    def ev(node):
        if isinstance(node, ast.Expression):
            return ev(node.body)
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool) or not isinstance(node.value, int):
                raise ValueError(f"resource expression constants must be integers: {expr!r}")
            return node.value
        if isinstance(node, ast.Name):
            if node.id not in values:
                raise ValueError(f"resource expression references unknown value {node.id!r}")
            value = values[node.id]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError(f"resource value {node.id!r} must be numeric")
            if isinstance(value, float) and not value.is_integer():
                raise ValueError(f"resource value {node.id!r} must be integral, got {value}")
            return int(value)
        if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BINOPS:
            return _ALLOWED_BINOPS[type(node.op)](ev(node.left), ev(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARYOPS:
            return _ALLOWED_UNARYOPS[type(node.op)](ev(node.operand))
        raise ValueError(f"unsupported syntax in resource expression {expr!r}")

    result = ev(tree)
    if not isinstance(result, int) or result < 0:
        raise ValueError(f"resource expression must produce a non-negative integer, got {result}")
    return result


def _parse_pin(data: dict) -> PinSpec:
    name = data["name"]
    channels   = data.get("channels", 1)
    block_size = data.get("block_size", "graph")
    dt_str     = data.get("data_type", "float32")

    if dt_str not in _DATA_TYPE_MAP:
        raise ValueError(
            f"unknown data_type {dt_str!r} for pin {name!r}; "
            f"valid values: {list(_DATA_TYPE_MAP)}"
        )
    data_type = _DATA_TYPE_MAP[dt_str]

    if not (channels == "any" or (isinstance(channels, int) and not isinstance(channels, bool) and channels >= 1)):
        raise ValueError(f"channels for pin {name!r} must be an integer >= 1 or 'any'")
    if not (block_size == "graph" or (isinstance(block_size, int) and not isinstance(block_size, bool) and block_size >= 1)):
        raise ValueError(f"block_size for pin {name!r} must be an integer >= 1 or 'graph'")

    count         = data.get("count")
    channel_group = data.get("channel_group")
    count_from_channels = data.get("count_from_channels")
    channels_from_count = data.get("channels_from_count")
    min_count     = data.get("min_count")
    max_count     = data.get("max_count")

    if count not in (None, "variable"):
        raise ValueError(f"count for pin {name!r} must be 'variable' when present")
    for field_name, value in (("min_count", min_count), ("max_count", max_count)):
        if value is not None and (not isinstance(value, int) or isinstance(value, bool) or value < 1):
            raise ValueError(f"{field_name} for pin {name!r} must be an integer >= 1")
    if min_count is not None and max_count is not None and min_count > max_count:
        raise ValueError(f"min_count for pin {name!r} may not exceed max_count")
    if count != "variable" and (min_count is not None or max_count is not None):
        raise ValueError(f"min_count/max_count for pin {name!r} require count='variable'")

    if channel_group is not None:
        if not isinstance(channel_group, str) or not channel_group.strip():
            raise ValueError(
                f"channel_group for pin {data.get('name')!r} must be a non-empty string"
            )

    for field_name, value in (
        ("count_from_channels", count_from_channels),
        ("channels_from_count", channels_from_count),
    ):
        if value is not None and (not isinstance(value, str) or not value.strip()):
            raise ValueError(
                f"{field_name} for pin {data.get('name')!r} must be a non-empty pin name"
            )

    if count_from_channels is not None and count != "variable":
        raise ValueError(
            f"pin {data.get('name')!r}: count_from_channels requires count='variable'"
        )
    if channels_from_count is not None and channels != "any":
        raise ValueError(
            f"pin {data.get('name')!r}: channels_from_count requires channels='any'"
        )

    return PinSpec(
        name=data["name"],
        channels=channels,
        block_size=block_size,
        data_type=data_type,
        count=count,
        channel_group=channel_group,
        count_from_channels=count_from_channels,
        channels_from_count=channels_from_count,
        min_count=min_count,
        max_count=max_count,
    )


def _parse_param(data: dict) -> ParamSpec:
    param_type = data.get("type", "float32")
    if param_type not in {"float32", "int", "bool", "string"}:
        raise ValueError(
            f"unknown parameter type {param_type!r} for param {data.get('name')!r}; "
            "valid values: float32, int, bool, string"
        )
    mutable_str = data.get("mutable", "const")
    if mutable_str not in _MUTABLE_MAP:
        raise ValueError(
            f"unknown mutable type {mutable_str!r} for param {data.get('name')!r}; "
            f"valid values: {list(_MUTABLE_MAP)}"
        )
    source = _validate_param_source(data.get("source"), data.get("name", "<unnamed>"))
    if source is not None and mutable_str != "const":
        raise ValueError(f"derived/system param {data.get('name')!r} must be mutable='const'")
    return ParamSpec(
        name=data["name"],
        param_type=param_type,
        default=data.get("default"),
        min_val=data.get("min"),
        max_val=data.get("max"),
        mutable=_MUTABLE_MAP[mutable_str],
        source=source,
    )


# ---------------------------------------------------------------------------
# Public loaders
# ---------------------------------------------------------------------------

def load_humnode(path: Path, namespace: str, override_name: Optional[str] = None) -> NodeManifest:
    """Load a ``.humnode`` TOML file and return a ``NodeManifest``.

    ``override_name`` is used when a ``humpkg.toml`` entry's ``name`` differs
    from the ``[node].name`` in the file (all biquad variants share one file).
    The checksum is FNV-1a over newline-canonicalized file bytes, so LF and CRLF checkouts are equivalent.
    """
    raw_bytes = path.read_bytes()
    data      = tomllib.loads(raw_bytes.decode("utf-8"))

    node_data = data["node"]
    name      = override_name if override_name is not None else node_data["name"]
    fqn       = f"{namespace}.{name}"

    desc_data = data.get("descriptor", {})
    provider  = desc_data.get("provider", "builtin")
    if provider not in {"builtin", "python"}:
        raise ValueError(f"unknown descriptor provider {provider!r}; expected 'builtin' or 'python'")
    if provider == "python" and (not desc_data.get("module") or not desc_data.get("function")):
        raise ValueError("python descriptor provider requires descriptor.module and descriptor.function")

    mem_data         = data.get("memory", {})
    raw_state_size   = mem_data.get("state_size", 0)
    if isinstance(raw_state_size, str):
        state_size = 0
        state_size_expr = raw_state_size
    elif isinstance(raw_state_size, int) and not isinstance(raw_state_size, bool) and raw_state_size >= 0:
        state_size = raw_state_size
        state_size_expr = None
    else:
        raise ValueError("memory.state_size must be a non-negative integer or resource expression string")
    state_mem_flags  = mem_data.get("state_mem_flags", [])

    compute_data          = data.get("compute", {})
    derived_size          = compute_data.get("derived_size", 0)
    compute_cost_str      = compute_data.get("compute_cost", "light")
    if compute_cost_str not in _COMPUTE_COST_MAP:
        raise ValueError(
            f"unknown compute_cost {compute_cost_str!r}; valid values: {list(_COMPUTE_COST_MAP)}"
        )
    compute_cost          = _COMPUTE_COST_MAP[compute_cost_str]
    compute_trigger_params = compute_data.get("trigger_params", [])

    inputs  = [_parse_pin(p) for p in data.get("pins", {}).get("inputs",  [])]
    outputs = [_parse_pin(p) for p in data.get("pins", {}).get("outputs", [])]
    params  = [_parse_param(p) for p in data.get("params", [])]

    pin_names = {p.name for p in inputs + outputs}
    variadic_names = {p.name for p in inputs + outputs if p.count == "variable"}
    for p in inputs + outputs:
        if p.count_from_channels is not None and p.count_from_channels not in pin_names:
            raise ValueError(
                f"pin {p.name!r}: count_from_channels references unknown pin "
                f"{p.count_from_channels!r}"
            )
        if p.channels_from_count is not None and p.channels_from_count not in variadic_names:
            raise ValueError(
                f"pin {p.name!r}: channels_from_count references unknown variadic pin "
                f"{p.channels_from_count!r}"
            )

    if state_size_expr is not None:
        names = resource_expression_names(state_size_expr)
        param_names = {p.name for p in params}
        unknown = sorted(names - param_names)
        if unknown:
            raise ValueError(
                f"memory.state_size references unknown parameter(s): {', '.join(unknown)}"
            )

    return NodeManifest(
        name=name,
        namespace=namespace,
        fqn=fqn,
        version=node_data.get("version", "0.0.0"),
        api_version=node_data.get("api_version", 1),
        description=node_data.get("description", ""),
        type_id=node_type_id(fqn),
        checksum=manifest_checksum(raw_bytes),
        descriptor_provider=provider,
        descriptor_module=desc_data.get("module"),
        descriptor_function=desc_data.get("function"),
        inputs=inputs,
        outputs=outputs,
        params=params,
        state_size=state_size,
        state_mem_flags=state_mem_flags,
        state_size_expr=state_size_expr,
        derived_size=derived_size,
        compute_cost=compute_cost,
        compute_trigger_params=compute_trigger_params,
    )


def load_package(pkg_dir: Path) -> dict[str, NodeManifest]:
    """Load all node manifests from a package directory.

    Reads ``humpkg.toml`` for the node list, then loads each referenced
    ``.humnode`` file.  Returns ``{simple_name: NodeManifest}``.
    """
    pkg_file  = pkg_dir / "humpkg.toml"
    raw_bytes = pkg_file.read_bytes()
    data      = tomllib.loads(raw_bytes.decode("utf-8"))

    namespace = data["package"]["name"]
    manifests: dict[str, NodeManifest] = {}

    for entry in data.get("nodes", []):
        node_name     = entry["name"]
        manifest_path = pkg_dir / entry["manifest"]
        manifest      = load_humnode(manifest_path, namespace, override_name=node_name)
        manifests[node_name] = manifest

    return manifests


# ---------------------------------------------------------------------------
# Declarative resource sizing
# ---------------------------------------------------------------------------

def resolve_manifest_descriptor(manifest: NodeManifest, params: dict[str, Any]) -> NodeDescriptor:
    """Resolve a builtin/declarative manifest's per-instance resources.

    ``memory.state_size`` may be either a static integer or a restricted
    arithmetic expression over manifest parameter names.  Parameters referenced
    by the expression are structural inputs to resource sizing, so their
    declared min/max bounds are enforced as hard constraints here.
    """
    if manifest.state_size_expr is None:
        size = manifest.state_size
    else:
        names = resource_expression_names(manifest.state_size_expr)
        by_name = {p.name: p for p in manifest.params}
        for name in names:
            if name not in params:
                raise RuntimeError(f"E045: resource expression requires parameter {name!r}")
            spec = by_name[name]
            value = params[name]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise RuntimeError(f"E045: resource parameter {name!r} must be numeric")
            if spec.min_val is not None and value < spec.min_val:
                raise RuntimeError(
                    f"E045: resource parameter {name!r}={value} is below minimum {spec.min_val}"
                )
            if spec.max_val is not None and value > spec.max_val:
                raise RuntimeError(
                    f"E045: resource parameter {name!r}={value} is above maximum {spec.max_val}"
                )
        try:
            size = evaluate_resource_expression(manifest.state_size_expr, params)
        except ValueError as exc:
            raise RuntimeError(f"E045: {exc}") from exc

    return NodeDescriptor(
        state_size=size,
        state_mem_flags=list(manifest.state_mem_flags),
    )


# ---------------------------------------------------------------------------
# Python descriptor invocation (fallback)
# ---------------------------------------------------------------------------

def invoke_descriptor(
    manifest: NodeManifest,
    params:   dict,
    pkg_dir:  Path,
) -> NodeDescriptor:
    """Call the Python descriptor function for a parameterised node.

    The module is imported with the package directory's parent on ``sys.path``
    so that ``import std.filters.fir_descriptor`` resolves correctly.

    Exceptions are caught and re-raised as ``RuntimeError`` with code ``E045``;
    the builder converts this to a proper ``HumError``.
    """
    assert manifest.descriptor_provider == "python"
    assert manifest.descriptor_module is not None
    assert manifest.descriptor_function is not None

    # Descriptor modules live inside the package directory itself.
    # We add pkg_dir (not pkg_dir.parent) so that a simple module name like
    # "fir_descriptor" resolves to pkg_dir/fir_descriptor.py.
    # pkg_dir names such as "std.filters" contain dots and are not valid Python
    # package paths, so we cannot use pkg_dir.parent with a dotted module name.
    search_dir = str(pkg_dir)
    inserted = search_dir not in sys.path
    if inserted:
        sys.path.insert(0, search_dir)
    try:
        mod = importlib.import_module(manifest.descriptor_module)
        fn  = getattr(mod, manifest.descriptor_function)
        result = fn(params)
    except Exception as exc:
        raise RuntimeError(
            f"E045: descriptor function '{manifest.descriptor_module}."
            f"{manifest.descriptor_function}' raised: {exc}"
        ) from exc
    finally:
        if inserted and search_dir in sys.path:
            sys.path.remove(search_dir)

    return result
