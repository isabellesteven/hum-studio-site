"""Liveness analysis — computes edge lifetime intervals.

After topo-sort has set each node's ``schedule_index``, liveness analysis
assigns a half-open interval ``[born, dies)`` to every edge, where:

  ``born`` = the schedule step at which the edge's buffer is first written
             (i.e. the producing node's schedule_index, or 0 for graph inputs)

  ``dies`` = the schedule step *after* the last node that reads from the buffer
             (i.e. the consuming node's schedule_index + 1, or
             len(ir.schedule) for graph outputs — meaning the buffer is live
             until the very end of the process block)

Liveness is computed even though the v1 allocator assigns one buffer per edge
and ignores overlap.  Future allocators can use this data for buffer reuse.

Prerequisite: ``topo_sort(ir)`` must have been called first.
"""

from __future__ import annotations

from hum.ir import EdgeLiveness, IR


def compute_liveness(ir: IR) -> None:
    """Fill in ``edge.liveness`` for every edge in *ir*.

    Mutates the IR in place.  Safe to call multiple times (idempotent).
    """
    n_steps = len(ir.schedule)

    for edge in ir.edges:
        # ── born: when is the buffer first written? ───────────────────────────
        if edge.src_node == -1:
            # Graph input boundary — buffer arrives at step 0
            born = 0
        else:
            born = ir.nodes[edge.src_node].schedule_index

        # ── dies: when is the buffer last consumed + 1? ──────────────────────
        if edge.dst_node == -1:
            # Graph output boundary — buffer must survive the full process block
            dies = n_steps
        else:
            dies = ir.nodes[edge.dst_node].schedule_index + 1

        edge.liveness = EdgeLiveness(born=born, dies=dies)
