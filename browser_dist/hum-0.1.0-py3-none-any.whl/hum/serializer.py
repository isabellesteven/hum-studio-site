"""Binary blob serializer — converts a fully-allocated IR to a .humblob.

BLOB.md describes the serialized contract; this module defines the emitted bytes.

Layout:
    [File Header        ]   64 bytes
    [Section Directory  ]   section_count × 20 bytes
    [Node Table         ]   node_count × 28 bytes
    [Schedule Table     ]   variable (one entry per schedule step)
    [Parameter Data     ]   packed per-node param blocks
    [State Descriptors  ]   node_count × 12 bytes
    [Buffer Descriptors ]   edge_count × 20 bytes
    [Feedback Descriptors] optional
    [Graph I/O Descriptors] host-visible boundary pins
    [Checksum           ]   8 bytes

All values are little-endian.
The graph_checksum covers all bytes except the 4-byte checksum field at
offset 36 in the header (those bytes are treated as zero when hashing).
"""

from __future__ import annotations

import struct
from typing import Any

from hum.fnv import fnv1a_32
from hum.ir import DataType, IR, Mutability

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_MAGIC            = b"HUM\x00"
_FORMAT_VERSION   = 2
_API_VERSION      = 1
_HEADER_SIZE      = 64
_SECTION_DIR_OFFSET = _HEADER_SIZE   # section directory immediately follows header
_SECTION_ENTRY_SIZE = 20

# Section type codes
_SEC_NODE_TABLE    = 0x0001
_SEC_SCHEDULE      = 0x0002
_SEC_PARAM_DATA    = 0x0003
_SEC_STATE_DESC    = 0x0004
_SEC_BUFFER_DESC   = 0x0005
_SEC_FEEDBACK_DESC = 0x0008
_SEC_GRAPH_IO_DESC = 0x0009
_SEC_CHECKSUM      = 0x00FF

# Data type encodings
_DT_FLOAT32  = 0
_DT_FIXED32  = 1
_DT_UFIXED32 = 2

_DT_MAP = {
    DataType.FLOAT32:  _DT_FLOAT32,
    DataType.FIXED32:  _DT_FIXED32,
    DataType.UFIXED32: _DT_UFIXED32,
}

# Mutability encodings (must match HUM_MUTABLE_* in hum.h)
_MUT_CONST  = 0
_MUT_PARAM  = 1
_MUT_ARRAY  = 2

_MUT_MAP = {
    Mutability.CONST:  _MUT_CONST,
    Mutability.PARAM:  _MUT_PARAM,
    Mutability.ARRAY:  _MUT_ARRAY,
}

# Struct format strings (little-endian)
_FMT_HEADER      = "<4sBBBBIIIIHHHHBxxxI24s"   # 64 bytes
_FMT_SECTION_DIR = "<HHIIII"                     # 20 bytes
_FMT_SCHED_HDR   = "<HHHH"                       # 8 bytes

# Node entry base (32 bytes):
# type_id(4)+manifest_checksum(4)+param_data_offset(4)+param_data_size(4)
# +state_desc_index(4)+name_offset(2)+input_pin_count(2)+output_pin_count(2)
# +derived_size(2)+compute_trigger_count(1)+compute_cost(1)+reserved(2)
_FMT_NODE_ENTRY_BASE = "<IIIIIHHHH" "BBH"   # 32 bytes fixed base

# Then followed by compute_trigger_count × uint16 trigger_param_indices,
# padded to 4-byte alignment.

# Param descriptor: param_id(2),type(1),mutable(1),value_offset(4),value_size(4),mem_flags(1),copy_at_init(1),reserved(2) = 16
_FMT_PARAM_DESC  = "<HBBIIBBH"

# Pin assignment: region_id(1)+data_type(1)+channels(2)+block_size(2)+reserved(2)+offset(4)+sample_rate(4) = 16
_FMT_PIN_ASSIGN  = "<BBHHHII"

# State descriptor: state_size(4)+param_copy_size(4)+state_region_flags(1)+param_copy_flags(1)+alignment(1)+pad(1) = 12
_FMT_STATE_DESC  = "<IIBBBx"

# Buffer descriptor: region_id(1)+data_type(1)+channels(2)+block_size(2)+reserved(2)+offset(4)+size(4)+sample_rate(4) = 20
_FMT_BUFFER_DESC = "<BBHHHIII"

# Feedback descriptor: schedule_step(2)+output_pin(2)+region_id(1)+data_type(1)
#   +channels(2)+block_size(2)+reserved(2)+shadow_offset(4)+shadow_size(4)+init_value(4f) = 24
_FMT_FEEDBACK_DESC = "<HHBBHHHIIf"

# Verify sizes at module load
assert struct.calcsize(_FMT_PIN_ASSIGN)       == 16, struct.calcsize(_FMT_PIN_ASSIGN)
assert struct.calcsize(_FMT_STATE_DESC)       == 12, struct.calcsize(_FMT_STATE_DESC)
assert struct.calcsize(_FMT_BUFFER_DESC)      == 20, struct.calcsize(_FMT_BUFFER_DESC)
assert struct.calcsize(_FMT_NODE_ENTRY_BASE)  == 32, struct.calcsize(_FMT_NODE_ENTRY_BASE)
assert struct.calcsize(_FMT_PARAM_DESC)       == 16, struct.calcsize(_FMT_PARAM_DESC)
assert struct.calcsize(_FMT_FEEDBACK_DESC)    == 24, struct.calcsize(_FMT_FEEDBACK_DESC)

# Param block header: param_count(2), reserved(2)
_FMT_PARAM_BLOCK = "<HH"


# ---------------------------------------------------------------------------
# Internal writer
# ---------------------------------------------------------------------------

class _BlobWriter:
    __slots__ = ("_buf",)

    def __init__(self) -> None:
        self._buf = bytearray()

    def pos(self) -> int:
        return len(self._buf)

    def write(self, data: bytes) -> None:
        self._buf += data

    def pack(self, fmt: str, *args: Any) -> None:
        self._buf += struct.pack(fmt, *args)

    def zeros(self, n: int) -> None:
        self._buf += bytes(n)

    def patch_u32(self, offset: int, value: int) -> None:
        struct.pack_into("<I", self._buf, offset, value)

    def to_bytes(self) -> bytes:
        return bytes(self._buf)


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------

def _node_entry_size(trigger_count: int) -> int:
    """Byte size of a single node table entry given its trigger param count.

    32-byte fixed base + trigger_count × 2 bytes, rounded up to 4-byte alignment.
    """
    raw = 32 + trigger_count * 2
    return (raw + 3) & ~3


def _build_node_table(ir: IR) -> tuple[bytes, list[int]]:
    """Node Table: one variable-size HumNodeEntry per node.

    Returns (section_bytes, entry_byte_offsets) where entry_byte_offsets[i]
    is the byte offset of node i's entry within the returned bytes.
    Used by the main serializer to patch param_data_offset / param_data_size.
    """
    w = _BlobWriter()
    entry_offsets: list[int] = []

    for node_idx, node in enumerate(ir.nodes):
        entry_offsets.append(w.pos())

        # Runtime pin arrays are indexed by resolved slot, not by edge count.
        # Fanout therefore contributes one output slot regardless of how many
        # consumers share that producer buffer.
        in_count  = len({e.dst_pin for e in ir.edges if e.dst_node == node_idx})
        out_count = len({e.src_pin for e in ir.edges if e.src_node == node_idx})

        trig_indices = list(node.compute_trigger_indices)
        trig_count   = len(trig_indices)

        # 32-byte fixed base
        w.pack(
            _FMT_NODE_ENTRY_BASE,
            node.type_id,            # uint32 type_id
            node.manifest_checksum,  # uint32 manifest_checksum
            0,                       # uint32 param_data_offset  (patched later)
            0,                       # uint32 param_data_size    (patched later)
            node_idx,                # uint32 state_desc_index
            0,                       # uint16 name_offset (no string table in v1)
            in_count,                # uint16 input_pin_count
            out_count,               # uint16 output_pin_count
            node.derived_size,       # uint16 derived_size
            trig_count,              # uint8  compute_trigger_count
            node.compute_cost,       # uint8  compute_cost
            0,                       # uint16 reserved
        )

        # Variable: trigger param indices (uint16 each)
        for idx in trig_indices:
            w.pack("<H", idx)

        # Pad to 4-byte alignment
        raw_size = 32 + trig_count * 2
        pad = (4 - (raw_size % 4)) % 4
        if pad:
            w.zeros(pad)

    return w.to_bytes(), entry_offsets


def _param_type_code(val: Any, param_type: str) -> int:
    if param_type in ("float32",):
        return _DT_FLOAT32
    if param_type in ("fixed32",):
        return _DT_FIXED32
    if param_type in ("ufixed32",):
        return _DT_UFIXED32
    # int, bool, string — encode as 0 (float32 slot)
    return _DT_FLOAT32


def _encode_param_value(val: Any, param_type: str) -> bytes:
    """Encode a single scalar parameter as 4 bytes."""
    if param_type == "float32":
        return struct.pack("<f", float(val))
    if param_type in ("int", "fixed32", "ufixed32"):
        return struct.pack("<i", int(val))
    if param_type == "bool":
        return struct.pack("<I", 1 if val else 0)
    if param_type == "string":
        # Strings are not directly representable as 4 bytes — store length
        return struct.pack("<I", len(val) if isinstance(val, (str, bytes)) else 0)
    # Fallback: float
    try:
        return struct.pack("<f", float(val))
    except (TypeError, struct.error):
        return struct.pack("<I", 0)


def _encode_array_value(arr: list, param_type: str) -> bytes:
    """Encode a list of values as packed float32."""
    result = bytearray()
    for item in arr:
        result += struct.pack("<f", float(item))
    return bytes(result)


def _build_param_data(ir: IR) -> tuple[bytes, list[tuple[int, int]]]:
    """Parameter Data section.

    Returns (section_bytes, node_offsets) where node_offsets[i] = (offset, size)
    of node i's param block within the returned bytes.
    """
    w           = _BlobWriter()
    node_offsets: list[tuple[int, int]] = []

    for node_idx, node in enumerate(ir.nodes):
        block_start = w.pos()

        params    = node.params
        mutability = node.param_mutability

        # Gather all param specs in order (we stored them by name; need consistent order)
        # Use the same order as params dict (Python 3.7+ preserves insertion order)
        param_names = list(params.keys())
        n_params    = len(param_names)

        # HumParamBlockHeader
        w.pack(_FMT_PARAM_BLOCK, n_params, 0)

        # Phase 1: write HumParamDescriptor entries (value_offset TBD)
        # We need to know where values will be, so calculate in advance
        descriptor_block_start = w.pos()
        descriptor_block_size  = n_params * struct.calcsize(_FMT_PARAM_DESC)

        # Calculate per-param value offsets (relative to section start)
        value_start = block_start + 4 + descriptor_block_size  # after header + descs
        value_offsets: list[int] = []
        offset = value_start
        for pname in param_names:
            val = params[pname]
            if isinstance(val, list):
                size = len(val) * 4
            else:
                size = 4
            value_offsets.append(offset)
            offset += size

        # Write descriptors
        for param_id, pname in enumerate(param_names):
            val     = params[pname]
            mut     = mutability.get(pname, Mutability.CONST)
            is_arr  = isinstance(val, list)
            # Determine copy_at_init: any array param (CONST or ARRAY mutable)
            # mutable=ARRAY also requires copy_at_init (double-buffer)
            copy_at_init = 1 if (is_arr or mut == Mutability.ARRAY) else 0
            mem_flags    = 0   # no preference for scalars

            # Check if this node has a param_copy for this param
            for pc in node.descriptor.param_copies:
                if pc.name == pname:
                    mem_flags    = 1 if "fast" in pc.mem_flags else 0
                    copy_at_init = 1
                    break

            v_size = len(val) * 4 if is_arr else 4
            # type field: 0=FLOAT32 for scalars, 3=ARRAY for arrays
            type_code = 3 if is_arr else _DT_FLOAT32
            w.pack(
                _FMT_PARAM_DESC,
                param_id,               # uint16 param_id
                type_code,              # uint8 type
                _MUT_MAP.get(mut, 0),   # uint8 mutable
                value_offsets[param_id],# uint32 value_offset
                v_size,                 # uint32 value_size
                mem_flags,              # uint8 mem_flags
                copy_at_init,           # uint8 copy_at_init
                0,                      # uint16 reserved
            )

        # Phase 2: write values
        for pname in param_names:
            val = params[pname]
            if isinstance(val, list):
                w.write(_encode_array_value(val, "float32"))
            else:
                w.write(_encode_param_value(val, "float32"))

        block_end = w.pos()
        node_offsets.append((block_start, block_end - block_start))

    return w.to_bytes(), node_offsets


def _flags_byte(flags: list[str]) -> int:
    b = 0
    if "fast"     in flags: b |= 0x01
    if "dma_safe" in flags: b |= 0x02
    return b


def _build_state_desc(ir: IR) -> bytes:
    """State Descriptor section: one 12-byte entry per node.

    param_copy_size accounts for double-buffering:
    - mutable=CONST arrays: 1× value_size (single copy in arena)
    - mutable=ARRAY params: 2× value_size (double-buffered swap)
    """
    w = _BlobWriter()
    for node in ir.nodes:
        desc = node.descriptor
        # Base param copy size from descriptor's param_copies list
        pc_size = sum(pc.size for pc in desc.param_copies)
        # Add extra buffer for @array (mutable=ARRAY) params: extra 1× per array param
        for pname, mut in node.param_mutability.items():
            if mut == Mutability.ARRAY:
                val = node.params.get(pname)
                if isinstance(val, list):
                    pc_size += len(val) * 4  # +1× for the second buffer
        pc_flags = _flags_byte(desc.param_copies[0].mem_flags if desc.param_copies else [])
        w.pack(
            _FMT_STATE_DESC,
            desc.state_size,            # uint32 state_size
            pc_size,                    # uint32 param_copy_size (includes 2× for @array)
            _flags_byte(desc.state_mem_flags),  # uint8 state_region_flags
            pc_flags,                   # uint8 param_copy_flags
            4,                          # uint8 alignment (float32 = 4-byte)
            # pad byte from 'x' in fmt
        )
    return w.to_bytes()


def _build_buffer_desc(ir: IR) -> bytes:
    """Buffer Descriptor section: one 20-byte entry per edge."""
    w = _BlobWriter()
    for edge in ir.edges:
        pt  = edge.pin_type
        buf = edge.buffer
        if buf is None:
            # Shouldn't happen after allocator runs; write zeroes
            w.zeros(20)
            continue
        w.pack(
            _FMT_BUFFER_DESC,
            buf.region_id,              # uint8  region_id
            _DT_MAP.get(pt.data_type, 0),  # uint8 data_type
            pt.channels,                # uint16 channels
            pt.block_size,              # uint16 block_size
            0,                          # uint16 reserved (pad)
            buf.offset,                 # uint32 offset
            buf.size,                   # uint32 size
            pt.sample_rate,             # uint32 sample_rate
        )
    return w.to_bytes()


def _build_feedback_desc(ir: IR) -> bytes:
    """Feedback Descriptor section: one 24-byte entry per ShadowPort.

    Encodes which schedule step owns the post-execute shadow copy, which
    output pin drives it, where the shadow buffer lives, and the init scalar.
    """
    if not ir.shadow_ports:
        return b""
    w = _BlobWriter()
    # Build a fast lookup: src_node → schedule_step, output_pin → out_pin_index
    node_step = {node_idx: step for step, node_idx in enumerate(ir.schedule)}
    for sp in ir.shadow_ports:
        buf = sp.buffer
        if buf is None:
            w.zeros(24)
            continue
        step     = node_step.get(sp.src_node, 0)
        out_pin  = sp.src_pin
        # Derive pin_type from any feedback edge referencing this shadow port
        ref_edge = next(
            e for e in ir.edges
            if e.feedback_wire and e.src_node == sp.src_node and e.src_pin == sp.src_pin
        )
        pt = ref_edge.pin_type
        w.pack(
            _FMT_FEEDBACK_DESC,
            step,                           # uint16 schedule_step
            out_pin,                        # uint16 output_pin
            buf.region_id,                  # uint8  region_id
            _DT_MAP.get(pt.data_type, 0),   # uint8  data_type
            pt.channels,                    # uint16 channels
            pt.block_size,                  # uint16 block_size
            0,                              # uint16 reserved
            buf.offset,                     # uint32 shadow_offset
            buf.size,                       # uint32 shadow_size
            sp.init_value,                  # float  init_value
        )
    return w.to_bytes()


def _build_graph_io_desc(ir: IR) -> tuple[bytes, int]:
    """Serialize host-visible graph boundary pins independently of schedule.

    Entries reuse the 16-byte pin-assignment layout. ``reserved`` is 1 for
    graph inputs and 2 for graph outputs.  Keeping this mapping separate from
    the node schedule means graph-input fanout and graph-output aliases do not
    alter a node's runtime pin count.
    """
    w = _BlobWriter()
    count = 0
    for pin_idx, _gp in enumerate(ir.graph_inputs):
        edge_id = next(
            (i for i, e in enumerate(ir.edges) if e.src_node < 0 and e.src_pin == pin_idx),
            None,
        )
        if edge_id is not None:
            _write_pin_assignment(w, ir, edge_id, 1)
            count += 1
    for pin_idx, _gp in enumerate(ir.graph_outputs):
        edge_id = next(
            (i for i, e in enumerate(ir.edges) if e.dst_node < 0 and e.dst_pin == pin_idx),
            None,
        )
        if edge_id is not None:
            _write_pin_assignment(w, ir, edge_id, 2)
            count += 1
    return w.to_bytes(), count


def _build_schedule(ir: IR) -> bytes:
    """Schedule Table: one variable-size entry per schedule step."""
    if not ir.schedule:
        return b""

    # Build lookup: edge index → buffer assignment
    # input_edges[node_idx][pin_idx] → edge
    # output_edges[node_idx][pin_idx] → edge
    from collections import defaultdict
    input_edges:  dict[int, dict[int, int]] = defaultdict(dict)   # [node_idx][pin_idx] = edge_id
    output_edges: dict[int, dict[int, int]] = defaultdict(dict)

    for edge_id, edge in enumerate(ir.edges):
        if edge.dst_node >= 0:
            input_edges[edge.dst_node][edge.dst_pin] = edge_id
        if edge.src_node >= 0:
            key = (edge.src_node, edge.src_pin)
            # Prefer a regular-wire edge so the source node's output pin
            # assignment always points to the live (non-shadow) buffer.
            # A feedback-wire edge is accepted only if no regular edge exists yet.
            existing = output_edges[edge.src_node].get(edge.src_pin)
            if existing is None or (ir.edges[existing].feedback_wire and not edge.feedback_wire):
                output_edges[edge.src_node][edge.src_pin] = edge_id

    w = _BlobWriter()
    seen_graph_inputs: set[int] = set()
    for step, node_idx in enumerate(ir.schedule):
        node  = ir.nodes[node_idx]

        # Count pins from edge lookups
        in_pins  = sorted(input_edges[node_idx].keys())
        out_pins = sorted(output_edges[node_idx].keys())

        w.pack(
            _FMT_SCHED_HDR,
            node_idx,                   # uint16 node_index
            ir.block_divisor,           # uint16 block_divisor
            len(in_pins),               # uint16 input_count
            len(out_pins),              # uint16 output_count
        )

        for pin_idx in in_pins:
            edge_id = input_edges[node_idx][pin_idx]
            edge = ir.edges[edge_id]
            if edge.feedback_wire:
                # reserved=3: consumer reads the shadow buffer, not the live buffer
                sp = ir.shadow_ports[edge.shadow_port_id]
                _write_pin_assignment(w, ir, edge_id, 3, override_buf=sp.buffer)
            elif edge.src_node < 0:
                # A graph input may fan out to multiple consumers.  All such
                # edges alias one producer buffer; mark only its first schedule
                # occurrence as a host-visible graph input so the runtime does
                # not expose duplicates.
                if edge.src_pin not in seen_graph_inputs:
                    seen_graph_inputs.add(edge.src_pin)
                    _write_pin_assignment(w, ir, edge_id, 1)
                else:
                    _write_pin_assignment(w, ir, edge_id, 0)
            else:
                _write_pin_assignment(w, ir, edge_id, 0)

        for pin_idx in out_pins:
            edge_id = output_edges[node_idx][pin_idx]
            # reserved=2 when this output feeds a graph-level output pin
            graph_pin_type = 2 if ir.edges[edge_id].dst_node < 0 else 0
            _write_pin_assignment(w, ir, edge_id, graph_pin_type)

    return w.to_bytes()


def _write_pin_assignment(w: _BlobWriter, ir: IR, edge_id: int,
                           graph_pin_type: int = 0,
                           override_buf: Any = None) -> None:
    """Serialize one pin assignment (16 bytes).

    *graph_pin_type* is stored in the reserved field:
      0 = normal node-to-node edge
      1 = graph-level input  (src_node == -1; host must fill buffer via input_fn)
      2 = graph-level output (dst_node == -1; host must drain buffer via output_fn)
      3 = feedback input (consumer reads shadow buffer from previous block)

    *override_buf* replaces the edge's own buffer assignment when provided.
    Used for feedback inputs, which point to the shadow buffer rather than the
    source node's live output buffer.
    """
    edge = ir.edges[edge_id]
    pt   = edge.pin_type
    buf  = override_buf if override_buf is not None else edge.buffer
    if buf is None:
        w.zeros(struct.calcsize(_FMT_PIN_ASSIGN))
        return
    w.pack(
        _FMT_PIN_ASSIGN,
        buf.region_id,
        _DT_MAP.get(pt.data_type, 0),
        pt.channels,
        pt.block_size,
        graph_pin_type,     # reserved: 0=normal, 1=graph_in, 2=graph_out, 3=feedback
        buf.offset,
        pt.sample_rate,
    )


def _build_section_directory(sections: list[tuple[int, int, int, int, int]]) -> bytes:
    """Write section directory entries.

    Each tuple: (section_type, version, offset, size, entry_count).
    entry_size = 0 for variable-size sections, else fixed size.
    """
    w = _BlobWriter()
    for sec_type, version, offset, size, entry_count in sections:
        w.pack(
            _FMT_SECTION_DIR,
            sec_type,       # uint16 section_type
            version,        # uint16 version
            offset,         # uint32 offset
            size,           # uint32 size
            entry_count,    # uint32 entry_count
            0,              # uint32 entry_size (0 = variable)
        )
    return w.to_bytes()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_GRAPH_CHECKSUM_OFFSET = 36   # byte offset of graph_checksum in file header


def serialize(ir: IR) -> bytes:
    """Serialize a fully-allocated *ir* to a ``.humblob`` byte string.

    Prerequisite: ``allocate(ir)`` must have been called first.
    """
    n_nodes        = len(ir.nodes)
    n_edges        = len(ir.edges)
    n_shadow_ports = len(ir.shadow_ports)
    # Node/schedule/params/state/buffers/graph-io/checksum, plus feedback when used.
    n_sections = 7 + (1 if n_shadow_ports > 0 else 0)

    # ── Build section data ────────────────────────────────────────────────────
    node_table_bytes, node_entry_offsets = _build_node_table(ir)
    state_desc_bytes    = _build_state_desc(ir)
    buffer_desc_bytes   = _build_buffer_desc(ir)
    feedback_desc_bytes = _build_feedback_desc(ir)
    graph_io_bytes, graph_io_count = _build_graph_io_desc(ir)
    schedule_bytes      = _build_schedule(ir)
    param_data_bytes, node_param_offsets = _build_param_data(ir)

    # ── Compute section layout ────────────────────────────────────────────────
    section_dir_offset  = _HEADER_SIZE
    section_dir_size    = n_sections * _SECTION_ENTRY_SIZE

    base = section_dir_offset + section_dir_size   # first section starts here

    nt_offset  = base
    nt_size    = len(node_table_bytes)

    sched_offset = nt_offset + nt_size
    sched_size   = len(schedule_bytes)

    pd_offset  = sched_offset + sched_size
    pd_size    = len(param_data_bytes)

    sd_offset  = pd_offset + pd_size
    sd_size    = len(state_desc_bytes)

    bd_offset  = sd_offset + sd_size
    bd_size    = len(buffer_desc_bytes)

    fd_offset  = bd_offset + bd_size
    fd_size    = len(feedback_desc_bytes)

    gio_offset = fd_offset + fd_size
    gio_size   = len(graph_io_bytes)

    # Checksum section (8 bytes) is always last
    cksum_offset = gio_offset + gio_size
    cksum_size   = 8

    total_size = cksum_offset + cksum_size

    # Patch param_data_offset / param_data_size into node table.
    # Use entry_byte_offsets from _build_node_table (variable-size entries).
    # Within each entry: param_data_offset at byte 8, param_data_size at byte 12.
    nt_mutable = bytearray(node_table_bytes)
    for node_idx, (pd_node_off, pd_node_size) in enumerate(node_param_offsets):
        entry_base = node_entry_offsets[node_idx]
        struct.pack_into("<I", nt_mutable, entry_base + 8,
                         pd_offset + pd_node_off)
        struct.pack_into("<I", nt_mutable, entry_base + 12, pd_node_size)
    node_table_bytes = bytes(nt_mutable)

    # Count tunable params (mutable != CONST) across all nodes
    param_count = sum(
        1 for node in ir.nodes
        for mut in node.param_mutability.values()
        if mut != Mutability.CONST
    )

    # ── Section directory ─────────────────────────────────────────────────────
    sections_info = [
        (_SEC_NODE_TABLE,  1, nt_offset,    nt_size,    n_nodes),
        (_SEC_SCHEDULE,    1, sched_offset, sched_size, len(ir.schedule)),
        (_SEC_PARAM_DATA,  1, pd_offset,    pd_size,    n_nodes),
        (_SEC_STATE_DESC,  1, sd_offset,    sd_size,    n_nodes),
        (_SEC_BUFFER_DESC, 1, bd_offset,    bd_size,    n_edges),
    ]
    if n_shadow_ports > 0:
        sections_info.append(
            (_SEC_FEEDBACK_DESC, 1, fd_offset, fd_size, n_shadow_ports)
        )
    sections_info.append(
        (_SEC_GRAPH_IO_DESC, 1, gio_offset, gio_size, graph_io_count)
    )
    sections_info.append((_SEC_CHECKSUM, 1, cksum_offset, cksum_size, 1))
    sec_dir_bytes = _build_section_directory(sections_info)

    # ── File header ───────────────────────────────────────────────────────────
    # graph_checksum placeholder = 0 for now; patched after hashing
    header_fmt = "<4sBBBBIIIIHHHHBxxxI24s"
    assert struct.calcsize(header_fmt) == _HEADER_SIZE

    header_bytes = struct.pack(
        header_fmt,
        _MAGIC,                         # magic[4]
        _FORMAT_VERSION,                # format_version
        _API_VERSION,                   # api_version
        0,                              # flags
        0,                              # reserved
        total_size,                     # blob_size
        section_dir_offset,             # section_dir_offset
        n_sections,                     # section_count
        ir.sample_rate,                 # sample_rate
        ir.fundamental_block,           # fundamental_block
        n_nodes,                        # node_count
        n_edges,                        # edge_count
        param_count,                    # param_count
        len(ir.memory_regions),         # region_count
        0,                              # graph_checksum (placeholder)
        bytes(24),                      # reserved3[24]
    )

    # ── Assemble blob ─────────────────────────────────────────────────────────
    blob = bytearray(
        header_bytes
        + sec_dir_bytes
        + node_table_bytes
        + schedule_bytes
        + param_data_bytes
        + state_desc_bytes
        + buffer_desc_bytes
        + feedback_desc_bytes
        + graph_io_bytes
        + bytes(cksum_size)   # checksum section placeholder
    )

    # ── Compute graph_checksum ────────────────────────────────────────────────
    # Zero out the checksum field (offset 36, 4 bytes) before hashing
    struct.pack_into("<I", blob, _GRAPH_CHECKSUM_OFFSET, 0)
    graph_checksum = fnv1a_32(bytes(blob[:-cksum_size]))   # hash all except checksum section
    struct.pack_into("<I", blob, _GRAPH_CHECKSUM_OFFSET, graph_checksum)

    # ── Write checksum section ────────────────────────────────────────────────
    # FNV-1a of all preceding bytes (everything before checksum section)
    trailing_checksum = fnv1a_32(bytes(blob[:-cksum_size]))
    struct.pack_into("<I", blob, cksum_offset, trailing_checksum)
    struct.pack_into("<I", blob, cksum_offset + 4, 0)   # reserved

    return bytes(blob)
