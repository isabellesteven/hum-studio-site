"""Shared Hum compilation pipeline.

This module is the semantic/toolchain entry point used by both the CLI and the
browser front-end.  It keeps pipeline ordering in one place and pairs the
runtime IR with the versioned developer-facing inspection model.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from hum.allocator import allocate
from hum.builder import build_with_metadata
from hum.inspection import InspectionModel, build_inspection
from hum.ir import IR
from hum.liveness import compute_liveness
from hum.project import Project
from hum.toposort import topo_sort
from hum.typechecker import check_types


@dataclass(frozen=True)
class Compilation:
    ir: IR
    inspection: InspectionModel


def compile_graph(
    source: str,
    project: Project,
    pkg_dirs: dict[str, Path],
) -> Compilation:
    """Run the complete compiler pipeline and return runtime + tooling models."""
    ir, metadata = build_with_metadata(source, project, pkg_dirs)
    check_types(ir)
    topo_sort(ir)
    compute_liveness(ir)
    allocate(ir)
    inspection = build_inspection(ir, metadata, project)
    return Compilation(ir=ir, inspection=inspection)
