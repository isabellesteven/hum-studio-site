"""Topological sort — determines node execution order.

Uses Kahn's algorithm (BFS-based).  Feedback (unit-delay) edges are excluded
from the dependency graph so intentional cycles are legal cycle-breakers.
Plain-wire back-edges are hard errors.

After this stage:
  - ``ir.schedule`` contains node indices in execution order.
  - Each ``ir.nodes[i].schedule_index`` is updated to its position in the
    schedule.

Error codes:
  E084 — cycle detected on a plain (non-feedback) wire.
"""

from __future__ import annotations

from collections import deque

from hum.errors import CompileError, HumError
from hum.ir import IR


def _find_plain_wire_back_edge(
    n: int,
    adjacency: list[set[int]],
    node_names: list[str],
) -> tuple[str, str] | None:
    """DFS over *adjacency* to find the first back-edge.

    Returns (src_name, dst_name) of the closing edge, or None (shouldn't
    happen if Kahn's already detected a cycle).
    """
    WHITE, GRAY, BLACK = 0, 1, 2
    color = [WHITE] * n

    def dfs(u: int) -> tuple[str, str] | None:
        color[u] = GRAY
        for v in adjacency[u]:
            if color[v] == GRAY:
                return (node_names[u], node_names[v])
            if color[v] == WHITE:
                result = dfs(v)
                if result:
                    return result
        color[u] = BLACK
        return None

    for i in range(n):
        if color[i] == WHITE:
            result = dfs(i)
            if result:
                return result
    return None


def topo_sort(ir: IR) -> None:
    """Sort nodes topologically and write the result into *ir*.

    Feedback edges (``edge.feedback_wire == True``) are treated as
    cycle-breakers and excluded from the dependency graph.  Any remaining
    plain-wire cycle is a hard error (E084).
    """
    n = len(ir.nodes)
    if n == 0:
        ir.schedule = []
        return

    # Build adjacency excluding feedback edges.
    # in_degree[i] = number of plain-wire predecessors for node i.
    in_degree = [0] * n
    adjacency: list[set[int]] = [set() for _ in range(n)]

    for edge in ir.edges:
        if edge.feedback_wire:
            continue   # feedback edges are cycle-breakers; not a dependency
        src = edge.src_node
        dst = edge.dst_node
        if src >= 0 and dst >= 0:
            if dst not in adjacency[src]:
                adjacency[src].add(dst)
                in_degree[dst] += 1

    # Kahn's algorithm
    queue: deque[int] = deque(i for i in range(n) if in_degree[i] == 0)
    schedule: list[int] = []

    while queue:
        node_idx = queue.popleft()
        schedule.append(node_idx)
        for successor in adjacency[node_idx]:
            in_degree[successor] -= 1
            if in_degree[successor] == 0:
                queue.append(successor)

    if len(schedule) != n:
        node_names = [node.name for node in ir.nodes]
        back_edge = _find_plain_wire_back_edge(n, adjacency, node_names)
        if back_edge:
            src_name, dst_name = back_edge
            raise CompileError([HumError(
                code="E084",
                message=(
                    f"cycle detected: non-feedback edge from '{src_name}' to "
                    f"'{dst_name}'. Use ~> for intentional unit-delay feedback."
                ),
            )])
        # Fallback (back-edge finder returned None unexpectedly)
        cycle_nodes = [ir.nodes[i].name for i in range(n) if in_degree[i] > 0]
        raise CompileError([HumError(
            code="E084",
            message=(
                f"cycle detected in graph; nodes involved: "
                f"{', '.join(cycle_nodes)}"
            ),
        )])

    ir.schedule = schedule
    for step, node_idx in enumerate(schedule):
        ir.nodes[node_idx].schedule_index = step
